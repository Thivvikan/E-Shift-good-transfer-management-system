﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace E_Shift
{
    public partial class ManageAdminProfile : UserControl
    {
        // connection string
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True";

        public ManageAdminProfile()
        {
            InitializeComponent();
        }

        public static string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string newUsername = nameTxt.Text.Trim();
            string newPassword = createPasswordTxt.Text;
            string confirmPassword = confirmPasswordTxt.Text;

            if (string.IsNullOrWhiteSpace(newUsername) || string.IsNullOrWhiteSpace(newPassword))
            {
                MessageBox.Show("Username and password cannot be empty.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (newPassword != confirmPassword)
            {
                MessageBox.Show("Passwords do not match.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string hashedPassword = HashPassword(newPassword);

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    string query = @"UPDATE Users 
                             SET Username = @Username, PasswordHash = @PasswordHash 
                             WHERE Role = 'Admin'";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@Username", newUsername);
                    cmd.Parameters.AddWithValue("@PasswordHash", hashedPassword);

                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0)
                    {
                        MessageBox.Show("Admin credentials updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("No admin account found to update.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating credentials:\n" + ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void showPasswordCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            createPasswordTxt.UseSystemPasswordChar = !showPasswordCheckBox.Checked;
            confirmPasswordTxt.UseSystemPasswordChar = !showPasswordCheckBox.Checked;
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            nameTxt.Clear();
            createPasswordTxt.Clear();
            confirmPasswordTxt.Clear();
        }
    }
}
