﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace E_Shift
{
    public partial class ManageJobs : UserControl
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True";
        private AdminDashboard adminDashboard;

        // Constructor for default (not recommended for this use)
        //public ManageJobs()
        //{
            //InitializeComponent();
        //}

        // Constructor that accepts AdminDashboard reference
        public ManageJobs(AdminDashboard dashboard)
        {
            InitializeComponent();
            this.adminDashboard = dashboard;
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            int jobId;
            if (!int.TryParse(jobIdTxt.Text, out jobId))
            {
                MessageBox.Show("Invalid Job ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string customerID = customerIdTxt.Text;
            string startLocation = startLocationTxt.Text.Trim();
            string destination = destinationTxt.Text.Trim();
            DateTime jobDate = jobDateAndTimeDTP.Value;
            string status = statusCB.Text;

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    if (status == "Rejected")
                    {
                        string deleteLoads = "DELETE FROM Load WHERE JobID = @JobID";
                        using (SqlCommand cmd = new SqlCommand(deleteLoads, conn))
                        {
                            cmd.Parameters.AddWithValue("@JobID", jobId);
                            cmd.ExecuteNonQuery();
                        }

                        string deleteJob = "DELETE FROM Job WHERE JobID = @JobID";
                        using (SqlCommand cmd = new SqlCommand(deleteJob, conn))
                        {
                            cmd.Parameters.AddWithValue("@JobID", jobId);
                            int rows = cmd.ExecuteNonQuery();

                            if (rows > 0)
                            {
                                MessageBox.Show("Job rejected and deleted.", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                // Notify customer
                                // Get CustomerID for the Job
                                string getCustomerQuery = "SELECT CustomerID FROM Job WHERE JobID = @JobID";
                                int CustomerID = 0;
                                using (SqlCommand cmdGetCustomer = new SqlCommand(getCustomerQuery, conn))
                                {
                                    cmdGetCustomer.Parameters.AddWithValue("@JobID", jobId);
                                    object result = cmdGetCustomer.ExecuteScalar();
                                    if (result != null) CustomerID = Convert.ToInt32(result);
                                }

                                // Insert Notification
                                string message = $"Your job #{jobId} is Rejected.";
                                string insertNotification = @"INSERT INTO Notifications (CustomerID, Message) 
                                    VALUES (@CustomerID, @Message)";
                                using (SqlCommand cmdNotify = new SqlCommand(insertNotification, conn))
                                {
                                    cmdNotify.Parameters.AddWithValue("@CustomerID", CustomerID);
                                    cmdNotify.Parameters.AddWithValue("@Message", message);
                                    cmdNotify.ExecuteNonQuery();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Job not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }

                        return;
                    }

                    string updateQuery = "UPDATE Job SET StartLocation = @StartLocation, Destination = @Destination, JobDate = @JobDate, Status = @Status " +
                                         "WHERE JobID = @JobID AND CustomerID = @CustomerID";

                    using (SqlCommand cmd = new SqlCommand(updateQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@StartLocation", startLocation);
                        cmd.Parameters.AddWithValue("@Destination", destination);
                        cmd.Parameters.AddWithValue("@JobDate", jobDate);
                        cmd.Parameters.AddWithValue("@Status", status);
                        cmd.Parameters.AddWithValue("@JobID", jobId);
                        cmd.Parameters.AddWithValue("@CustomerID", customerID);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Job updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            if (status == "Approved")
                            {
                                // Create ManageLoad and pass dashboard
                                ManageLoad manageLoadsUC = new ManageLoad(adminDashboard);
                                manageLoadsUC.LoadLoadsByJob(jobId);
                                manageLoadsUC.LoadAvailableTransportUnits();
                                adminDashboard.LoadUserControl(manageLoadsUC);

                                // Notify customer
                                // Get CustomerID for the Job
                                string getCustomerQuery = "SELECT CustomerID FROM Job WHERE JobID = @JobID";
                                int CustomerID = 0;
                                using (SqlCommand cmdGetCustomer = new SqlCommand(getCustomerQuery, conn))
                                {
                                    cmdGetCustomer.Parameters.AddWithValue("@JobID", jobId);
                                    object result = cmdGetCustomer.ExecuteScalar();
                                    if (result != null) CustomerID = Convert.ToInt32(result);
                                }

                                // Insert Notification
                                string message = $"Your job #{jobId} is now Approved.";
                                string insertNotification = @"INSERT INTO Notifications (CustomerID, Message) 
                                    VALUES (@CustomerID, @Message)";
                                using (SqlCommand cmdNotify = new SqlCommand(insertNotification, conn))
                                {
                                    cmdNotify.Parameters.AddWithValue("@CustomerID", CustomerID);
                                    cmdNotify.Parameters.AddWithValue("@Message", message);
                                    cmdNotify.ExecuteNonQuery();
                                }

                            }
                        }
                        else
                        {
                            MessageBox.Show("Update failed. Please check the Job ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while updating job:\n" + ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void LoadJobDetails(string jobID)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    string jobQuery = "SELECT * FROM Job WHERE JobID = @JobID";
                    using (SqlCommand cmd = new SqlCommand(jobQuery, con))
                    {
                        cmd.Parameters.AddWithValue("@JobID", jobID);
                        SqlDataReader reader = cmd.ExecuteReader();

                        if (reader.Read())
                        {
                            jobIdTxt.Text = reader["JobID"].ToString();
                            customerIdTxt.Text = reader["CustomerID"].ToString();
                            startLocationTxt.Text = reader["StartLocation"].ToString();
                            destinationTxt.Text = reader["Destination"].ToString();
                            jobDateAndTimeDTP.Value = Convert.ToDateTime(reader["JobDate"]);
                            statusCB.Text = reader["Status"].ToString();
                        }

                        reader.Close();
                    }

                    string loadQuery = "SELECT * FROM Load WHERE JobID = @JobID";
                    SqlCommand loadCmd = new SqlCommand(loadQuery, con);
                    loadCmd.Parameters.AddWithValue("@JobID", jobID);

                    SqlDataAdapter adapter = new SqlDataAdapter(loadCmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    loadsOfTheJobDGV.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading job details: " + ex.Message);
                }
            }
        }

        public void LoadJobDetails()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Job";
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                viewJobsDGV.DataSource = dt;
            }
        }

        private void ManageJobs_Load(object sender, EventArgs e)
        {
            LoadJobDetails();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(jobIdTxt.Text))
            {
                MessageBox.Show("Please enter a Job ID to search.", "Input Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            int jobID = Convert.ToInt32(jobIdTxt.Text);

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    // --- Search Job Details ---
                    string jobQuery = "SELECT * FROM Job WHERE JobID = @JobID";
                    SqlCommand jobCmd = new SqlCommand(jobQuery, con);
                    jobCmd.Parameters.AddWithValue("@JobID", jobID);

                    SqlDataReader reader = jobCmd.ExecuteReader();

                    if (reader.Read())
                    {
                        customerIdTxt.Text = reader["CustomerID"].ToString();
                        startLocationTxt.Text = reader["StartLocation"].ToString();
                        destinationTxt.Text = reader["Destination"].ToString();
                        jobDateAndTimeDTP.Value = Convert.ToDateTime(reader["JobDate"]);
                        statusCB.Text = reader["Status"].ToString();
                    }
                    else
                    {
                        MessageBox.Show("No job found with that ID.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        reader.Close();
                        return;
                    }

                    reader.Close();
                    loadsOfTheJob(jobID);



                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while searching: " + ex.Message);
                }
            }
        }

        private void loadsOfTheJob(int JobID)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    // --- Load Related Loads for this Job ---
                    string loadQuery = "SELECT * FROM Load WHERE JobID = @JobID";
                    SqlCommand loadCmd = new SqlCommand(loadQuery, con);
                    loadCmd.Parameters.AddWithValue("@JobID", jobIdTxt.Text.Trim());

                    SqlDataAdapter loadAdapter = new SqlDataAdapter(loadCmd);
                    DataTable loadTable = new DataTable();
                    loadAdapter.Fill(loadTable);

                    loadsOfTheJobDGV.DataSource = loadTable;

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while searching: " + ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(jobIdTxt.Text))
            {
                MessageBox.Show("Please enter a Job ID to delete.", "Input Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult confirmResult = MessageBox.Show("Are you sure you want to delete this job and all its related loads?",
                                                          "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (confirmResult != DialogResult.Yes)
                return;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    string jobId = jobIdTxt.Text.Trim();

                    // --- Delete related loads first ---
                    string deleteLoadsQuery = "DELETE FROM Load WHERE JobID = @JobID";
                    SqlCommand deleteLoadsCmd = new SqlCommand(deleteLoadsQuery, con);
                    deleteLoadsCmd.Parameters.AddWithValue("@JobID", jobId);
                    deleteLoadsCmd.ExecuteNonQuery();

                    // --- Then delete the job ---
                    string deleteJobQuery = "DELETE FROM Job WHERE JobID = @JobID";
                    SqlCommand deleteJobCmd = new SqlCommand(deleteJobQuery, con);
                    deleteJobCmd.Parameters.AddWithValue("@JobID", jobId);
                    int rowsAffected = deleteJobCmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Job and its related loads deleted successfully.", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Clear the fields
                        customerIdTxt.Clear();
                        startLocationTxt.Clear();
                        destinationTxt.Clear();
                        jobIdTxt.Clear();
                        statusCB.SelectedIndex = -1;
                        jobDateAndTimeDTP.Value = DateTime.Now;
                        loadsOfTheJobDGV.DataSource = null;
                    }
                    else
                    {
                        MessageBox.Show("No job found with the given ID.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while deleting: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void viewJobsDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Make sure the click is on a valid row
            {
                DataGridViewRow row = viewJobsDGV.Rows[e.RowIndex];

                // Load data from the clicked row into input fields
                jobIdTxt.Text = row.Cells["JobID"].Value?.ToString();
                customerIdTxt.Text = row.Cells["CustomerID"].Value.ToString();
                startLocationTxt.Text = row.Cells["StartLocation"].Value.ToString();
                destinationTxt.Text = row.Cells["Destination"].Value.ToString();
                jobDateAndTimeDTP.Value = Convert.ToDateTime(row.Cells["JobDate"].Value);
                statusCB.Text = row.Cells["Status"].Value.ToString();
                int jobID = Convert.ToInt32(jobIdTxt.Text);
                loadsOfTheJob(jobID);
            }
        }

        private void loadsOfTheJobDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}