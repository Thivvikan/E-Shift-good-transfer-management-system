﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace E_Shift
{
    public partial class CustomerEnquiry : UserControl
    {
        // connection string
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True";

        public CustomerEnquiry()
        {
            InitializeComponent();
        }

        private void sendBtn_Click(object sender, EventArgs e)
        {
            string description = enquiryDescriptionTxt.Text.Trim();

            if (string.IsNullOrWhiteSpace(description))
            {
                MessageBox.Show("Please enter your enquiry.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = @"INSERT INTO Enquiry (CustomerID, EnquiryDescription)
                             VALUES (@CustomerID, @Description)";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@CustomerID", Session.LoggedInCustomerID);
                    cmd.Parameters.AddWithValue("@Description", description);

                    int result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        MessageBox.Show("Your enquiry has been sent successfully.");
                        enquiryDescriptionTxt.Clear();
                    }
                    else
                    {
                        MessageBox.Show("Failed to send enquiry.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            enquiryDescriptionTxt.Clear();
        }
        
        private void cancelBtn_Click(object sender, EventArgs e)
        {
            // Get reference to the parent form
            CustomerDashboard dashboardForm = this.FindForm() as CustomerDashboard;

            if (dashboardForm != null)
            {
                // Create a new instance of the dashboard user control
                DefaultCustomerDashboard dashboardUC = new DefaultCustomerDashboard();

                // Load the dashboard user control into the main panel
                dashboardForm.CustomerLoadUserControl(dashboardUC);
            }
        }
    }
}
