﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace E_Shift
{
    public partial class ManageLorryAndContainer : UserControl
    {
        // connection string
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True";

        public ManageLorryAndContainer()
        {
            InitializeComponent();
        }

        private void clearAll()
        {
            lorryIDTxt.Clear();
            plateNumberTxt.Clear();
            capacityTxt.Clear();
               
            containerIdTxt.Clear();
            containerCapacityTxt.Clear();
            dimensionTxt.Clear();
        }

        private void insertBtn_Click(object sender, EventArgs e)
        {
            string plateNumber = plateNumberTxt.Text.Trim();
            if (!int.TryParse(capacityTxt.Text.Trim(), out int capacity))
            {
                MessageBox.Show("Invalid capacity.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Lorry (PlateNumber, Capacity) VALUES (@PlateNumber, @Capacity)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@PlateNumber", plateNumber);
                cmd.Parameters.AddWithValue("@Capacity", capacity);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Lorry inserted successfully.");
                clearAll();
                LoadLorries();
            }
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(lorryIDTxt.Text, out int lorryId))
            {
                MessageBox.Show("Invalid Lorry ID.");
                return;
            }

            string plateNumber = plateNumberTxt.Text.Trim();
            if (!int.TryParse(capacityTxt.Text.Trim(), out int capacity))
            {
                MessageBox.Show("Invalid capacity.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "UPDATE Lorry SET PlateNumber = @PlateNumber, Capacity = @Capacity WHERE LorryID = @LorryID";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@PlateNumber", plateNumber);
                cmd.Parameters.AddWithValue("@Capacity", capacity);
                cmd.Parameters.AddWithValue("@LorryID", lorryId);

                con.Open();
                int rows = cmd.ExecuteNonQuery();
                con.Close();

                if (rows > 0)
                {
                    MessageBox.Show("Lorry updated.");
                    LoadLorries();
                    clearAll();
                }
                else
                {
                    MessageBox.Show("Lorry not found.");
                }
            }
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(lorryIDTxt.Text, out int lorryId))
            {
                MessageBox.Show("Invalid Lorry ID.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Lorry WHERE LorryID = @LorryID";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@LorryID", lorryId);

                con.Open();
                int rows = cmd.ExecuteNonQuery();
                con.Close();

                if (rows > 0)
                {
                    MessageBox.Show("Lorry deleted.");
                    clearAll();
                    LoadLorries();
                }
                else
                {
                    MessageBox.Show("Lorry not found.");
                }
            }
        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(lorryIDTxt.Text, out int lorryId))
            {
                MessageBox.Show("Invalid Lorry ID.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Lorry WHERE LorryID = @LorryID";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@LorryID", lorryId);

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    plateNumberTxt.Text = reader["PlateNumber"].ToString();
                    capacityTxt.Text = reader["Capacity"].ToString();
                    LoadLorryAssignedLoads(lorryId);
                }
                else
                {
                    MessageBox.Show("Lorry not found.");
                }
                con.Close();
            }
        }

        private void LoadLorryAssignedLoads(int lorryId)
        {
            string query = @"
                SELECT 
                    l.LoadID,
                    l.JobID,
                    tu.TransportUnitID,
                    lo.PlateNumber,
                    d.Name AS DriverName,
                    a.Name AS AssistantName
                FROM [Load] l
                INNER JOIN TransportUnit tu ON l.TransportUnitID = tu.TransportUnitID
                INNER JOIN Lorry lo ON tu.LorryID = lo.LorryID
                INNER JOIN Driver d ON tu.DriverID = d.DriverID
                INNER JOIN Assistant a ON tu.AssistantID = a.AssistantID
                INNER JOIN Container c ON tu.ContainerID = c.ContainerID
                WHERE lo.LorryID = @LorryID
                ORDER BY l.LoadID DESC;
                ";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@LorryID", lorryId);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    lorryAssignedJobsDGV.DataSource = dt;
                }
            }
        }



        private void LoadLorries()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Lorry";
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                lorryDGV.DataSource = dt;
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void ManageLorryAndContainer_Load(object sender, EventArgs e)
        {
            LoadLorries();
            LoadContainers();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            string capacity = containerCapacityTxt.Text;
            string dimensions = dimensionTxt.Text;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Container (Capacity, Dimensions) VALUES (@Capacity, @Dimensions)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Capacity", capacity);
                cmd.Parameters.AddWithValue("@Dimensions", dimensions);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Container inserted successfully.");
                clearAll();
                LoadContainers();
            }
        }

        private void containerUpdateBtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(containerCapacityTxt.Text.Trim(), out int containerId))
            {
                MessageBox.Show("Invalid Container ID.");
                return;
            }

            if (!float.TryParse(capacityTxt.Text.Trim(), out float capacity))
            {
                MessageBox.Show("Invalid Capacity.");
                return;
            }

            string dimensions = dimensionTxt.Text.Trim();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "UPDATE Container SET Capacity = @Capacity, Dimensions = @Dimensions WHERE ContainerID = @ContainerID";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Capacity", capacity);
                cmd.Parameters.AddWithValue("@Dimensions", dimensions);
                cmd.Parameters.AddWithValue("@ContainerID", containerId);

                con.Open();
                int rows = cmd.ExecuteNonQuery();
                con.Close();

                if (rows > 0)
                {
                    MessageBox.Show("Container updated.");
                    clearAll();
                    LoadContainers();
                }
                else
                {
                    MessageBox.Show("Container not found.");
                }
            }
        }

        private void containerDeleteBtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(containerIdTxt.Text.Trim(), out int containerId))
            {
                MessageBox.Show("Invalid Container ID.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Container WHERE ContainerID = @ContainerID";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@ContainerID", containerId);

                con.Open();
                int rows = cmd.ExecuteNonQuery();
                con.Close();

                if (rows > 0)
                {
                    MessageBox.Show("Container deleted.");
                    clearAll();
                    LoadContainers();
                }
                else
                {
                    MessageBox.Show("Container not found.");
                }
            }
        }

        private void containerSearchBtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(containerIdTxt.Text.Trim(), out int containerId))
            {
                MessageBox.Show("Invalid Container ID.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Container WHERE ContainerID = @ContainerID";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@ContainerID", containerId);

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    capacityTxt.Text = reader["Capacity"].ToString();
                    dimensionTxt.Text = reader["Dimensions"].ToString();
                    LoadContainerAssignedLoads(containerId);
                }
                else
                {
                    MessageBox.Show("Container not found.");
                }

                con.Close();
            }
        }

        private void LoadContainerAssignedLoads(int containerId)
        {
            string query = @"
                SELECT 
                    l.LoadID,
                    l.JobID,
                    tu.TransportUnitID,
                    lo.PlateNumber,
                    d.Name AS DriverName,
                    a.Name AS AssistantName
                FROM Load l
                INNER JOIN TransportUnit tu ON l.TransportUnitID = tu.TransportUnitID
                INNER JOIN Lorry lo ON tu.LorryID = lo.LorryID
                INNER JOIN Driver d ON tu.DriverID = d.DriverID
                INNER JOIN Assistant a ON tu.AssistantID = a.AssistantID
                INNER JOIN Container c ON tu.ContainerID = c.ContainerID
                WHERE c.ContainerID = @ContainerID
                ORDER BY l.LoadID DESC;
            ";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@ContainerID", containerId);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    containerAssignedJobsDGV.DataSource = dt;
                }
            }
        }

        private void LoadContainers()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Container";
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                containerDGV.DataSource = dt;
            }
        }

        private void containerDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // to ignore header row clicks
            {
                DataGridViewRow row = containerDGV.Rows[e.RowIndex];

                containerIdTxt.Text = row.Cells["ContainerID"].Value.ToString();
                containerCapacityTxt.Text = row.Cells["Capacity"].Value.ToString();
                dimensionTxt.Text = row.Cells["Dimensions"].Value.ToString();
                // conveting the datagrid value to int
                int containerId = Convert.ToInt32(row.Cells["ContainerID"].Value);
                LoadContainerAssignedLoads(containerId);
            }
        }

        private void lorryDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // to ignore header row clicks
            {
                DataGridViewRow row = lorryDGV.Rows[e.RowIndex];

                lorryIDTxt.Text = row.Cells["LorryID"].Value.ToString();
                plateNumberTxt.Text = row.Cells["PlateNumber"].Value.ToString();
                capacityTxt.Text = row.Cells["Capacity"].Value.ToString();
                // conveting the datagrid value to int
                int lorryId = Convert.ToInt32(row.Cells["LorryID"].Value);
                LoadLorryAssignedLoads(lorryId);
            }
        }
    }
}
