﻿namespace E_Shift
{
    partial class ManageLorryAndContainer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dimensionTxt = new System.Windows.Forms.TextBox();
            this.containerCapacityTxt = new System.Windows.Forms.TextBox();
            this.containerIdTxt = new System.Windows.Forms.TextBox();
            this.containerSearchBtn = new System.Windows.Forms.Button();
            this.containerDeleteBtn = new System.Windows.Forms.Button();
            this.containerUpdateBtn = new System.Windows.Forms.Button();
            this.containerInsertBtn = new System.Windows.Forms.Button();
            this.containerDGV = new System.Windows.Forms.DataGridView();
            this.containerAssignedJobsDGV = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.capacityTxt = new System.Windows.Forms.TextBox();
            this.plateNumberTxt = new System.Windows.Forms.TextBox();
            this.lorryIDTxt = new System.Windows.Forms.TextBox();
            this.searchBtn = new System.Windows.Forms.Button();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.updateBtn = new System.Windows.Forms.Button();
            this.insertBtn = new System.Windows.Forms.Button();
            this.lorryDGV = new System.Windows.Forms.DataGridView();
            this.lorryAssignedJobsDGV = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.containerDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.containerAssignedJobsDGV)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lorryDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lorryAssignedJobsDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.dimensionTxt);
            this.groupBox2.Controls.Add(this.containerCapacityTxt);
            this.groupBox2.Controls.Add(this.containerIdTxt);
            this.groupBox2.Controls.Add(this.containerSearchBtn);
            this.groupBox2.Controls.Add(this.containerDeleteBtn);
            this.groupBox2.Controls.Add(this.containerUpdateBtn);
            this.groupBox2.Controls.Add(this.containerInsertBtn);
            this.groupBox2.Controls.Add(this.containerDGV);
            this.groupBox2.Controls.Add(this.containerAssignedJobsDGV);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(380, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(358, 562);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Manage Container";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // dimensionTxt
            // 
            this.dimensionTxt.Location = new System.Drawing.Point(174, 129);
            this.dimensionTxt.Name = "dimensionTxt";
            this.dimensionTxt.PlaceholderText = "Length x Width";
            this.dimensionTxt.Size = new System.Drawing.Size(146, 30);
            this.dimensionTxt.TabIndex = 60;
            // 
            // containerCapacityTxt
            // 
            this.containerCapacityTxt.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.containerCapacityTxt.Location = new System.Drawing.Point(174, 80);
            this.containerCapacityTxt.Name = "containerCapacityTxt";
            this.containerCapacityTxt.PlaceholderText = "max weight, volume";
            this.containerCapacityTxt.Size = new System.Drawing.Size(146, 27);
            this.containerCapacityTxt.TabIndex = 58;
            // 
            // containerIdTxt
            // 
            this.containerIdTxt.Location = new System.Drawing.Point(174, 33);
            this.containerIdTxt.Name = "containerIdTxt";
            this.containerIdTxt.Size = new System.Drawing.Size(146, 30);
            this.containerIdTxt.TabIndex = 57;
            // 
            // containerSearchBtn
            // 
            this.containerSearchBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.containerSearchBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.containerSearchBtn.Location = new System.Drawing.Point(250, 312);
            this.containerSearchBtn.Name = "containerSearchBtn";
            this.containerSearchBtn.Size = new System.Drawing.Size(70, 26);
            this.containerSearchBtn.TabIndex = 56;
            this.containerSearchBtn.Text = "Search";
            this.containerSearchBtn.UseVisualStyleBackColor = false;
            this.containerSearchBtn.Click += new System.EventHandler(this.containerSearchBtn_Click);
            // 
            // containerDeleteBtn
            // 
            this.containerDeleteBtn.BackColor = System.Drawing.Color.Red;
            this.containerDeleteBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.containerDeleteBtn.Location = new System.Drawing.Point(174, 312);
            this.containerDeleteBtn.Name = "containerDeleteBtn";
            this.containerDeleteBtn.Size = new System.Drawing.Size(70, 26);
            this.containerDeleteBtn.TabIndex = 55;
            this.containerDeleteBtn.Text = "Delete";
            this.containerDeleteBtn.UseVisualStyleBackColor = false;
            this.containerDeleteBtn.Click += new System.EventHandler(this.containerDeleteBtn_Click);
            // 
            // containerUpdateBtn
            // 
            this.containerUpdateBtn.BackColor = System.Drawing.Color.Yellow;
            this.containerUpdateBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.containerUpdateBtn.Location = new System.Drawing.Point(98, 312);
            this.containerUpdateBtn.Name = "containerUpdateBtn";
            this.containerUpdateBtn.Size = new System.Drawing.Size(70, 26);
            this.containerUpdateBtn.TabIndex = 54;
            this.containerUpdateBtn.Text = "Update";
            this.containerUpdateBtn.UseVisualStyleBackColor = false;
            this.containerUpdateBtn.Click += new System.EventHandler(this.containerUpdateBtn_Click);
            // 
            // containerInsertBtn
            // 
            this.containerInsertBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.containerInsertBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.containerInsertBtn.Location = new System.Drawing.Point(22, 312);
            this.containerInsertBtn.Name = "containerInsertBtn";
            this.containerInsertBtn.Size = new System.Drawing.Size(70, 26);
            this.containerInsertBtn.TabIndex = 53;
            this.containerInsertBtn.Text = "Insert";
            this.containerInsertBtn.UseVisualStyleBackColor = false;
            this.containerInsertBtn.Click += new System.EventHandler(this.button4_Click);
            // 
            // containerDGV
            // 
            this.containerDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.containerDGV.Location = new System.Drawing.Point(22, 357);
            this.containerDGV.Name = "containerDGV";
            this.containerDGV.RowHeadersWidth = 51;
            this.containerDGV.RowTemplate.Height = 29;
            this.containerDGV.Size = new System.Drawing.Size(311, 131);
            this.containerDGV.TabIndex = 52;
            this.containerDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.containerDGV_CellContentClick);
            // 
            // containerAssignedJobsDGV
            // 
            this.containerAssignedJobsDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.containerAssignedJobsDGV.Location = new System.Drawing.Point(22, 206);
            this.containerAssignedJobsDGV.Name = "containerAssignedJobsDGV";
            this.containerAssignedJobsDGV.RowHeadersWidth = 51;
            this.containerAssignedJobsDGV.RowTemplate.Height = 29;
            this.containerAssignedJobsDGV.Size = new System.Drawing.Size(311, 84);
            this.containerAssignedJobsDGV.TabIndex = 51;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 183);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(155, 22);
            this.label6.TabIndex = 50;
            this.label6.Text = "Jobs Assigned for:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(22, 132);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(106, 22);
            this.label7.TabIndex = 49;
            this.label7.Text = "Dimensions";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(22, 83);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 22);
            this.label9.TabIndex = 47;
            this.label9.Text = "Capacity";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(22, 36);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(117, 22);
            this.label10.TabIndex = 46;
            this.label10.Text = "Container ID";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.capacityTxt);
            this.groupBox1.Controls.Add(this.plateNumberTxt);
            this.groupBox1.Controls.Add(this.lorryIDTxt);
            this.groupBox1.Controls.Add(this.searchBtn);
            this.groupBox1.Controls.Add(this.deleteBtn);
            this.groupBox1.Controls.Add(this.updateBtn);
            this.groupBox1.Controls.Add(this.insertBtn);
            this.groupBox1.Controls.Add(this.lorryDGV);
            this.groupBox1.Controls.Add(this.lorryAssignedJobsDGV);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(11, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(352, 562);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Manage Lorry";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // capacityTxt
            // 
            this.capacityTxt.Location = new System.Drawing.Point(169, 132);
            this.capacityTxt.Name = "capacityTxt";
            this.capacityTxt.Size = new System.Drawing.Size(146, 30);
            this.capacityTxt.TabIndex = 44;
            // 
            // plateNumberTxt
            // 
            this.plateNumberTxt.Location = new System.Drawing.Point(169, 83);
            this.plateNumberTxt.Name = "plateNumberTxt";
            this.plateNumberTxt.Size = new System.Drawing.Size(146, 30);
            this.plateNumberTxt.TabIndex = 43;
            // 
            // lorryIDTxt
            // 
            this.lorryIDTxt.Location = new System.Drawing.Point(169, 36);
            this.lorryIDTxt.Name = "lorryIDTxt";
            this.lorryIDTxt.Size = new System.Drawing.Size(146, 30);
            this.lorryIDTxt.TabIndex = 42;
            // 
            // searchBtn
            // 
            this.searchBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.searchBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.searchBtn.Location = new System.Drawing.Point(234, 315);
            this.searchBtn.Name = "searchBtn";
            this.searchBtn.Size = new System.Drawing.Size(70, 26);
            this.searchBtn.TabIndex = 41;
            this.searchBtn.Text = "Search";
            this.searchBtn.UseVisualStyleBackColor = false;
            this.searchBtn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // deleteBtn
            // 
            this.deleteBtn.BackColor = System.Drawing.Color.Red;
            this.deleteBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.deleteBtn.Location = new System.Drawing.Point(158, 315);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(70, 26);
            this.deleteBtn.TabIndex = 40;
            this.deleteBtn.Text = "Delete";
            this.deleteBtn.UseVisualStyleBackColor = false;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // updateBtn
            // 
            this.updateBtn.BackColor = System.Drawing.Color.Yellow;
            this.updateBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.updateBtn.Location = new System.Drawing.Point(82, 315);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(70, 26);
            this.updateBtn.TabIndex = 39;
            this.updateBtn.Text = "Update";
            this.updateBtn.UseVisualStyleBackColor = false;
            this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
            // 
            // insertBtn
            // 
            this.insertBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.insertBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.insertBtn.Location = new System.Drawing.Point(6, 315);
            this.insertBtn.Name = "insertBtn";
            this.insertBtn.Size = new System.Drawing.Size(70, 26);
            this.insertBtn.TabIndex = 38;
            this.insertBtn.Text = "Insert";
            this.insertBtn.UseVisualStyleBackColor = false;
            this.insertBtn.Click += new System.EventHandler(this.insertBtn_Click);
            // 
            // lorryDGV
            // 
            this.lorryDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lorryDGV.Location = new System.Drawing.Point(6, 357);
            this.lorryDGV.Name = "lorryDGV";
            this.lorryDGV.RowHeadersWidth = 51;
            this.lorryDGV.RowTemplate.Height = 29;
            this.lorryDGV.Size = new System.Drawing.Size(311, 131);
            this.lorryDGV.TabIndex = 6;
            this.lorryDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.lorryDGV_CellContentClick);
            // 
            // lorryAssignedJobsDGV
            // 
            this.lorryAssignedJobsDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lorryAssignedJobsDGV.Location = new System.Drawing.Point(6, 209);
            this.lorryAssignedJobsDGV.Name = "lorryAssignedJobsDGV";
            this.lorryAssignedJobsDGV.RowHeadersWidth = 51;
            this.lorryAssignedJobsDGV.RowTemplate.Height = 29;
            this.lorryAssignedJobsDGV.Size = new System.Drawing.Size(311, 84);
            this.lorryAssignedJobsDGV.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(6, 186);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(139, 19);
            this.label5.TabIndex = 4;
            this.label5.Text = "Jobs Assigned for:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(6, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(157, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "Capacity(maxpower)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(6, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Plate Number";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(6, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Lorry ID";
            // 
            // ManageLorryAndContainer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "ManageLorryAndContainer";
            this.Size = new System.Drawing.Size(762, 619);
            this.Load += new System.EventHandler(this.ManageLorryAndContainer_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.containerDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.containerAssignedJobsDGV)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lorryDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lorryAssignedJobsDGV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox2;
        private TextBox dimensionTxt;
        private TextBox containerCapacityTxt;
        private TextBox containerIdTxt;
        private Button containerSearchBtn;
        private Button containerDeleteBtn;
        private Button containerUpdateBtn;
        private Button containerInsertBtn;
        private DataGridView containerDGV;
        private DataGridView containerAssignedJobsDGV;
        private Label label6;
        private Label label7;
        private Label label9;
        private Label label10;
        private GroupBox groupBox1;
        private TextBox capacityTxt;
        private TextBox plateNumberTxt;
        private TextBox lorryIDTxt;
        private Button searchBtn;
        private Button deleteBtn;
        private Button updateBtn;
        private Button insertBtn;
        private DataGridView lorryDGV;
        private DataGridView lorryAssignedJobsDGV;
        private Label label5;
        private Label label3;
        private Label label2;
        private Label label1;
    }
}
