﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace E_Shift
{
    public partial class ManageEmployees : UserControl
    {
        // connection string
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True";

        public ManageEmployees()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        public static string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void ManageEmployees_Load(object sender, EventArgs e)
        {
            LoadAssistants();
            LoadDrivers();
        }

        private void clearAll()
        {
            nameTxt.Clear();
            licenseNumberTxt.Clear();
            contactNumberTxt.Clear();
            driverIDTxt.Clear();
            driverPasswordTxt.Clear();
            assistantIDTxt.Clear();
            assistantNameTxt.Clear();
            nicTxt.Clear();
            assistantPasswordTxt.Clear();
            contactTxt.Clear();
        }

        private void insertBtn_Click(object sender, EventArgs e)
        {
            string name = nameTxt.Text.Trim();
            string licenseNumber = licenseNumberTxt.Text.Trim();
            string contactNumber = contactNumberTxt.Text.Trim();
            string password = driverPasswordTxt.Text;

            string hashedPassword = HashPassword(password);

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    // Insert into Driver table
                    string insertDriver = "INSERT INTO Driver (Name, LicenseNumber, ContactNumber) VALUES (@Name, @License, @Contact)";
                    SqlCommand cmdDriver = new SqlCommand(insertDriver, con);
                    cmdDriver.Parameters.AddWithValue("@Name", name);
                    cmdDriver.Parameters.AddWithValue("@License", licenseNumber);
                    cmdDriver.Parameters.AddWithValue("@Contact", contactNumber);

                    cmdDriver.ExecuteNonQuery();

                    // Insert into Users table
                    string insertUser = "INSERT INTO Users (Username, PasswordHash, Role) VALUES (@Username, @PasswordHash, 'Driver')";
                    SqlCommand cmdUser = new SqlCommand(insertUser, con);
                    cmdUser.Parameters.AddWithValue("@Username", licenseNumber);
                    cmdUser.Parameters.AddWithValue("@PasswordHash", hashedPassword);
                    cmdUser.ExecuteNonQuery();

                    MessageBox.Show("Driver inserted successfully.");
                    LoadDrivers();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Insert failed: " + ex.Message);
                }
                clearAll();
            }
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(driverIDTxt.Text, out int driverId))
            {
                MessageBox.Show("Invalid Driver ID.");
                return;
            }

            string name = nameTxt.Text.Trim();
            string licenseNumber = licenseNumberTxt.Text.Trim();
            string contactNumber = contactNumberTxt.Text.Trim();
            string password = driverPasswordTxt.Text;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    // Update Driver
                    string updateDriver = "UPDATE Driver SET Name = @Name, LicenseNumber = @License, ContactNumber = @Contact WHERE DriverID = @DriverID";
                    SqlCommand cmdDriver = new SqlCommand(updateDriver, con);
                    cmdDriver.Parameters.AddWithValue("@Name", name);
                    cmdDriver.Parameters.AddWithValue("@License", licenseNumber);
                    cmdDriver.Parameters.AddWithValue("@Contact", contactNumber);
                    cmdDriver.Parameters.AddWithValue("@DriverID", driverId);

                    cmdDriver.ExecuteNonQuery();

                    // Optional: Update password if not empty
                    if (!string.IsNullOrEmpty(password))
                    {
                        string hashedPassword = HashPassword(password);
                        string updateUser = "UPDATE Users SET PasswordHash = @PasswordHash WHERE Username = @Username AND Role = 'Driver'";
                        SqlCommand cmdUser = new SqlCommand(updateUser, con);
                        cmdUser.Parameters.AddWithValue("@PasswordHash", hashedPassword);
                        cmdUser.Parameters.AddWithValue("@Username", licenseNumber);
                        cmdUser.ExecuteNonQuery();
                    }

                    MessageBox.Show("Driver updated successfully.");
                    LoadDrivers();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Update failed: " + ex.Message);
                }
                clearAll();
            }
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(driverIDTxt.Text, out int driverId))
            {
                MessageBox.Show("Invalid Driver ID.");
                return;
            }

            string licenseNumber = licenseNumberTxt.Text.Trim();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    // Delete from Driver table
                    string deleteDriver = "DELETE FROM Driver WHERE DriverID = @DriverID";
                    SqlCommand cmdDriver = new SqlCommand(deleteDriver, con);
                    cmdDriver.Parameters.AddWithValue("@DriverID", driverId);
                    cmdDriver.ExecuteNonQuery();

                    // Delete from Users table
                    string deleteUser = "DELETE FROM Users WHERE Username = @Username AND Role = 'Driver'";
                    SqlCommand cmdUser = new SqlCommand(deleteUser, con);
                    cmdUser.Parameters.AddWithValue("@Username", licenseNumber);
                    cmdUser.ExecuteNonQuery();

                    MessageBox.Show("Driver deleted.");
                    LoadDrivers();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Delete failed: " + ex.Message);
                }
                clearAll();
            }
        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(driverIDTxt.Text, out int driverId))
            {
                MessageBox.Show("Invalid Driver ID.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    string query = "SELECT * FROM Driver WHERE DriverID = @DriverID";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@DriverID", driverId);
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        nameTxt.Text = reader["Name"].ToString();
                        licenseNumberTxt.Text = reader["LicenseNumber"].ToString();
                        contactNumberTxt.Text = reader["ContactNumber"].ToString();
                        
                        LoadAssignedJobs("Driver", driverId);
                    }
                    else
                    {
                        MessageBox.Show("Driver not found.");
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Search failed: " + ex.Message);
                }
            }
        }

        private void LoadAssignedJobs(string role, int id)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    string query = "";

                    if (role.Equals("Driver", StringComparison.OrdinalIgnoreCase))
                    {
                        query = @"SELECT l.LoadID, l.Description, l.TransportUnitID, l.JobID
                          FROM Load l
                          INNER JOIN TransportUnit t ON l.TransportUnitID = t.TransportUnitID
                          WHERE t.DriverID = @ID";
                    }
                    else if (role.Equals("Assistant", StringComparison.OrdinalIgnoreCase))
                    {
                        query = @"SELECT l.LoadID, l.Description, l.TransportUnitID, l.JobID
                          FROM Load l
                          INNER JOIN TransportUnit t ON l.TransportUnitID = t.TransportUnitID
                          WHERE t.AssistantID = @ID";
                    }
                    else
                    {
                        MessageBox.Show("Invalid role.");
                        return;
                    }

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@ID", id);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    if (role == "Driver")
                    {
                        assignedLoadsForDriverView.DataSource = dt;
                    }
                    else if (role == "Assistant")
                    {
                        assignedLoadsForAssistantView.DataSource = dt;
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Failed to load assigned jobs: " + ex.Message);
                }
            }
        }


        private void LoadDrivers()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Driver";
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                viewDriverDGV.DataSource = dt;
            }
        }

        private void assistantInsertBtn_Click(object sender, EventArgs e)
        {
            string name = assistantNameTxt.Text.Trim();
            string nic = nicTxt.Text.Trim();
            string contact = contactTxt.Text.Trim();
            string password = assistantPasswordTxt.Text;

            string hashedPassword = HashPassword(password);

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    // Insert into Assistant table
                    string insertAssistant = "INSERT INTO Assistant (Name, NIC, ContactNumber) VALUES (@Name, @NIC, @Contact)";
                    SqlCommand cmdAssistant = new SqlCommand(insertAssistant, con);
                    cmdAssistant.Parameters.AddWithValue("@Name", name);
                    cmdAssistant.Parameters.AddWithValue("@NIC", nic);
                    cmdAssistant.Parameters.AddWithValue("@Contact", contact);

                    cmdAssistant.ExecuteNonQuery();

                    // Insert into Users table
                    string insertUser = "INSERT INTO Users (Username, PasswordHash, Role) VALUES (@Username, @PasswordHash, 'Assistant')";
                    SqlCommand cmdUser = new SqlCommand(insertUser, con);
                    cmdUser.Parameters.AddWithValue("@Username", nic);
                    cmdUser.Parameters.AddWithValue("@PasswordHash", hashedPassword);
                    cmdUser.ExecuteNonQuery();

                    MessageBox.Show("Assistant inserted successfully.");
                    LoadAssistants();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Insert failed: " + ex.Message);
                }
                clearAll();
            }
        }

        private void assistantUpdateBtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(assistantIDTxt.Text, out int assistantId))
            {
                MessageBox.Show("Invalid Assistant ID.");
                return;
            }

            string name = nameTxt.Text.Trim();
            string nic = nicTxt.Text.Trim();
            string contact = contactTxt.Text.Trim();
            string password = assistantPasswordTxt.Text;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    // Update Assistant
                    string updateAssistant = "UPDATE Assistant SET Name = @Name, NIC = @NIC, ContactNumber = @Contact WHERE AssistantID = @AssistantID";
                    SqlCommand cmdAssistant = new SqlCommand(updateAssistant, con);
                    cmdAssistant.Parameters.AddWithValue("@Name", name);
                    cmdAssistant.Parameters.AddWithValue("@NIC", nic);
                    cmdAssistant.Parameters.AddWithValue("@Contact", contact);
                    cmdAssistant.Parameters.AddWithValue("@AssistantID", assistantId);

                    cmdAssistant.ExecuteNonQuery();

                    // Update password only if provided
                    if (!string.IsNullOrEmpty(password))
                    {
                        string hashedPassword = HashPassword(password);
                        string updateUser = "UPDATE Users SET PasswordHash = @PasswordHash WHERE Username = @Username AND Role = 'Assistant'";
                        SqlCommand cmdUser = new SqlCommand(updateUser, con);
                        cmdUser.Parameters.AddWithValue("@PasswordHash", hashedPassword);
                        cmdUser.Parameters.AddWithValue("@Username", nic);
                        cmdUser.ExecuteNonQuery();
                    }

                    MessageBox.Show("Assistant updated successfully.");
                    LoadAssistants();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Update failed: " + ex.Message);
                }
                clearAll();
            }
        }

        private void assistantDeleteBtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(assistantIDTxt.Text, out int assistantId))
            {
                MessageBox.Show("Invalid Assistant ID.");
                return;
            }

            string nic = nicTxt.Text.Trim();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    // Delete Assistant
                    string deleteAssistant = "DELETE FROM Assistant WHERE AssistantID = @AssistantID";
                    SqlCommand cmdAssistant = new SqlCommand(deleteAssistant, con);
                    cmdAssistant.Parameters.AddWithValue("@AssistantID", assistantId);
                    cmdAssistant.ExecuteNonQuery();

                    // Delete from Users
                    string deleteUser = "DELETE FROM Users WHERE Username = @Username AND Role = 'Assistant'";
                    SqlCommand cmdUser = new SqlCommand(deleteUser, con);
                    cmdUser.Parameters.AddWithValue("@Username", nic);
                    cmdUser.ExecuteNonQuery();

                    MessageBox.Show("Assistant deleted.");
                    LoadAssistants();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Delete failed: " + ex.Message);
                }
                clearAll();
            }
        }

        private void assistantSearchBtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(assistantIDTxt.Text, out int assistantId))
            {
                MessageBox.Show("Invalid Assistant ID.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    string query = "SELECT * FROM Assistant WHERE AssistantID = @AssistantID";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@AssistantID", assistantId);

                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        nameTxt.Text = reader["Name"].ToString();
                        nicTxt.Text = reader["NIC"].ToString();
                        contactTxt.Text = reader["ContactNumber"].ToString();

                        LoadAssignedJobs("Assistant", assistantId);
                    }
                    else
                    {
                        MessageBox.Show("Assistant not found.");
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Search failed: " + ex.Message);
                }
            }
        }
        private void LoadAssistants()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Assistant";
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                viewAssistantDGV.DataSource = dt;
            }
        }

        private void viewDriverDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Make sure the click is on a valid row
            {
                DataGridViewRow row = viewDriverDGV.Rows[e.RowIndex];

                // Load data from the clicked row into input fields
                driverIDTxt.Text = row.Cells["DriverID"].Value?.ToString();
                nameTxt.Text = row.Cells["Name"].Value.ToString();
                licenseNumberTxt.Text = row.Cells["LicenseNumber"].Value.ToString();
                contactNumberTxt.Text = row.Cells["ContactNumber"].Value.ToString();

                int driverID = int.Parse(driverIDTxt.Text);

                LoadAssignedJobs("Driver", driverID);
            }
        }

        private void viewAssistantDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Make sure the click is on a valid row
            {
                DataGridViewRow row = viewAssistantDGV.Rows[e.RowIndex];

                // Load data from the clicked row into input fields
                assistantIDTxt.Text = row.Cells["AssistantID"].Value?.ToString();
                assistantNameTxt.Text = row.Cells["Name"].Value.ToString();
                nicTxt.Text = row.Cells["NIC"].Value.ToString();
                contactTxt.Text = row.Cells["ContactNumber"].Value.ToString();

                int assistantID = int.Parse(assistantIDTxt.Text);

                LoadAssignedJobs("Assistant", assistantID);
            }
        }
    }
}
