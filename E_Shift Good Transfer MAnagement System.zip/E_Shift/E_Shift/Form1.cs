namespace E_Shift
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Start the timer when form loads
            loadTimer.Start();
        }

        private void loadTimer_Tick(object sender, EventArgs e)
        {
            loadLoginPage.Value += 5;

            if (loadLoginPage.Value >= 100)
            {
                loadTimer.Stop();

                login loginForm = new login();
                loginForm.Show();
                this.Hide();
            }
        }
    }
}