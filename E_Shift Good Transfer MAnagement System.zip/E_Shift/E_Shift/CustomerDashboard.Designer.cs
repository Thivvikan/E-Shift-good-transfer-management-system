﻿namespace E_Shift
{
    partial class CustomerDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerDashboard));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.enquiryBtn = new System.Windows.Forms.Button();
            this.logoutBtn = new System.Windows.Forms.Button();
            this.feedbackBtn = new System.Windows.Forms.Button();
            this.topBar = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.manageJobsBtn = new System.Windows.Forms.Button();
            this.dashboardBtn = new System.Windows.Forms.Button();
            this.sidebar = new System.Windows.Forms.Panel();
            this.manageProfileBtn = new System.Windows.Forms.Button();
            this.mainContentArea = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.topBar.SuspendLayout();
            this.sidebar.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(677, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(89, 68);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Image = global::E_Shift.Properties.Resources.Screenshot_2025_07_23_161129;
            this.pictureBox1.Location = new System.Drawing.Point(6, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(86, 62);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // enquiryBtn
            // 
            this.enquiryBtn.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.enquiryBtn.Location = new System.Drawing.Point(12, 196);
            this.enquiryBtn.Name = "enquiryBtn";
            this.enquiryBtn.Size = new System.Drawing.Size(189, 34);
            this.enquiryBtn.TabIndex = 10;
            this.enquiryBtn.Text = "Enquiry";
            this.enquiryBtn.UseVisualStyleBackColor = true;
            this.enquiryBtn.Click += new System.EventHandler(this.enquiryBtn_Click);
            // 
            // logoutBtn
            // 
            this.logoutBtn.BackColor = System.Drawing.Color.Red;
            this.logoutBtn.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.logoutBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.logoutBtn.Location = new System.Drawing.Point(12, 326);
            this.logoutBtn.Name = "logoutBtn";
            this.logoutBtn.Size = new System.Drawing.Size(189, 34);
            this.logoutBtn.TabIndex = 9;
            this.logoutBtn.Text = "Logout";
            this.logoutBtn.UseVisualStyleBackColor = false;
            this.logoutBtn.Click += new System.EventHandler(this.logoutBtn_Click);
            // 
            // feedbackBtn
            // 
            this.feedbackBtn.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.feedbackBtn.Location = new System.Drawing.Point(12, 263);
            this.feedbackBtn.Name = "feedbackBtn";
            this.feedbackBtn.Size = new System.Drawing.Size(189, 34);
            this.feedbackBtn.TabIndex = 6;
            this.feedbackBtn.Text = "Feedback";
            this.feedbackBtn.UseVisualStyleBackColor = true;
            this.feedbackBtn.Click += new System.EventHandler(this.feedbackBtn_Click);
            // 
            // topBar
            // 
            this.topBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.topBar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("topBar.BackgroundImage")));
            this.topBar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.topBar.Controls.Add(this.pictureBox2);
            this.topBar.Controls.Add(this.label1);
            this.topBar.Controls.Add(this.pictureBox1);
            this.topBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.topBar.Location = new System.Drawing.Point(218, 0);
            this.topBar.Name = "topBar";
            this.topBar.Size = new System.Drawing.Size(770, 77);
            this.topBar.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Sylfaen", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Brown;
            this.label1.Location = new System.Drawing.Point(161, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(386, 39);
            this.label1.TabIndex = 1;
            this.label1.Text = "Welcome Back to E-Shift...";
            // 
            // manageJobsBtn
            // 
            this.manageJobsBtn.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.manageJobsBtn.Location = new System.Drawing.Point(12, 71);
            this.manageJobsBtn.Name = "manageJobsBtn";
            this.manageJobsBtn.Size = new System.Drawing.Size(189, 34);
            this.manageJobsBtn.TabIndex = 2;
            this.manageJobsBtn.Text = "Manage Jobs";
            this.manageJobsBtn.UseVisualStyleBackColor = true;
            this.manageJobsBtn.Click += new System.EventHandler(this.manageJobsBtn_Click);
            // 
            // dashboardBtn
            // 
            this.dashboardBtn.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dashboardBtn.Location = new System.Drawing.Point(12, 11);
            this.dashboardBtn.Name = "dashboardBtn";
            this.dashboardBtn.Size = new System.Drawing.Size(189, 34);
            this.dashboardBtn.TabIndex = 0;
            this.dashboardBtn.Text = "Dashboard";
            this.dashboardBtn.UseVisualStyleBackColor = true;
            this.dashboardBtn.Click += new System.EventHandler(this.dashboardBtn_Click);
            // 
            // sidebar
            // 
            this.sidebar.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.sidebar.BackgroundImage = global::E_Shift.Properties.Resources.R;
            this.sidebar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sidebar.Controls.Add(this.enquiryBtn);
            this.sidebar.Controls.Add(this.logoutBtn);
            this.sidebar.Controls.Add(this.feedbackBtn);
            this.sidebar.Controls.Add(this.manageJobsBtn);
            this.sidebar.Controls.Add(this.manageProfileBtn);
            this.sidebar.Controls.Add(this.dashboardBtn);
            this.sidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidebar.Location = new System.Drawing.Point(0, 0);
            this.sidebar.Name = "sidebar";
            this.sidebar.Size = new System.Drawing.Size(218, 583);
            this.sidebar.TabIndex = 3;
            // 
            // manageProfileBtn
            // 
            this.manageProfileBtn.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.manageProfileBtn.Location = new System.Drawing.Point(12, 132);
            this.manageProfileBtn.Name = "manageProfileBtn";
            this.manageProfileBtn.Size = new System.Drawing.Size(189, 34);
            this.manageProfileBtn.TabIndex = 1;
            this.manageProfileBtn.Text = "Manage Profile";
            this.manageProfileBtn.UseVisualStyleBackColor = true;
            this.manageProfileBtn.Click += new System.EventHandler(this.manageProfileBtn_Click);
            // 
            // mainContentArea
            // 
            this.mainContentArea.BackgroundImage = global::E_Shift.Properties.Resources.M;
            this.mainContentArea.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.mainContentArea.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainContentArea.Location = new System.Drawing.Point(218, 77);
            this.mainContentArea.Name = "mainContentArea";
            this.mainContentArea.Size = new System.Drawing.Size(770, 506);
            this.mainContentArea.TabIndex = 3;
            this.mainContentArea.Paint += new System.Windows.Forms.PaintEventHandler(this.mainContentArea_Paint);
            // 
            // CustomerDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(988, 583);
            this.Controls.Add(this.mainContentArea);
            this.Controls.Add(this.topBar);
            this.Controls.Add(this.sidebar);
            this.Name = "CustomerDashboard";
            this.Text = "CustomerDashboard";
            this.Load += new System.EventHandler(this.CustomerDashboard_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.topBar.ResumeLayout(false);
            this.topBar.PerformLayout();
            this.sidebar.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private Button enquiryBtn;
        private Button logoutBtn;
        private Button feedbackBtn;
        private Panel topBar;
        private Label label1;
        private Button manageJobsBtn;
        private Button dashboardBtn;
        private Panel sidebar;
        private Button manageProfileBtn;
        private Panel mainContentArea;
    }
}