﻿namespace E_Shift
{
    partial class ManageEmployees
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.driverPasswordTxt = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.contactNumberTxt = new System.Windows.Forms.TextBox();
            this.licenseNumberTxt = new System.Windows.Forms.TextBox();
            this.nameTxt = new System.Windows.Forms.TextBox();
            this.driverIDTxt = new System.Windows.Forms.TextBox();
            this.searchBtn = new System.Windows.Forms.Button();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.updateBtn = new System.Windows.Forms.Button();
            this.insertBtn = new System.Windows.Forms.Button();
            this.viewDriverDGV = new System.Windows.Forms.DataGridView();
            this.assignedLoadsForDriverView = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.nicTxt = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.assistantPasswordTxt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.contactTxt = new System.Windows.Forms.TextBox();
            this.assistantNameTxt = new System.Windows.Forms.TextBox();
            this.assistantIDTxt = new System.Windows.Forms.TextBox();
            this.assistantSearchBtn = new System.Windows.Forms.Button();
            this.assistantDeleteBtn = new System.Windows.Forms.Button();
            this.assistantUpdateBtn = new System.Windows.Forms.Button();
            this.assistantInsertBtn = new System.Windows.Forms.Button();
            this.viewAssistantDGV = new System.Windows.Forms.DataGridView();
            this.assignedLoadsForAssistantView = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.viewDriverDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assignedLoadsForDriverView)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.viewAssistantDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assignedLoadsForAssistantView)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.driverPasswordTxt);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.contactNumberTxt);
            this.groupBox1.Controls.Add(this.licenseNumberTxt);
            this.groupBox1.Controls.Add(this.nameTxt);
            this.groupBox1.Controls.Add(this.driverIDTxt);
            this.groupBox1.Controls.Add(this.searchBtn);
            this.groupBox1.Controls.Add(this.deleteBtn);
            this.groupBox1.Controls.Add(this.updateBtn);
            this.groupBox1.Controls.Add(this.insertBtn);
            this.groupBox1.Controls.Add(this.viewDriverDGV);
            this.groupBox1.Controls.Add(this.assignedLoadsForDriverView);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(352, 562);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Manage Driver";
            // 
            // driverPasswordTxt
            // 
            this.driverPasswordTxt.Location = new System.Drawing.Point(158, 226);
            this.driverPasswordTxt.Name = "driverPasswordTxt";
            this.driverPasswordTxt.Size = new System.Drawing.Size(146, 30);
            this.driverPasswordTxt.TabIndex = 64;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 229);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(86, 22);
            this.label11.TabIndex = 63;
            this.label11.Text = "Password";
            // 
            // contactNumberTxt
            // 
            this.contactNumberTxt.Location = new System.Drawing.Point(158, 179);
            this.contactNumberTxt.Name = "contactNumberTxt";
            this.contactNumberTxt.Size = new System.Drawing.Size(146, 30);
            this.contactNumberTxt.TabIndex = 45;
            // 
            // licenseNumberTxt
            // 
            this.licenseNumberTxt.Location = new System.Drawing.Point(158, 132);
            this.licenseNumberTxt.Name = "licenseNumberTxt";
            this.licenseNumberTxt.Size = new System.Drawing.Size(146, 30);
            this.licenseNumberTxt.TabIndex = 44;
            // 
            // nameTxt
            // 
            this.nameTxt.Location = new System.Drawing.Point(158, 83);
            this.nameTxt.Name = "nameTxt";
            this.nameTxt.Size = new System.Drawing.Size(146, 30);
            this.nameTxt.TabIndex = 43;
            // 
            // driverIDTxt
            // 
            this.driverIDTxt.Location = new System.Drawing.Point(158, 36);
            this.driverIDTxt.Name = "driverIDTxt";
            this.driverIDTxt.PlaceholderText = "Auto assigned";
            this.driverIDTxt.Size = new System.Drawing.Size(146, 30);
            this.driverIDTxt.TabIndex = 42;
            // 
            // searchBtn
            // 
            this.searchBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.searchBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.searchBtn.Location = new System.Drawing.Point(246, 413);
            this.searchBtn.Name = "searchBtn";
            this.searchBtn.Size = new System.Drawing.Size(70, 26);
            this.searchBtn.TabIndex = 41;
            this.searchBtn.Text = "Search";
            this.searchBtn.UseVisualStyleBackColor = false;
            this.searchBtn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // deleteBtn
            // 
            this.deleteBtn.BackColor = System.Drawing.Color.Red;
            this.deleteBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.deleteBtn.Location = new System.Drawing.Point(168, 413);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(70, 26);
            this.deleteBtn.TabIndex = 40;
            this.deleteBtn.Text = "Delete";
            this.deleteBtn.UseVisualStyleBackColor = false;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // updateBtn
            // 
            this.updateBtn.BackColor = System.Drawing.Color.Yellow;
            this.updateBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.updateBtn.Location = new System.Drawing.Point(90, 413);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(70, 26);
            this.updateBtn.TabIndex = 39;
            this.updateBtn.Text = "Update";
            this.updateBtn.UseVisualStyleBackColor = false;
            this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
            // 
            // insertBtn
            // 
            this.insertBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.insertBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.insertBtn.Location = new System.Drawing.Point(10, 413);
            this.insertBtn.Name = "insertBtn";
            this.insertBtn.Size = new System.Drawing.Size(70, 26);
            this.insertBtn.TabIndex = 38;
            this.insertBtn.Text = "Insert";
            this.insertBtn.UseVisualStyleBackColor = false;
            this.insertBtn.Click += new System.EventHandler(this.insertBtn_Click);
            // 
            // viewDriverDGV
            // 
            this.viewDriverDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.viewDriverDGV.Location = new System.Drawing.Point(6, 445);
            this.viewDriverDGV.Name = "viewDriverDGV";
            this.viewDriverDGV.RowHeadersWidth = 51;
            this.viewDriverDGV.RowTemplate.Height = 29;
            this.viewDriverDGV.Size = new System.Drawing.Size(311, 111);
            this.viewDriverDGV.TabIndex = 6;
            this.viewDriverDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.viewDriverDGV_CellContentClick);
            // 
            // assignedLoadsForDriverView
            // 
            this.assignedLoadsForDriverView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.assignedLoadsForDriverView.Location = new System.Drawing.Point(6, 310);
            this.assignedLoadsForDriverView.Name = "assignedLoadsForDriverView";
            this.assignedLoadsForDriverView.RowHeadersWidth = 51;
            this.assignedLoadsForDriverView.RowTemplate.Height = 29;
            this.assignedLoadsForDriverView.Size = new System.Drawing.Size(311, 84);
            this.assignedLoadsForDriverView.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(6, 287);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(150, 19);
            this.label5.TabIndex = 4;
            this.label5.Text = "Loads Assigned for:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(6, 182);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "Contact Number";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(6, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "License Number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(6, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(6, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Driver ID";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.nicTxt);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.assistantPasswordTxt);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.contactTxt);
            this.groupBox2.Controls.Add(this.assistantNameTxt);
            this.groupBox2.Controls.Add(this.assistantIDTxt);
            this.groupBox2.Controls.Add(this.assistantSearchBtn);
            this.groupBox2.Controls.Add(this.assistantDeleteBtn);
            this.groupBox2.Controls.Add(this.assistantUpdateBtn);
            this.groupBox2.Controls.Add(this.assistantInsertBtn);
            this.groupBox2.Controls.Add(this.viewAssistantDGV);
            this.groupBox2.Controls.Add(this.assignedLoadsForAssistantView);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(386, -1);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(358, 562);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Manage Assistant";
            // 
            // nicTxt
            // 
            this.nicTxt.Location = new System.Drawing.Point(174, 130);
            this.nicTxt.Name = "nicTxt";
            this.nicTxt.Size = new System.Drawing.Size(146, 30);
            this.nicTxt.TabIndex = 64;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(22, 133);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(98, 19);
            this.label12.TabIndex = 63;
            this.label12.Text = "NIC Number";
            // 
            // assistantPasswordTxt
            // 
            this.assistantPasswordTxt.Location = new System.Drawing.Point(174, 227);
            this.assistantPasswordTxt.Name = "assistantPasswordTxt";
            this.assistantPasswordTxt.Size = new System.Drawing.Size(146, 30);
            this.assistantPasswordTxt.TabIndex = 62;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(22, 230);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 22);
            this.label8.TabIndex = 61;
            this.label8.Text = "Password";
            // 
            // contactTxt
            // 
            this.contactTxt.Location = new System.Drawing.Point(174, 171);
            this.contactTxt.Name = "contactTxt";
            this.contactTxt.Size = new System.Drawing.Size(146, 30);
            this.contactTxt.TabIndex = 60;
            // 
            // assistantNameTxt
            // 
            this.assistantNameTxt.Location = new System.Drawing.Point(174, 80);
            this.assistantNameTxt.Name = "assistantNameTxt";
            this.assistantNameTxt.Size = new System.Drawing.Size(146, 30);
            this.assistantNameTxt.TabIndex = 58;
            // 
            // assistantIDTxt
            // 
            this.assistantIDTxt.Location = new System.Drawing.Point(174, 33);
            this.assistantIDTxt.Name = "assistantIDTxt";
            this.assistantIDTxt.PlaceholderText = "Auto assigned";
            this.assistantIDTxt.Size = new System.Drawing.Size(146, 30);
            this.assistantIDTxt.TabIndex = 57;
            // 
            // assistantSearchBtn
            // 
            this.assistantSearchBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.assistantSearchBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.assistantSearchBtn.Location = new System.Drawing.Point(260, 410);
            this.assistantSearchBtn.Name = "assistantSearchBtn";
            this.assistantSearchBtn.Size = new System.Drawing.Size(70, 26);
            this.assistantSearchBtn.TabIndex = 56;
            this.assistantSearchBtn.Text = "Search";
            this.assistantSearchBtn.UseVisualStyleBackColor = false;
            this.assistantSearchBtn.Click += new System.EventHandler(this.assistantSearchBtn_Click);
            // 
            // assistantDeleteBtn
            // 
            this.assistantDeleteBtn.BackColor = System.Drawing.Color.Red;
            this.assistantDeleteBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.assistantDeleteBtn.Location = new System.Drawing.Point(178, 410);
            this.assistantDeleteBtn.Name = "assistantDeleteBtn";
            this.assistantDeleteBtn.Size = new System.Drawing.Size(70, 26);
            this.assistantDeleteBtn.TabIndex = 55;
            this.assistantDeleteBtn.Text = "Delete";
            this.assistantDeleteBtn.UseVisualStyleBackColor = false;
            this.assistantDeleteBtn.Click += new System.EventHandler(this.assistantDeleteBtn_Click);
            // 
            // assistantUpdateBtn
            // 
            this.assistantUpdateBtn.BackColor = System.Drawing.Color.Yellow;
            this.assistantUpdateBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.assistantUpdateBtn.Location = new System.Drawing.Point(101, 410);
            this.assistantUpdateBtn.Name = "assistantUpdateBtn";
            this.assistantUpdateBtn.Size = new System.Drawing.Size(70, 26);
            this.assistantUpdateBtn.TabIndex = 54;
            this.assistantUpdateBtn.Text = "Update";
            this.assistantUpdateBtn.UseVisualStyleBackColor = false;
            this.assistantUpdateBtn.Click += new System.EventHandler(this.assistantUpdateBtn_Click);
            // 
            // assistantInsertBtn
            // 
            this.assistantInsertBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.assistantInsertBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.assistantInsertBtn.Location = new System.Drawing.Point(22, 410);
            this.assistantInsertBtn.Name = "assistantInsertBtn";
            this.assistantInsertBtn.Size = new System.Drawing.Size(70, 26);
            this.assistantInsertBtn.TabIndex = 53;
            this.assistantInsertBtn.Text = "Insert";
            this.assistantInsertBtn.UseVisualStyleBackColor = false;
            this.assistantInsertBtn.Click += new System.EventHandler(this.assistantInsertBtn_Click);
            // 
            // viewAssistantDGV
            // 
            this.viewAssistantDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.viewAssistantDGV.Location = new System.Drawing.Point(22, 446);
            this.viewAssistantDGV.Name = "viewAssistantDGV";
            this.viewAssistantDGV.RowHeadersWidth = 51;
            this.viewAssistantDGV.RowTemplate.Height = 29;
            this.viewAssistantDGV.Size = new System.Drawing.Size(311, 107);
            this.viewAssistantDGV.TabIndex = 52;
            this.viewAssistantDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.viewAssistantDGV_CellContentClick);
            // 
            // assignedLoadsForAssistantView
            // 
            this.assignedLoadsForAssistantView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.assignedLoadsForAssistantView.Location = new System.Drawing.Point(22, 311);
            this.assignedLoadsForAssistantView.Name = "assignedLoadsForAssistantView";
            this.assignedLoadsForAssistantView.RowHeadersWidth = 51;
            this.assignedLoadsForAssistantView.RowTemplate.Height = 29;
            this.assignedLoadsForAssistantView.Size = new System.Drawing.Size(311, 84);
            this.assignedLoadsForAssistantView.TabIndex = 51;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 288);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(167, 22);
            this.label6.TabIndex = 50;
            this.label6.Text = "Loads Assigned for:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(22, 174);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(147, 22);
            this.label7.TabIndex = 49;
            this.label7.Text = "Contact Number";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(22, 83);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 22);
            this.label9.TabIndex = 47;
            this.label9.Text = "Name";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(22, 36);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(108, 22);
            this.label10.TabIndex = 46;
            this.label10.Text = "Assistant ID";
            // 
            // ManageEmployees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "ManageEmployees";
            this.Size = new System.Drawing.Size(810, 562);
            this.Load += new System.EventHandler(this.ManageEmployees_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.viewDriverDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assignedLoadsForDriverView)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.viewAssistantDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assignedLoadsForAssistantView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox1;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private GroupBox groupBox2;
        private DataGridView viewDriverDGV;
        private DataGridView assignedLoadsForDriverView;
        private TextBox contactNumberTxt;
        private TextBox licenseNumberTxt;
        private TextBox nameTxt;
        private TextBox driverIDTxt;
        private Button searchBtn;
        private Button deleteBtn;
        private Button updateBtn;
        private Button insertBtn;
        private TextBox contactTxt;
        private TextBox assistantNameTxt;
        private TextBox assistantIDTxt;
        private Button assistantSearchBtn;
        private Button assistantDeleteBtn;
        private Button assistantUpdateBtn;
        private Button assistantInsertBtn;
        private DataGridView viewAssistantDGV;
        private DataGridView assignedLoadsForAssistantView;
        private Label label6;
        private Label label7;
        private Label label9;
        private Label label10;
        private TextBox driverPasswordTxt;
        private Label label11;
        private TextBox assistantPasswordTxt;
        private Label label8;
        private TextBox nicTxt;
        private Label label12;
    }
}
