﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace E_Shift
{
    public partial class CustomerGiveFeedbacks : UserControl
    {
        // connection string
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True";

        public CustomerGiveFeedbacks()
        {
            InitializeComponent();
        }

        private void sendBtn_Click(object sender, EventArgs e)
        {
            string feedback = feedbackTxt.Text.Trim();
            int jobId = int.Parse(jobIDTxt.Text);

            if (string.IsNullOrWhiteSpace(feedback))
            {
                MessageBox.Show("Please enter your feedback.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "INSERT INTO Feedback (JobID, Feedback) VALUES (@JobID, @Feedback)";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@JobID", jobId);
                    cmd.Parameters.AddWithValue("@Feedback", feedback);

                    int result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        MessageBox.Show("Thank you for your feedback!");
                        feedbackTxt.Clear();
                    }
                    else
                    {
                        MessageBox.Show("Failed to send feedback.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error submitting feedback: " + ex.Message);
                }
            }
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            // Get reference to the parent form
            CustomerDashboard dashboardForm = this.FindForm() as CustomerDashboard;

            if (dashboardForm != null)
            {
                // Create a new instance of the dashboard user control
                DefaultCustomerDashboard dashboardUC = new DefaultCustomerDashboard();

                // Load the dashboard user control into the main panel
                dashboardForm.CustomerLoadUserControl(dashboardUC);
            }
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            jobIDTxt.Clear();
            feedbackTxt.Clear();
        }
    }
}
