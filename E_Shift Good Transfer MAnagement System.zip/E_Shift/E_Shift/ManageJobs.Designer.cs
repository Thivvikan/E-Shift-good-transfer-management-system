﻿namespace E_Shift
{
    partial class ManageJobs
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.jobIdTxt = new System.Windows.Forms.TextBox();
            this.customerIdTxt = new System.Windows.Forms.TextBox();
            this.startLocationTxt = new System.Windows.Forms.TextBox();
            this.destinationTxt = new System.Windows.Forms.TextBox();
            this.jobDateAndTimeDTP = new System.Windows.Forms.DateTimePicker();
            this.viewJobsDGV = new System.Windows.Forms.DataGridView();
            this.label10 = new System.Windows.Forms.Label();
            this.loadsOfTheJobDGV = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.updateBtn = new System.Windows.Forms.Button();
            this.statusCB = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.viewJobsDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loadsOfTheJobDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(17, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Job ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(17, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "Customer ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(17, 176);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 19);
            this.label3.TabIndex = 3;
            this.label3.Text = "Start Location";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(17, 237);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 19);
            this.label4.TabIndex = 4;
            this.label4.Text = "Destination";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(17, 297);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(116, 19);
            this.label5.TabIndex = 5;
            this.label5.Text = "Job Date & Time";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(17, 356);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 19);
            this.label6.TabIndex = 6;
            this.label6.Text = "Status";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Sylfaen", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label7.Location = new System.Drawing.Point(264, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(172, 36);
            this.label7.TabIndex = 7;
            this.label7.Text = "Manage Jobs";
            // 
            // jobIdTxt
            // 
            this.jobIdTxt.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.jobIdTxt.Location = new System.Drawing.Point(162, 49);
            this.jobIdTxt.Name = "jobIdTxt";
            this.jobIdTxt.Size = new System.Drawing.Size(206, 27);
            this.jobIdTxt.TabIndex = 8;
            // 
            // customerIdTxt
            // 
            this.customerIdTxt.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.customerIdTxt.Location = new System.Drawing.Point(162, 106);
            this.customerIdTxt.Name = "customerIdTxt";
            this.customerIdTxt.Size = new System.Drawing.Size(206, 27);
            this.customerIdTxt.TabIndex = 9;
            // 
            // startLocationTxt
            // 
            this.startLocationTxt.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.startLocationTxt.Location = new System.Drawing.Point(162, 173);
            this.startLocationTxt.Name = "startLocationTxt";
            this.startLocationTxt.Size = new System.Drawing.Size(206, 27);
            this.startLocationTxt.TabIndex = 10;
            // 
            // destinationTxt
            // 
            this.destinationTxt.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.destinationTxt.Location = new System.Drawing.Point(162, 234);
            this.destinationTxt.Name = "destinationTxt";
            this.destinationTxt.Size = new System.Drawing.Size(206, 27);
            this.destinationTxt.TabIndex = 11;
            // 
            // jobDateAndTimeDTP
            // 
            this.jobDateAndTimeDTP.CustomFormat = " dd, MM, yyyy hh:mm tt";
            this.jobDateAndTimeDTP.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.jobDateAndTimeDTP.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.jobDateAndTimeDTP.Location = new System.Drawing.Point(162, 292);
            this.jobDateAndTimeDTP.Name = "jobDateAndTimeDTP";
            this.jobDateAndTimeDTP.Size = new System.Drawing.Size(206, 27);
            this.jobDateAndTimeDTP.TabIndex = 14;
            // 
            // viewJobsDGV
            // 
            this.viewJobsDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.viewJobsDGV.Location = new System.Drawing.Point(3, 400);
            this.viewJobsDGV.Name = "viewJobsDGV";
            this.viewJobsDGV.RowHeadersWidth = 51;
            this.viewJobsDGV.RowTemplate.Height = 29;
            this.viewJobsDGV.Size = new System.Drawing.Size(729, 157);
            this.viewJobsDGV.TabIndex = 19;
            this.viewJobsDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.viewJobsDGV_CellContentClick);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(385, 51);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(138, 19);
            this.label10.TabIndex = 20;
            this.label10.Text = "Loads for the Job:";
            // 
            // loadsOfTheJobDGV
            // 
            this.loadsOfTheJobDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.loadsOfTheJobDGV.Location = new System.Drawing.Point(395, 73);
            this.loadsOfTheJobDGV.Name = "loadsOfTheJobDGV";
            this.loadsOfTheJobDGV.RowHeadersWidth = 51;
            this.loadsOfTheJobDGV.RowTemplate.Height = 29;
            this.loadsOfTheJobDGV.Size = new System.Drawing.Size(337, 188);
            this.loadsOfTheJobDGV.TabIndex = 21;
            this.loadsOfTheJobDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.loadsOfTheJobDGV_CellContentClick);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button1.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(625, 331);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 26);
            this.button1.TabIndex = 60;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Red;
            this.button2.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button2.Location = new System.Drawing.Point(512, 331);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(103, 26);
            this.button2.TabIndex = 59;
            this.button2.Text = "Delete";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // updateBtn
            // 
            this.updateBtn.BackColor = System.Drawing.Color.Yellow;
            this.updateBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.updateBtn.Location = new System.Drawing.Point(399, 331);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(103, 26);
            this.updateBtn.TabIndex = 58;
            this.updateBtn.Text = "Update";
            this.updateBtn.UseVisualStyleBackColor = false;
            this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
            // 
            // statusCB
            // 
            this.statusCB.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.statusCB.FormattingEnabled = true;
            this.statusCB.Items.AddRange(new object[] {
            "Pending",
            "Approved",
            "Rejected",
            "In Progress",
            "Completed"});
            this.statusCB.Location = new System.Drawing.Point(162, 352);
            this.statusCB.Name = "statusCB";
            this.statusCB.Size = new System.Drawing.Size(206, 27);
            this.statusCB.TabIndex = 61;
            // 
            // ManageJobs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.statusCB);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.updateBtn);
            this.Controls.Add(this.loadsOfTheJobDGV);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.viewJobsDGV);
            this.Controls.Add(this.jobDateAndTimeDTP);
            this.Controls.Add(this.destinationTxt);
            this.Controls.Add(this.startLocationTxt);
            this.Controls.Add(this.customerIdTxt);
            this.Controls.Add(this.jobIdTxt);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ManageJobs";
            this.Size = new System.Drawing.Size(749, 560);
            this.Load += new System.EventHandler(this.ManageJobs_Load);
            ((System.ComponentModel.ISupportInitialize)(this.viewJobsDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loadsOfTheJobDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private TextBox jobIdTxt;
        private TextBox customerIdTxt;
        private TextBox startLocationTxt;
        private TextBox destinationTxt;
        private DateTimePicker jobDateAndTimeDTP;
        private DataGridView viewJobsDGV;
        private Label label10;
        private DataGridView loadsOfTheJobDGV;
        private Button button1;
        private Button button2;
        private Button updateBtn;
        private ComboBox statusCB;
    }
}
