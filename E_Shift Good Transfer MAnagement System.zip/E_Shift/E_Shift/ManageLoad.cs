﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace E_Shift
{
    public partial class ManageLoad : UserControl
    {
        // connection string
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True";

        private AdminDashboard adminDashboard;

        public ManageLoad(AdminDashboard dashboard)
        {
            InitializeComponent();
            this.adminDashboard = dashboard;
        }


        public void LoadLoadsByJob(int jobID)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "SELECT * FROM Load WHERE JobID = @JobID";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@JobID", jobID);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                loadDGV.DataSource = dt;
            }
        }

        public void LoadAvailableTransportUnits()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "SELECT TransportUnitID FROM TransportUnit";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader reader = cmd.ExecuteReader();

                transportIdCB.Items.Clear();
                while (reader.Read())
                {
                    transportIdCB.Items.Add(reader["TransportUnitID"].ToString());
                }
                reader.Close();
            }
        }

        private void insertBtn_Click(object sender, EventArgs e)
        {

        }

        private void LoadTransportUnitIDs()
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True"))
            {
                try
                {
                    con.Open();
                    string query = "SELECT TransportUnitID FROM TransportUnit";
                    SqlCommand cmd = new SqlCommand(query, con);
                    SqlDataReader reader = cmd.ExecuteReader();

                    transportIdCB.Items.Clear();

                    while (reader.Read())
                    {
                        transportIdCB.Items.Add(reader["TransportUnitID"].ToString());
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading Transport Units: " + ex.Message);
                }
            }
        }

        private void ManageLoad_Load(object sender, EventArgs e)
        {
            LoadTransportUnitIDs();
            LoadLoads();
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(loadIdTxt.Text, out int loadId))
            {
                MessageBox.Show("Invalid Load ID.");
                return;
            }

            if (!float.TryParse(weightTxt.Text, out float weight) ||
                !float.TryParse(volumeTxt.Text, out float volume))
            {
                MessageBox.Show("Invalid weight or volume.");
                return;
            }

            string description = descriptionTxt.Text.Trim();
            int jobId = int.Parse(jobIdTxt.Text);
            int transportId = int.Parse(transportIdCB.Text);

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    // Get Job Date
                    DateTime jobDate = DateTime.MinValue;
                    using (SqlCommand getJobDate = new SqlCommand("SELECT JobDate FROM Job WHERE JobID = @JobID", con))
                    {
                        getJobDate.Parameters.AddWithValue("@JobID", jobId);
                        object result = getJobDate.ExecuteScalar();
                        if (result != null)
                            jobDate = Convert.ToDateTime(result);
                    }

                    // Check if TransportUnit is already assigned to another job at same date
                    string conflictQuery = @"SELECT COUNT(*) FROM Load 
                                     WHERE TransportUnitID = @TransportUnitID 
                                     AND JobID != @JobID 
                                     AND JobID IN (SELECT JobID FROM Job WHERE JobDate = @JobDate)";
                    using (SqlCommand checkConflict = new SqlCommand(conflictQuery, con))
                    {
                        checkConflict.Parameters.AddWithValue("@TransportUnitID", transportId);
                        checkConflict.Parameters.AddWithValue("@JobID", jobId);
                        checkConflict.Parameters.AddWithValue("@JobDate", jobDate);

                        int conflictCount = (int)checkConflict.ExecuteScalar();
                        if (conflictCount > 0)
                        {
                            MessageBox.Show("This Transport Unit is already assigned to another job on the same date.\nPlease choose a different Transport Unit.");
                            return;
                        }
                    }

                    // Get Container Capacity from Capacity column (e.g., "500, 50")
                    float maxWeight = 0;
                    float maxVolume = 0;

                    string capacityQuery = @"SELECT c.Capacity 
                                     FROM TransportUnit tu 
                                     JOIN Container c ON tu.ContainerID = c.ContainerID 
                                     WHERE tu.TransportUnitID = @TransportUnitID";
                    using (SqlCommand getCapCmd = new SqlCommand(capacityQuery, con))
                    {
                        getCapCmd.Parameters.AddWithValue("@TransportUnitID", transportId);
                        object capObj = getCapCmd.ExecuteScalar();

                        if (capObj != null)
                        {
                            string capacity = capObj.ToString();
                            string[] parts = capacity.Split(',');
                            if (parts.Length == 2 &&
                                float.TryParse(parts[0].Trim(), out maxWeight) &&
                                float.TryParse(parts[1].Trim(), out maxVolume))
                            {
                                // Parsed successfully
                            }
                            else
                            {
                                MessageBox.Show("Invalid capacity format in the container (expected: weight, volume).");
                                return;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Container capacity not found.");
                            return;
                        }
                    }

                    // 4️⃣ Get current total weight/volume (excluding the load being updated)
                    float totalWeight = 0;
                    float totalVolume = 0;
                    string totalLoadQuery = @"SELECT SUM(Weight) AS TotalWeight, SUM(Volume) AS TotalVolume 
                                      FROM Load 
                                      WHERE JobID = @JobID 
                                      AND TransportUnitID = @TransportUnitID 
                                      AND LoadID != @LoadID";
                    using (SqlCommand totalCmd = new SqlCommand(totalLoadQuery, con))
                    {
                        totalCmd.Parameters.AddWithValue("@JobID", jobId);
                        totalCmd.Parameters.AddWithValue("@TransportUnitID", transportId);
                        totalCmd.Parameters.AddWithValue("@LoadID", loadId);

                        using (SqlDataReader reader = totalCmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                totalWeight = reader["TotalWeight"] != DBNull.Value ? Convert.ToSingle(reader["TotalWeight"]) : 0;
                                totalVolume = reader["TotalVolume"] != DBNull.Value ? Convert.ToSingle(reader["TotalVolume"]) : 0;
                            }
                        }
                    }

                    float updatedTotalWeight = totalWeight + weight;
                    float updatedTotalVolume = totalVolume + volume;

                    if (updatedTotalWeight > maxWeight || updatedTotalVolume > maxVolume)
                    {
                        MessageBox.Show($"Exceeded container capacity.\nAllowed: {maxWeight}kg / {maxVolume}m³\nCurrent total with this load: {updatedTotalWeight}kg / {updatedTotalVolume}m³");
                        return;
                    }

                    // ✅ Finally, Update the Load
                    string updateQuery = @"UPDATE Load SET 
                                    Weight = @Weight, 
                                    Volume = @Volume, 
                                    Description = @Description, 
                                    JobID = @JobID, 
                                    TransportUnitID = @TransportUnitID 
                                   WHERE LoadID = @LoadID";

                    SqlCommand cmd = new SqlCommand(updateQuery, con);
                    cmd.Parameters.AddWithValue("@Weight", weight);
                    cmd.Parameters.AddWithValue("@Volume", volume);
                    cmd.Parameters.AddWithValue("@Description", description);
                    cmd.Parameters.AddWithValue("@JobID", jobId);
                    cmd.Parameters.AddWithValue("@TransportUnitID", transportId);
                    cmd.Parameters.AddWithValue("@LoadID", loadId);

                    int rows = cmd.ExecuteNonQuery();
                    MessageBox.Show(rows > 0 ? "Load updated successfully!" : "Load not found.");
                    LoadLoads(); // reload grid if needed
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Update Error: " + ex.Message);
                }
                // 🟩 Check if all loads of the job are assigned a TransportUnit
                string checkAllAssignedQuery = @"SELECT COUNT(*) FROM Load WHERE JobID = @JobID AND (TransportUnitID IS NULL OR TransportUnitID = 0)";
                using (SqlCommand checkAssignedCmd = new SqlCommand(checkAllAssignedQuery, con))
                {
                    checkAssignedCmd.Parameters.AddWithValue("@JobID", jobId);
                    int unassignedCount = (int)checkAssignedCmd.ExecuteScalar();

                    if (unassignedCount == 0)
                    {
                        // 🟩 Now update Job status to "In progress" only if it's still "Approved"
                        string updateStatusQuery = @"UPDATE Job 
                                     SET Status = 'In Progress' 
                                     WHERE JobID = @JobID AND Status = 'Approved'";
                        using (SqlCommand updateStatusCmd = new SqlCommand(updateStatusQuery, con))
                        {
                            updateStatusCmd.Parameters.AddWithValue("@JobID", jobId);
                            updateStatusCmd.ExecuteNonQuery();
                        }
                        // Get CustomerID for the Job
                        string getCustomerQuery = "SELECT CustomerID FROM Job WHERE JobID = @JobID";
                        int customerID = 0;
                        using (SqlCommand cmdGetCustomer = new SqlCommand(getCustomerQuery, con))
                        {
                            cmdGetCustomer.Parameters.AddWithValue("@JobID", jobId);
                            object result = cmdGetCustomer.ExecuteScalar();
                            if (result != null) customerID = Convert.ToInt32(result);
                        }

                        // Insert Notification
                        string message = $"Your job #{jobId} is now In progress.";
                        string insertNotification = @"INSERT INTO Notifications (CustomerID, Message) 
                              VALUES (@CustomerID, @Message)";
                        using (SqlCommand cmdNotify = new SqlCommand(insertNotification, con))
                        {
                            cmdNotify.Parameters.AddWithValue("@CustomerID", customerID);
                            cmdNotify.Parameters.AddWithValue("@Message", message);
                            cmdNotify.ExecuteNonQuery();
                        }

                    }
                }

            }

        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(loadIdTxt.Text, out int loadId))
            {
                MessageBox.Show("Invalid Load ID.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "DELETE FROM Load WHERE LoadID = @LoadID";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@LoadID", loadId);

                    int rows = cmd.ExecuteNonQuery();
                    MessageBox.Show(rows > 0 ? "Load deleted successfully." : "Load not found.");
                    LoadLoads(); // refresh data
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Delete error: " + ex.Message);
                }
            }
        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(loadIdTxt.Text, out int loadId))
            {
                MessageBox.Show("Invalid Load ID.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "SELECT * FROM Load WHERE LoadID = @LoadID";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@LoadID", loadId);

                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        weightTxt.Text = reader["Weight"].ToString();
                        volumeTxt.Text = reader["Volume"].ToString();
                        descriptionTxt.Text = reader["Description"].ToString();
                        jobIdTxt.Text = reader["JobID"].ToString();
                        transportIdCB.Text = reader["TransportUnitID"].ToString();
                    }
                    else
                    {
                        MessageBox.Show("Load not found.");
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Search error: " + ex.Message);
                }
            }
        }

        private void LoadLoads()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Load";
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                loadDGV.DataSource = dt;
            }
        }

        private void loadDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // to ignore header row clicks
            {
                DataGridViewRow row = loadDGV.Rows[e.RowIndex];

                loadIdTxt.Text = row.Cells["LoadID"].Value.ToString();
                weightTxt.Text = row.Cells["Weight"].Value.ToString();
                volumeTxt.Text = row.Cells["Volume"].Value.ToString();
                descriptionTxt.Text = row.Cells["Description"].Value.ToString();
                jobIdTxt.Text = row.Cells["JobID"].Value.ToString();
                transportIdCB.Text = row.Cells["TransportUnitID"].Value.ToString();
            }
        }
    }
}
