﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace E_Shift
{
    public partial class DefaultAssistantDashboard : UserControl
    {
        public DefaultAssistantDashboard()
        {
            InitializeComponent();
        }

        private void LoadAssignedJobsForAssistant()
        {
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    string query = @"
                SELECT 
                    J.JobID,
                    J.CustomerID,
                    J.StartLocation,
                    J.Destination,
                    J.JobDate,
                    J.Status,
                    TU.TransportUnitID,
                    L.LorryID,
                    C.ContainerID,
                    C.Capacity,
                    C.Dimensions,
                    D.Name AS DriverName
                FROM Job J
                INNER JOIN Load LD ON J.JobID = LD.JobID
                INNER JOIN TransportUnit TU ON LD.TransportUnitID = TU.TransportUnitID
                INNER JOIN Lorry L ON TU.LorryID = L.LorryID
                INNER JOIN Container C ON TU.ContainerID = C.ContainerID
                LEFT JOIN Driver D ON TU.DriverID = D.DriverID
                WHERE TU.AssistantID = @AssistantID
                GROUP BY 
                    J.JobID, J.CustomerID, J.StartLocation, J.Destination, J.JobDate, J.Status,
                    TU.TransportUnitID, L.LorryID, C.ContainerID, C.Capacity, C.Dimensions, D.Name
                ORDER BY J.JobDate DESC";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@AssistantID", Session.LoggedInAssistantID); // ensure session has this

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    viewAssignedJobs.DataSource = dt;

                    // Optional formatting
                    viewAssignedJobs.Columns["JobDate"].DefaultCellStyle.Format = "yyyy-MM-dd hh:mm tt";
                    viewAssignedJobs.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading assigned jobs: " + ex.Message);
                }
            }
        }

        private void DefaultAssistantDashboard_Load(object sender, EventArgs e)
        {
            LoadAssignedJobsForAssistant();
        }
    }
}
