﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace E_Shift
{
    public partial class CalenderView : UserControl
    {
        // connection string
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True";

        private DateTime currentMonth = DateTime.Now;

        // Navigation controls
        private Button btnPrevMonth;
        private Button btnNextMonth;
        private Label lblMonthYear;
        private DateTimePicker dtpCustomDate;

        public CalenderView()
        {
            InitializeComponent();
            this.Load += CalenderView_Load;

            // Add top controls dynamically
            SetupNavigationControls();
        }

        private void SetupNavigationControls()
        {
            btnPrevMonth = new Button
            {
                Text = "<<",
                Width = 40,
                Height = 25
            };
            btnPrevMonth.Click += BtnPrevMonth_Click;

            btnNextMonth = new Button
            {
                Text = ">>",
                Width = 40,
                Height = 25
            };
            btnNextMonth.Click += BtnNextMonth_Click;

            lblMonthYear = new Label
            {
                AutoSize = true,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter
            };

            dtpCustomDate = new DateTimePicker
            {
                Format = DateTimePickerFormat.Custom,
                CustomFormat = "MMMM yyyy",
                Width = 130
            };
            dtpCustomDate.ValueChanged += DtpCustomDate_ValueChanged;

            FlowLayoutPanel panelTop = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                Height = 40,
                Padding = new Padding(10),
                FlowDirection = FlowDirection.LeftToRight
            };

            panelTop.Controls.Add(btnPrevMonth);
            panelTop.Controls.Add(lblMonthYear);
            panelTop.Controls.Add(btnNextMonth);
            panelTop.Controls.Add(dtpCustomDate);

            this.Controls.Add(panelTop);
        }

        private void BtnPrevMonth_Click(object sender, EventArgs e)
        {
            currentMonth = currentMonth.AddMonths(-1);
            dtpCustomDate.Value = currentMonth;
            PopulateCalendar(currentMonth);
        }

        private void BtnNextMonth_Click(object sender, EventArgs e)
        {
            currentMonth = currentMonth.AddMonths(1);
            dtpCustomDate.Value = currentMonth;
            PopulateCalendar(currentMonth);
        }

        private void DtpCustomDate_ValueChanged(object sender, EventArgs e)
        {
            currentMonth = new DateTime(dtpCustomDate.Value.Year, dtpCustomDate.Value.Month, 1);
            PopulateCalendar(currentMonth);
        }

        private void CalenderView_Load(object sender, EventArgs e)
        {
            dtpCustomDate.Value = DateTime.Now;
            currentMonth = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            PopulateCalendar(currentMonth);
        }

        private void PopulateCalendar(DateTime selectedMonth)
        {
            lblMonthYear.Text = selectedMonth.ToString("MMMM yyyy");

            tblCalendarGrid.Controls.Clear();
            tblCalendarGrid.ColumnCount = 7;
            tblCalendarGrid.RowCount = 7;
            tblCalendarGrid.ColumnStyles.Clear();
            tblCalendarGrid.RowStyles.Clear();

            for (int i = 0; i < 7; i++)
                tblCalendarGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.28f));

            for (int i = 0; i < 7; i++)
                tblCalendarGrid.RowStyles.Add(new RowStyle(SizeType.Percent, 14.28f));

            string[] dayNames = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
            for (int col = 0; col < 7; col++)
            {
                var dayLabel = new Label
                {
                    Text = dayNames[col],
                    Dock = DockStyle.Fill,
                    TextAlign = ContentAlignment.MiddleCenter,
                    Font = new Font("Segoe UI", 9, FontStyle.Bold),
                    BackColor = Color.LightGray
                };
                tblCalendarGrid.Controls.Add(dayLabel, col, 0);
            }

            DateTime firstDay = new DateTime(selectedMonth.Year, selectedMonth.Month, 1);
            int daysInMonth = DateTime.DaysInMonth(selectedMonth.Year, selectedMonth.Month);
            int startColumn = (int)firstDay.DayOfWeek;

            var jobs = GetJobsFromDatabase(selectedMonth);
            int day = 1;

            for (int row = 1; row <= 6; row++)
            {
                for (int col = 0; col < 7; col++)
                {
                    if (row == 1 && col < startColumn)
                    {
                        tblCalendarGrid.Controls.Add(new Panel(), col, row);
                        continue;
                    }

                    if (day > daysInMonth) break;

                    var cellPanel = new Panel
                    {
                        BorderStyle = BorderStyle.FixedSingle,
                        Margin = new Padding(1),
                        BackColor = Color.White,
                        AutoScroll = true
                    };

                    var lblDay = new Label
                    {
                        Text = day.ToString(),
                        Dock = DockStyle.Top,
                        Height = 20,
                        TextAlign = ContentAlignment.TopRight,
                        Font = new Font("Segoe UI", 8, FontStyle.Bold)
                    };
                    cellPanel.Controls.Add(lblDay);

                    DateTime cellDate = new DateTime(selectedMonth.Year, selectedMonth.Month, day);
                    if (cellDate.Date == DateTime.Today)
                    {
                        cellPanel.BackColor = Color.LightBlue;
                    }

                    var jobsForDate = jobs.Where(j => j.JobDate.Date == cellDate.Date).ToList();
                    foreach (var job in jobsForDate)
                    {
                        var jobLabel = new Label
                        {
                            Height = 20,
                            Dock = DockStyle.Top,
                            BackColor = GetStatusColor(job.Status),
                            ForeColor = Color.White,
                            Padding = new Padding(2),
                            Cursor = Cursors.Hand,
                            Tag = job
                        };
                        jobLabel.Click += JobLabel_Click;
                        jobLabel.ContextMenuStrip = contextJobMenu;
                        cellPanel.Controls.Add(jobLabel);
                    }

                    tblCalendarGrid.Controls.Add(cellPanel, col, row);
                    day++;
                }
            }
        }

        public class Job
        {
            public int JobId { get; set; }
            public DateTime JobDate { get; set; }
            public string Status { get; set; }
        }

        private Color GetStatusColor(string status)
        {
            return status switch
            {
                "Pending" => Color.OrangeRed,
                "In Progress" => Color.Orange,
                "Completed" => Color.LimeGreen,
                _ => Color.Gray
            };
        }

        private void JobLabel_Click(object sender, EventArgs e)
        {
            var label = sender as Label;
            var job = label?.Tag as Job;

            if (job != null)
            {
                MessageBox.Show($"Job ID: {job.JobId}\nDate: {job.JobDate.ToShortDateString()}\nStatus: {job.Status}",
                    "Job Details", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private List<Job> GetJobsFromDatabase(DateTime selectedMonth)
        {
            List<Job> jobList = new List<Job>();

            DateTime startDate = new DateTime(selectedMonth.Year, selectedMonth.Month, 1);
            DateTime endDate = startDate.AddMonths(1).AddDays(-1);

            string query = @"SELECT JobID, JObDate, Status
                     FROM Job
                     WHERE JObDate BETWEEN @StartDate AND @EndDate";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@StartDate", startDate);
                    cmd.Parameters.AddWithValue("@EndDate", endDate);

                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            jobList.Add(new Job
                            {
                                JobId = reader.GetInt32(0),
                                //Title = reader.GetString(1),
                                JobDate = reader.GetDateTime(1),
                                Status = reader.GetString(2)
                            });
                        }
                    }
                }
            }

            return jobList;
        }

        // Unused event handlers can remain empty or be removed
        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e) { }
        private void tblCalendarGrid_Paint(object sender, PaintEventArgs e) { }
        private void menuAddJob_Click(object sender, EventArgs e) { }
        private void menuEditJob_Click(object sender, EventArgs e) { }
        private void menuDeleteJob_Click(object sender, EventArgs e) { }
        private void panelLegend_Paint(object sender, PaintEventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void searchBtn_Click(object sender, EventArgs e) { }
        private void searchTxt_TextChanged(object sender, EventArgs e) { }
        private void transportUnitCbx_SelectedIndexChanged(object sender, EventArgs e) { }
        private void UnitLbl_Click(object sender, EventArgs e) { }
        private void customerCbx_SelectedIndexChanged(object sender, EventArgs e) { }
        private void customerLbl_Click(object sender, EventArgs e) { }
        private void panelTopBar_Paint(object sender, PaintEventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void contextJobMenu_Opening(object sender, System.ComponentModel.CancelEventArgs e) { }
        private void menuAddJob_Click_1(object sender, EventArgs e) { }
        private void menuEditJob_Click_1(object sender, EventArgs e) { }
        private void menuDeleteJob_Click_1(object sender, EventArgs e) { }
        private void tblCalendarGrid_Paint_1(object sender, PaintEventArgs e) { }

        private void CalenderView_Load_1(object sender, EventArgs e)
        {

        }
    }
}
