﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace E_Shift
{
    public partial class AssistantManageProfile : UserControl
    {
        // connection string
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True";

        public AssistantManageProfile()
        {
            InitializeComponent();
        }

        // Password hashing method (reuse from login)
        public static string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void clearAll()
        {
            idTxt.Clear();
            nameTxt.Clear();
            contactNumberTxt.Clear();
            nicTxt.Clear();
            assistantPasswordTxt.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    // Step 1: Get logged-in assistant's NIC
                    string getNicQuery = "SELECT NIC FROM Assistant WHERE AssistantID = @AssistantID";
                    SqlCommand getNicCmd = new SqlCommand(getNicQuery, con);
                    getNicCmd.Parameters.AddWithValue("@AssistantID", Session.LoggedInAssistantID);
                    string assistantNIC = getNicCmd.ExecuteScalar()?.ToString();

                    if (string.IsNullOrEmpty(assistantNIC))
                    {
                        MessageBox.Show("Logged-in assistant details not found.");
                        return;
                    }

                    // Step 2: Hash the entered password
                    string enteredPassword = assistantPasswordTxt.Text.Trim();
                    string hashedPassword = HashPassword(enteredPassword);

                    // Step 3: Validate against Users table
                    string checkUserQuery = "SELECT COUNT(*) FROM Users WHERE Username = @Username AND PasswordHash = @PasswordHash AND Role = 'Assistant'";
                    SqlCommand checkCmd = new SqlCommand(checkUserQuery, con);
                    checkCmd.Parameters.AddWithValue("@Username", assistantNIC);
                    checkCmd.Parameters.AddWithValue("@PasswordHash", hashedPassword);

                    int userCount = (int)checkCmd.ExecuteScalar();

                    if (userCount != 1)
                    {
                        MessageBox.Show("Password incorrect. Update denied.");
                        return;
                    }

                    // Step 4: Perform the update
                    string updateQuery = @"UPDATE Assistant 
                                   SET Name = @Name, 
                                       NIC = @NIC, 
                                       ContactNumber = @ContactNumber 
                                   WHERE AssistantID = @AssistantID";

                    SqlCommand updateCmd = new SqlCommand(updateQuery, con);
                    updateCmd.Parameters.AddWithValue("@AssistantID", Session.LoggedInAssistantID);
                    updateCmd.Parameters.AddWithValue("@Name", nameTxt.Text.Trim());
                    updateCmd.Parameters.AddWithValue("@NIC", nicTxt.Text.Trim());
                    updateCmd.Parameters.AddWithValue("@ContactNumber", contactNumberTxt.Text.Trim());

                    int rowsAffected = updateCmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Assistant details updated successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Update failed. No matching record found.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error during update: " + ex.Message);
                }
            }
            clearAll();
        }
    }
}
