﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace E_Shift
{
    public partial class ManageNotifications : UserControl
    {
        // connection string
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True";
        
        private AdminDashboard adminDashboard;

        public ManageNotifications(AdminDashboard dashboard)
        {
            InitializeComponent();
            this.adminDashboard = dashboard;

            // Call it here instead of Load event
            LoadPendingJobs();
        }

        private void LoadAllEnquiries()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "SELECT EnquiryID, CustomerID, EnquiryDescription, ISNULL(Reply, 'Pending') AS Reply FROM Enquiry ORDER BY EnquiryID DESC";
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                enquiriesDGV.DataSource = dt;
            }
        }

        private void LoadAllFeedbacks()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = @"SELECT FeedbackID, JobID, Feedback 
                             FROM Feedback 
                             ORDER BY FeedbackID DESC";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    feedbackDGV.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading feedbacks: " + ex.Message);
                }
            }
        }

        private void ManageNotifications_Load(object sender, EventArgs e)
        {
            LoadPendingJobs();
            LoadAllEnquiries();
            LoadAllFeedbacks();
        }

        public void LoadPendingJobs()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "SELECT * FROM Job WHERE Status = 'Pending'";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    // Assign the result to your DataGridView
                    newJobRequestsDGV.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while loading pending jobs: " + ex.Message);
                }
            }
        }

        private void newJobRequestsDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                string selectedJobID = newJobRequestsDGV.Rows[e.RowIndex].Cells["JobID"].Value.ToString();

                ManageJobs manageJobs = new ManageJobs(adminDashboard);
                manageJobs.LoadJobDetails(selectedJobID);  // Load before showing

                adminDashboard.LoadUserControl(manageJobs);  // Then show the control
                this.Hide();
            }
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void replyBtn_Click(object sender, EventArgs e)
        {
            if (enquiriesDGV.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an enquiry to reply.");
                return;
            }

            int enquiryId = Convert.ToInt32(enquiriesDGV.SelectedRows[0].Cells["EnquiryID"].Value);
            string reply = replyTxt.Text.Trim();

            if (string.IsNullOrWhiteSpace(reply))
            {
                MessageBox.Show("Reply cannot be empty.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "UPDATE Enquiry SET Reply = @Reply WHERE EnquiryID = @EnquiryID";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@Reply", reply);
                    cmd.Parameters.AddWithValue("@EnquiryID", enquiryId);

                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0)
                    {
                        MessageBox.Show("Reply sent successfully.");
                        replyTxt.Clear();
                        LoadAllEnquiries(); // Refresh grid
                    }
                    else
                    {
                        MessageBox.Show("Failed to update reply.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }
    }
}
