﻿namespace E_Shift
{
    partial class ManageTransportUnit
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.transportUnitIdTxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.searchBtn = new System.Windows.Forms.Button();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.updateBtn = new System.Windows.Forms.Button();
            this.insertBtn = new System.Windows.Forms.Button();
            this.containerIDTxt = new System.Windows.Forms.TextBox();
            this.assistantIDTxt = new System.Windows.Forms.TextBox();
            this.driverIDTxt = new System.Windows.Forms.TextBox();
            this.lorryIDTxt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.driverDGV = new System.Windows.Forms.DataGridView();
            this.assistantDGV = new System.Windows.Forms.DataGridView();
            this.lorryDGV = new System.Windows.Forms.DataGridView();
            this.containerDGV = new System.Windows.Forms.DataGridView();
            this.label11 = new System.Windows.Forms.Label();
            this.dateBrowse = new System.Windows.Forms.DateTimePicker();
            this.browseBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.driverDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assistantDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lorryDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.containerDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Sylfaen", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(155, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(404, 36);
            this.label5.TabIndex = 57;
            this.label5.Text = "Manage Transport Unit Details";
            // 
            // transportUnitIdTxt
            // 
            this.transportUnitIdTxt.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.transportUnitIdTxt.Location = new System.Drawing.Point(204, 91);
            this.transportUnitIdTxt.Name = "transportUnitIdTxt";
            this.transportUnitIdTxt.Size = new System.Drawing.Size(157, 27);
            this.transportUnitIdTxt.TabIndex = 56;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(28, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 19);
            this.label1.TabIndex = 55;
            this.label1.Text = "Transport Unit ID";
            // 
            // searchBtn
            // 
            this.searchBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.searchBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.searchBtn.Location = new System.Drawing.Point(325, 337);
            this.searchBtn.Name = "searchBtn";
            this.searchBtn.Size = new System.Drawing.Size(70, 26);
            this.searchBtn.TabIndex = 54;
            this.searchBtn.Text = "Search";
            this.searchBtn.UseVisualStyleBackColor = false;
            this.searchBtn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // deleteBtn
            // 
            this.deleteBtn.BackColor = System.Drawing.Color.Red;
            this.deleteBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.deleteBtn.Location = new System.Drawing.Point(225, 337);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(70, 26);
            this.deleteBtn.TabIndex = 53;
            this.deleteBtn.Text = "Delete";
            this.deleteBtn.UseVisualStyleBackColor = false;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // updateBtn
            // 
            this.updateBtn.BackColor = System.Drawing.Color.Yellow;
            this.updateBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.updateBtn.Location = new System.Drawing.Point(126, 337);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(70, 26);
            this.updateBtn.TabIndex = 52;
            this.updateBtn.Text = "Update";
            this.updateBtn.UseVisualStyleBackColor = false;
            this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
            // 
            // insertBtn
            // 
            this.insertBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.insertBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.insertBtn.Location = new System.Drawing.Point(24, 337);
            this.insertBtn.Name = "insertBtn";
            this.insertBtn.Size = new System.Drawing.Size(70, 26);
            this.insertBtn.TabIndex = 51;
            this.insertBtn.Text = "Insert";
            this.insertBtn.UseVisualStyleBackColor = false;
            this.insertBtn.Click += new System.EventHandler(this.insertBtn_Click);
            // 
            // containerIDTxt
            // 
            this.containerIDTxt.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.containerIDTxt.Location = new System.Drawing.Point(204, 183);
            this.containerIDTxt.Multiline = true;
            this.containerIDTxt.Name = "containerIDTxt";
            this.containerIDTxt.Size = new System.Drawing.Size(157, 33);
            this.containerIDTxt.TabIndex = 48;
            // 
            // assistantIDTxt
            // 
            this.assistantIDTxt.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.assistantIDTxt.Location = new System.Drawing.Point(203, 281);
            this.assistantIDTxt.Name = "assistantIDTxt";
            this.assistantIDTxt.Size = new System.Drawing.Size(157, 27);
            this.assistantIDTxt.TabIndex = 47;
            // 
            // driverIDTxt
            // 
            this.driverIDTxt.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.driverIDTxt.Location = new System.Drawing.Point(203, 233);
            this.driverIDTxt.Name = "driverIDTxt";
            this.driverIDTxt.Size = new System.Drawing.Size(157, 27);
            this.driverIDTxt.TabIndex = 46;
            // 
            // lorryIDTxt
            // 
            this.lorryIDTxt.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lorryIDTxt.Location = new System.Drawing.Point(203, 132);
            this.lorryIDTxt.Name = "lorryIDTxt";
            this.lorryIDTxt.Size = new System.Drawing.Size(157, 27);
            this.lorryIDTxt.TabIndex = 45;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(28, 186);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 19);
            this.label6.TabIndex = 44;
            this.label6.Text = "Container ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(27, 284);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 19);
            this.label4.TabIndex = 43;
            this.label4.Text = "Assistant ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(27, 233);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 19);
            this.label3.TabIndex = 42;
            this.label3.Text = "Driver ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(27, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 19);
            this.label2.TabIndex = 41;
            this.label2.Text = "Lorry ID ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(27, 380);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 19);
            this.label7.TabIndex = 58;
            this.label7.Text = "Driver";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(391, 380);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 19);
            this.label8.TabIndex = 59;
            this.label8.Text = "Assistant";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(391, 96);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 19);
            this.label9.TabIndex = 60;
            this.label9.Text = "Lorry";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(391, 238);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 19);
            this.label10.TabIndex = 61;
            this.label10.Text = "Container";
            // 
            // driverDGV
            // 
            this.driverDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.driverDGV.Location = new System.Drawing.Point(28, 402);
            this.driverDGV.Name = "driverDGV";
            this.driverDGV.RowHeadersWidth = 51;
            this.driverDGV.RowTemplate.Height = 29;
            this.driverDGV.Size = new System.Drawing.Size(355, 135);
            this.driverDGV.TabIndex = 62;
            // 
            // assistantDGV
            // 
            this.assistantDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.assistantDGV.Location = new System.Drawing.Point(402, 402);
            this.assistantDGV.Name = "assistantDGV";
            this.assistantDGV.RowHeadersWidth = 51;
            this.assistantDGV.RowTemplate.Height = 29;
            this.assistantDGV.Size = new System.Drawing.Size(333, 135);
            this.assistantDGV.TabIndex = 63;
            // 
            // lorryDGV
            // 
            this.lorryDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lorryDGV.Location = new System.Drawing.Point(402, 118);
            this.lorryDGV.Name = "lorryDGV";
            this.lorryDGV.RowHeadersWidth = 51;
            this.lorryDGV.RowTemplate.Height = 29;
            this.lorryDGV.Size = new System.Drawing.Size(333, 117);
            this.lorryDGV.TabIndex = 64;
            // 
            // containerDGV
            // 
            this.containerDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.containerDGV.Location = new System.Drawing.Point(402, 260);
            this.containerDGV.Name = "containerDGV";
            this.containerDGV.RowHeadersWidth = 51;
            this.containerDGV.RowTemplate.Height = 29;
            this.containerDGV.Size = new System.Drawing.Size(333, 117);
            this.containerDGV.TabIndex = 65;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label11.ForeColor = System.Drawing.Color.Purple;
            this.label11.Location = new System.Drawing.Point(183, 56);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(230, 19);
            this.label11.TabIndex = 66;
            this.label11.Text = "Browse Available Components:";
            // 
            // dateBrowse
            // 
            this.dateBrowse.CustomFormat = "dd, MMMM, yyyy ";
            this.dateBrowse.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dateBrowse.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateBrowse.Location = new System.Drawing.Point(419, 56);
            this.dateBrowse.Name = "dateBrowse";
            this.dateBrowse.Size = new System.Drawing.Size(240, 27);
            this.dateBrowse.TabIndex = 67;
            // 
            // browseBtn
            // 
            this.browseBtn.BackColor = System.Drawing.Color.Silver;
            this.browseBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.browseBtn.Location = new System.Drawing.Point(665, 58);
            this.browseBtn.Name = "browseBtn";
            this.browseBtn.Size = new System.Drawing.Size(70, 26);
            this.browseBtn.TabIndex = 68;
            this.browseBtn.Text = "Browse";
            this.browseBtn.UseVisualStyleBackColor = false;
            this.browseBtn.Click += new System.EventHandler(this.browseBtn_Click);
            // 
            // ManageTransportUnit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.browseBtn);
            this.Controls.Add(this.dateBrowse);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.containerDGV);
            this.Controls.Add(this.lorryDGV);
            this.Controls.Add(this.assistantDGV);
            this.Controls.Add(this.driverDGV);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.transportUnitIdTxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.searchBtn);
            this.Controls.Add(this.deleteBtn);
            this.Controls.Add(this.updateBtn);
            this.Controls.Add(this.insertBtn);
            this.Controls.Add(this.containerIDTxt);
            this.Controls.Add(this.assistantIDTxt);
            this.Controls.Add(this.driverIDTxt);
            this.Controls.Add(this.lorryIDTxt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Name = "ManageTransportUnit";
            this.Size = new System.Drawing.Size(751, 553);
            this.Load += new System.EventHandler(this.ManageTransportUnit_Load);
            ((System.ComponentModel.ISupportInitialize)(this.driverDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assistantDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lorryDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.containerDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label5;
        private TextBox transportUnitIdTxt;
        private Label label1;
        private Button searchBtn;
        private Button deleteBtn;
        private Button updateBtn;
        private Button insertBtn;
        private TextBox containerIDTxt;
        private TextBox assistantIDTxt;
        private TextBox driverIDTxt;
        private TextBox lorryIDTxt;
        private Label label6;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private DataGridView driverDGV;
        private DataGridView assistantDGV;
        private DataGridView lorryDGV;
        private DataGridView containerDGV;
        private Label label11;
        private DateTimePicker dateBrowse;
        private Button browseBtn;
    }
}
