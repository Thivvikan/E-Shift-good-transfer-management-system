﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E_Shift
{
    public partial class DriverDashboard : Form
    {
        
        public DriverDashboard()
        {
            InitializeComponent();
        }

        private void LoadUserControl(UserControl uc)
        {
            mainContentArea.Controls.Clear();
            uc.Dock = DockStyle.Fill;
            mainContentArea.Controls.Add(uc);
        }

        private void EmployeeDashboard_Load(object sender, EventArgs e)
        {
            LoadUserControl(new DefaultDriverDashboard());
        }

        private void logoutBtn_Click(object sender, EventArgs e)
        {
            login loginForm = new login();
            loginForm.Show();
            this.Hide();
        }

        private void dashboardBtn_Click(object sender, EventArgs e)
        {
            LoadUserControl(new DefaultDriverDashboard());
        }

        private void manageEmployeeProfileBtn_Click(object sender, EventArgs e)
        {
            LoadUserControl(new DiverManageProfile());
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            LoadUserControl(new DefaultDriverDashboard());
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            LoadUserControl(new DiverManageProfile());
        }

        private void mainContentArea_Paint(object sender, PaintEventArgs e)
        {
            
        }
    }
}
