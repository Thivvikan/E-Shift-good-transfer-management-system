﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace E_Shift
{
    public partial class CustomerManageJobs : UserControl
    {
        public CustomerManageJobs()
        {
            InitializeComponent();
            loadCustomerJobsToDGV();
        }
        // connection string
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True";

        int customerId = Session.LoggedInCustomerID; // Set this during login
        int newJobID;

        // code for insert button
        private void button4_Click(object sender, EventArgs e)
        {
            string startLocation = startLocationTxt.Text;
            string destination = destinationTxt.Text;
            DateTime jobDate = jobDateAndTimeDTP.Value;
            string status = "Pending";
            double totalWeight = double.Parse(weightTxt.Text);
            double totalVolume = double.Parse(volumeTxt.Text);

            if (string.IsNullOrWhiteSpace(startLocation) || string.IsNullOrWhiteSpace(destination))
            {
                MessageBox.Show("Please fill in all fields.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO Job (CustomerID, StartLocation, Destination, JobDate, Status) " +
                                   "VALUES (@CustomerID, @StartLocation, @Destination, @JobDate, @Status);" +
                                   "SELECT SCOPE_IDENTITY();";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@CustomerID", customerId);
                        cmd.Parameters.AddWithValue("@StartLocation", startLocation);
                        cmd.Parameters.AddWithValue("@Destination", destination);
                        cmd.Parameters.AddWithValue("@JobDate", jobDate);
                        cmd.Parameters.AddWithValue("@Status", status);

                        conn.Open();
                        
                        object result = cmd.ExecuteScalar();

                        if (result != null)
                        {
                            newJobID = Convert.ToInt32(result);

                            // now insert the load details
                            InsertLoad(newJobID, totalWeight, totalVolume);

                            MessageBox.Show("Job inserted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearFields();
                        }
                        else
                        {
                            MessageBox.Show("Insert failed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while inserting job:\n" + ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            clearAll();
            loadCustomerJobsToDGV();
        }

        public void InsertLoad(int jobID, double totalWeight, double totalVolume)
        {
            int loadCountByWeight = (int)Math.Ceiling(totalWeight / 100);
            int loadCountByVolume = (int)Math.Ceiling(totalVolume / 10);

            int finalLoadCount = Math.Max(loadCountByWeight, loadCountByVolume);

            double splitWeight = totalWeight / finalLoadCount;
            double splitVolume = totalVolume / finalLoadCount;
            string description = descriptionTxt.Text;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                for (int i = 0; i < finalLoadCount; i++)
                {
                    string query = "INSERT INTO Load (JobID, Weight, Volume, Description) " +
                                   "VALUES (@JobID, @Weight, @Volume, @Description)";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@JobID", jobID);
                        cmd.Parameters.AddWithValue("@Weight", splitWeight);
                        cmd.Parameters.AddWithValue("@Volume", splitVolume);
                        cmd.Parameters.AddWithValue("@Description", description);

                        cmd.ExecuteNonQuery();
                    }
                }

                con.Close();
            }

            Console.WriteLine($"{finalLoadCount} loads inserted for JobID: {jobID}");
        }

        private void ClearFields()
        {
            startLocationTxt.Text = "";
            destinationTxt.Text = "";
            jobDateAndTimeDTP.Value = DateTime.Today;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int jobId;

            if (!int.TryParse(jobIdTxt.Text, out jobId))
            {
                MessageBox.Show("Invalid Job ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string startLocation = startLocationTxt.Text.Trim();
            string destination = destinationTxt.Text.Trim();
            DateTime? jobDate = jobDateAndTimeDTP.Checked ? jobDateAndTimeDTP.Value : (DateTime?)null;
            string weightStr = weightTxt.Text.Trim();
            string volumeStr = volumeTxt.Text.Trim();

            double? newWeight = string.IsNullOrWhiteSpace(weightStr) ? (double?)null : double.Parse(weightStr);
            double? newVolume = string.IsNullOrWhiteSpace(volumeStr) ? (double?)null : double.Parse(volumeStr);

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    // Build the UPDATE query dynamically
                    List<string> setClauses = new List<string>();
                    SqlCommand cmd = new SqlCommand();

                    if (!string.IsNullOrWhiteSpace(startLocation))
                    {
                        setClauses.Add("StartLocation = @StartLocation");
                        cmd.Parameters.AddWithValue("@StartLocation", startLocation);
                    }

                    if (!string.IsNullOrWhiteSpace(destination))
                    {
                        setClauses.Add("Destination = @Destination");
                        cmd.Parameters.AddWithValue("@Destination", destination);
                    }

                    if (jobDate.HasValue)
                    {
                        setClauses.Add("JobDate = @JobDate");
                        cmd.Parameters.AddWithValue("@JobDate", jobDate.Value);
                    }

                    // Only run UPDATE if there’s something to change
                    if (setClauses.Count > 0)
                    {
                        string query = $"UPDATE Job SET {string.Join(", ", setClauses)} " +
                                       "WHERE JobID = @JobID AND CustomerID = @CustomerID";

                        cmd.CommandText = query;
                        cmd.Connection = conn;
                        cmd.Parameters.AddWithValue("@JobID", jobId);
                        cmd.Parameters.AddWithValue("@CustomerID", customerId);

                        conn.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();

                        // If weight/volume provided, update loads
                        if (newWeight.HasValue || newVolume.HasValue)
                        {
                            UpdateOrInsertLoads(jobId, newWeight ?? 0, newVolume ?? 0);
                        }

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Job updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Update failed. Please check the Job ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("No fields to update. Please fill in at least one field.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while updating job:\n" + ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            clearAll();
            loadCustomerJobsToDGV();
        }

        public void UpdateOrInsertLoads(int jobID, double newWeight, double newVolume)
        {
            string description = descriptionTxt.Text;

            int maxWeightPerLoad = 100;
            int maxVolumePerLoad = 10;

            int requiredByWeight = (int)Math.Ceiling(newWeight / maxWeightPerLoad);
            int requiredByVolume = (int)Math.Ceiling(newVolume / maxVolumePerLoad);
            int finalLoadCount = Math.Max(requiredByWeight, requiredByVolume);

            double updatedWeight = newWeight / finalLoadCount;
            double updatedVolume = newVolume / finalLoadCount;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                // 1. Count current loads for JobID
                int currentLoadCount = 0;
                using (SqlCommand countCmd = new SqlCommand("SELECT COUNT(*) FROM Load WHERE JobID = @JobID", con))
                {
                    countCmd.Parameters.AddWithValue("@JobID", jobID);
                    currentLoadCount = (int)countCmd.ExecuteScalar();
                }

                // 2. Update all existing loads
                using (SqlCommand updateCmd = new SqlCommand("UPDATE Load SET Weight = @Weight, Volume = @Volume WHERE JobID = @JobID", con))
                {
                    updateCmd.Parameters.AddWithValue("@Weight", updatedWeight);
                    updateCmd.Parameters.AddWithValue("@Volume", updatedVolume);
                    updateCmd.Parameters.AddWithValue("@JobID", jobID);
                    updateCmd.ExecuteNonQuery();
                }

                // 3. If more loads needed, insert the remaining
                int additionalLoads = finalLoadCount - currentLoadCount;
                if (additionalLoads > 0)
                {
                    for (int i = 0; i < additionalLoads; i++)
                    {
                        using (SqlCommand insertCmd = new SqlCommand("INSERT INTO Load (JobID, Weight, Volume, Description) VALUES (@JobID, @Weight, @Volume, @Description)", con))
                        {
                            insertCmd.Parameters.AddWithValue("@JobID", jobID);
                            insertCmd.Parameters.AddWithValue("@Weight", updatedWeight);
                            insertCmd.Parameters.AddWithValue("@Volume", updatedVolume);
                            insertCmd.Parameters.AddWithValue("@Description", description);
                            insertCmd.ExecuteNonQuery();
                        }
                    }
                }

                con.Close();
            }

            Console.WriteLine($"Updated JobID: {jobID} to {finalLoadCount} loads with Weight = {updatedWeight}, Volume = {updatedVolume}");
        }

        // Delete button code
        private void button2_Click(object sender, EventArgs e)
        {
            int jobId;

            if (!int.TryParse(jobIdTxt.Text, out jobId))
            {
                MessageBox.Show("Invalid Job ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var confirm = MessageBox.Show("Are you sure you want to delete this job?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm == DialogResult.No)
                return;

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Job WHERE JobID = @JobID AND CustomerID = @CustomerID";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        string deleteLoadQuery = "DELETE FROM Load WHERE JobID = @JobID";

                        conn.Open();

                        using (SqlCommand cmd1 = new SqlCommand(deleteLoadQuery, conn))
                        {
                            cmd1.Parameters.AddWithValue("@JobID", jobId);
                            int rowsAffected1 = cmd1.ExecuteNonQuery();

                            Console.WriteLine($"{rowsAffected1} load(s) deleted for JobID: {jobId}");
                        }

                        cmd.Parameters.AddWithValue("@JobID", jobId);
                        cmd.Parameters.AddWithValue("@CustomerID", customerId);

                        
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Job deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearFields();
                        }
                        else
                        {
                            MessageBox.Show("Delete failed. Please check the Job ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        
                        conn.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while deleting job:\n" + ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            clearAll();
            loadCustomerJobsToDGV();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int jobId;

            if (!int.TryParse(jobIdTxt.Text, out jobId))
            {
                MessageBox.Show("Invalid Job ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "SELECT StartLocation, Destination, JobDate, Status FROM Job " +
                                   "WHERE JobID = @JobID AND CustomerID = @CustomerID";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@JobID", jobId);
                        cmd.Parameters.AddWithValue("@CustomerID", customerId);

                        conn.Open();
                        SqlDataReader reader = cmd.ExecuteReader();

                        if (reader.Read())
                        {
                            startLocationTxt.Text = reader["StartLocation"].ToString();
                            destinationTxt.Text = reader["Destination"].ToString();
                            jobDateAndTimeDTP.Value = Convert.ToDateTime(reader["JobDate"]);
                            MessageBox.Show("Job found. Status: " + reader["Status"].ToString(), "Search Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Job not found.", "Result", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while searching job:\n" + ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void loadCustomerJobsToDGV()
        {
            
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "SELECT JobID, StartLocation, Destination, JobDate, Status " +
                                   "FROM Job WHERE CustomerID = @CustomerID ORDER BY JobID DESC";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@CustomerID", customerId);

                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        DataTable jobsTable = new DataTable();
                        adapter.Fill(jobsTable);

                        customerJobsViewDGV.DataSource = jobsTable;

                        // Customize column headers
                        customerJobsViewDGV.Columns["JobID"].HeaderText = "Job ID";
                        customerJobsViewDGV.Columns["StartLocation"].HeaderText = "Start Location";
                        customerJobsViewDGV.Columns["Destination"].HeaderText = "Destination";
                        customerJobsViewDGV.Columns["JobDate"].HeaderText = "Date";
                        customerJobsViewDGV.Columns["Status"].HeaderText = "Status";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load jobs:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CustomerManageJobs_Load(object sender, EventArgs e)
        {
            loadCustomerJobsToDGV();
        }

        // method to clear all input fields
        private void clearAll()
        {
            jobIdTxt.Clear();
            startLocationTxt.Clear();
            destinationTxt.Clear();
            jobDateAndTimeDTP.Value = DateTime.Today;
            statusTxt.Clear();
            weightTxt.Clear();
            volumeTxt.Clear();
            descriptionTxt.Clear();
        }

        // Clear button code
        private void clearBtn_Click(object sender, EventArgs e)
        {
            clearAll();
        }

        private void customerJobsViewDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Make sure it's not the header
            {
                DataGridViewRow row = customerJobsViewDGV.Rows[e.RowIndex];

                // Assign values to input fields
                jobIdTxt.Text = row.Cells["JobID"].Value.ToString();
                startLocationTxt.Text = row.Cells["StartLocation"].Value.ToString();
                destinationTxt.Text = row.Cells["Destination"].Value.ToString();
                statusTxt.Text = row.Cells["Status"].Value.ToString();
                
                if (DateTime.TryParse(row.Cells["JobDate"].Value.ToString(), out DateTime jobDate))
                {
                    jobDateAndTimeDTP.Value = jobDate;
                }
            }
        }
    }
}
