﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace E_Shift
{
    public partial class ManageTransportUnit : UserControl
    {
        // connection string
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True";

        public ManageTransportUnit()
        {
            InitializeComponent();
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(transportUnitIdTxt.Text, out int unitId))
            {
                MessageBox.Show("Invalid Unit ID.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "DELETE FROM TransportUnit WHERE TransportUnitID = @UnitID";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@UnitID", unitId);

                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0)
                    {
                        MessageBox.Show("Transport Unit deleted successfully.");
                        
                    }
                    else
                    {
                        MessageBox.Show("Transport Unit not found.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Delete failed: " + ex.Message);
                }
            }
        }

        private void LoadLorries()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Lorry";
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                lorryDGV.DataSource = dt;
            }
        }

        private void LoadContainers()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Container";
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                containerDGV.DataSource = dt;
            }
        }
        private void LoadDrivers()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Driver";
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                driverDGV.DataSource = dt;
            }
        }

        private void LoadAssistants()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Assistant";
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                assistantDGV.DataSource = dt;
            }
        }

        private void ManageTransportUnit_Load(object sender, EventArgs e)
        {
            LoadLorries();
            LoadContainers();
            LoadAssistants();
            LoadDrivers();
        }

        private void insertBtn_Click(object sender, EventArgs e)
        {
            int lorryId = int.Parse(lorryIDTxt.Text.Trim());
            int containerId = int.Parse(containerIDTxt.Text.Trim());
            int driverId = int.Parse(driverIDTxt.Text.Trim());
            int assistantId = int.Parse(assistantIDTxt.Text.Trim());

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "INSERT INTO TransportUnit (LorryID, ContainerID, DriverID, AssistantID) " +
                                   "VALUES (@LorryID, @ContainerID, @DriverID, @AssistantID)";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@LorryID", lorryId);
                    cmd.Parameters.AddWithValue("@ContainerID", containerId);
                    cmd.Parameters.AddWithValue("@DriverID", driverId);
                    cmd.Parameters.AddWithValue("@AssistantID", assistantId);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Transport Unit inserted successfully.");
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Insert failed: " + ex.Message);
                }
            }
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(transportUnitIdTxt.Text, out int unitId))
            {
                MessageBox.Show("Invalid Unit ID.");
                return;
            }

            int lorryId = int.Parse(lorryIDTxt.Text.Trim());
            int containerId = int.Parse(containerIDTxt.Text.Trim());
            int driverId = int.Parse(driverIDTxt.Text.Trim());
            int assistantId = int.Parse(assistantIDTxt.Text.Trim());

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "UPDATE TransportUnit SET LorryID = @LorryID, ContainerID = @ContainerID, " +
                                   "DriverID = @DriverID, AssistantID = @AssistantID WHERE TransportUnitID = @UnitID";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@LorryID", lorryId);
                    cmd.Parameters.AddWithValue("@ContainerID", containerId);
                    cmd.Parameters.AddWithValue("@DriverID", driverId);
                    cmd.Parameters.AddWithValue("@AssistantID", assistantId);
                    cmd.Parameters.AddWithValue("@UnitID", unitId);

                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0)
                    {
                        MessageBox.Show("Transport Unit updated successfully.");
                        
                    }
                    else
                    {
                        MessageBox.Show("Transport Unit not found.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Update failed: " + ex.Message);
                }
            }
        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(transportUnitIdTxt.Text, out int unitId))
            {
                MessageBox.Show("Invalid Unit ID.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "SELECT * FROM TransportUnit WHERE TransportUnitID = @UnitID";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@UnitID", unitId);

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        lorryIDTxt.Text = reader["LorryID"].ToString();
                        containerIDTxt.Text = reader["ContainerID"].ToString();
                        driverIDTxt.Text = reader["DriverID"].ToString();
                        assistantIDTxt.Text = reader["AssistantID"].ToString();
                    }
                    else
                    {
                        MessageBox.Show("Transport Unit not found.");
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Search failed: " + ex.Message);
                }
            }
        }

        private void browseBtn_Click(object sender, EventArgs e)
        {
            DateTime selectedDate = dateBrowse.Value.Date;

            LoadAvailableLorries(selectedDate);
            LoadAvailableDrivers(selectedDate);
            LoadAvailableAssistants(selectedDate);
            LoadAvailableContainers(selectedDate);
        }

        private List<int> GetOccupiedTransportUnitIds(DateTime date)
        {
            var occupiedIds = new List<int>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                string query = @"
            SELECT DISTINCT tu.TransportUnitID
            FROM TransportUnit tu
            INNER JOIN Load l ON tu.TransportUnitID = l.TransportUnitID
            INNER JOIN Job j ON l.JobID = j.JobID
            WHERE CAST(j.JobDate AS DATE) = @Date";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Date", date);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            occupiedIds.Add(reader.GetInt32(0));
                        }
                    }
                }
            }

            return occupiedIds;
        }

        private void LoadAvailableLorries(DateTime date)
        {
            var occupiedTUIds = GetOccupiedTransportUnitIds(date);

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                string query = @"
                    SELECT * FROM Lorry l
                    WHERE l.LorryID NOT IN (
                        SELECT tu.LorryID FROM TransportUnit tu
                        WHERE tu.TransportUnitID IN (" 
                            + string.Join(",", occupiedTUIds.DefaultIfEmpty(-1)) + "))";
        
        SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                lorryDGV.DataSource = dt;
            }
        }

        private void LoadAvailableDrivers(DateTime date)
        {
            var occupiedTUIds = GetOccupiedTransportUnitIds(date);

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                string query = @"
                    SELECT * FROM Driver d
                    WHERE d.DriverID NOT IN (
                        SELECT tu.DriverID FROM TransportUnit tu
                        WHERE tu.TransportUnitID IN (" 
                        + string.Join(",", occupiedTUIds.DefaultIfEmpty(-1)) + "))";
        
        SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                driverDGV.DataSource = dt;
            }
        }

        private void LoadAvailableAssistants(DateTime date)
        {
            var occupiedTUIds = GetOccupiedTransportUnitIds(date);

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                string query = @"
                    SELECT * FROM Assistant a
                    WHERE a.AssistantID NOT IN (
                        SELECT tu.AssistantID FROM TransportUnit tu
                        WHERE tu.TransportUnitID IN (" 
                            + string.Join(",", occupiedTUIds.DefaultIfEmpty(-1)) + "))";
        
        SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                assistantDGV.DataSource = dt;
            }
        }

        private void LoadAvailableContainers(DateTime date)
        {
            var occupiedTUIds = GetOccupiedTransportUnitIds(date);

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                string query = @"
                    SELECT * FROM Container c
                    WHERE c.ContainerID NOT IN (
                        SELECT tu.ContainerID FROM TransportUnit tu
                        WHERE tu.TransportUnitID IN (" 
                            + string.Join(",", occupiedTUIds.DefaultIfEmpty(-1)) + "))";
        
        SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                containerDGV.DataSource = dt;
            }
        }

    }
}
