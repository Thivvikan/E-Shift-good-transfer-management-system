﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E_Shift
{
    public class Session
    {
        public static int LoggedInCustomerID { get; set; }
        public static int LoggedInDriverID { get; set; }
        public static int LoggedInAssistantID { get; set; }
    }
}
