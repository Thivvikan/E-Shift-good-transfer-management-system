﻿namespace E_Shift
{
    partial class CalenderView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panelLegend = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.contextJobMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuAddJob = new System.Windows.Forms.ToolStripMenuItem();
            this.menuEditJob = new System.Windows.Forms.ToolStripMenuItem();
            this.menuDeleteJob = new System.Windows.Forms.ToolStripMenuItem();
            this.tblCalendarGrid = new System.Windows.Forms.TableLayoutPanel();
            this.panelLegend.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.contextJobMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelLegend
            // 
            this.panelLegend.Controls.Add(this.pictureBox3);
            this.panelLegend.Controls.Add(this.pictureBox2);
            this.panelLegend.Controls.Add(this.pictureBox1);
            this.panelLegend.Controls.Add(this.label3);
            this.panelLegend.Controls.Add(this.label2);
            this.panelLegend.Controls.Add(this.label1);
            this.panelLegend.Location = new System.Drawing.Point(3, 62);
            this.panelLegend.Name = "panelLegend";
            this.panelLegend.Size = new System.Drawing.Size(753, 50);
            this.panelLegend.TabIndex = 1;
            this.panelLegend.Paint += new System.Windows.Forms.PaintEventHandler(this.panelLegend_Paint);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.OrangeRed;
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox3.Location = new System.Drawing.Point(27, 15);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(26, 22);
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.LimeGreen;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox2.Location = new System.Drawing.Point(527, 15);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(26, 22);
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Orange;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(267, 15);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(26, 22);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(554, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "Completed";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(299, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 22);
            this.label2.TabIndex = 1;
            this.label2.Text = "In Pogress";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(56, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Pending";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // contextJobMenu
            // 
            this.contextJobMenu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextJobMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuAddJob,
            this.menuEditJob,
            this.menuDeleteJob});
            this.contextJobMenu.Name = "contextJobMenu";
            this.contextJobMenu.Size = new System.Drawing.Size(150, 76);
            this.contextJobMenu.Opening += new System.ComponentModel.CancelEventHandler(this.contextJobMenu_Opening);
            // 
            // menuAddJob
            // 
            this.menuAddJob.Name = "menuAddJob";
            this.menuAddJob.Size = new System.Drawing.Size(149, 24);
            this.menuAddJob.Text = "Add Job";
            this.menuAddJob.Click += new System.EventHandler(this.menuAddJob_Click_1);
            // 
            // menuEditJob
            // 
            this.menuEditJob.Name = "menuEditJob";
            this.menuEditJob.Size = new System.Drawing.Size(149, 24);
            this.menuEditJob.Text = "Edit Job";
            this.menuEditJob.Click += new System.EventHandler(this.menuEditJob_Click_1);
            // 
            // menuDeleteJob
            // 
            this.menuDeleteJob.Name = "menuDeleteJob";
            this.menuDeleteJob.Size = new System.Drawing.Size(149, 24);
            this.menuDeleteJob.Text = "Delete Job";
            this.menuDeleteJob.Click += new System.EventHandler(this.menuDeleteJob_Click_1);
            // 
            // tblCalendarGrid
            // 
            this.tblCalendarGrid.BackColor = System.Drawing.Color.Transparent;
            this.tblCalendarGrid.ColumnCount = 7;
            this.tblCalendarGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblCalendarGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblCalendarGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblCalendarGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblCalendarGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblCalendarGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblCalendarGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblCalendarGrid.Location = new System.Drawing.Point(0, 118);
            this.tblCalendarGrid.Name = "tblCalendarGrid";
            this.tblCalendarGrid.RowCount = 7;
            this.tblCalendarGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblCalendarGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblCalendarGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblCalendarGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblCalendarGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblCalendarGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblCalendarGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblCalendarGrid.Size = new System.Drawing.Size(753, 319);
            this.tblCalendarGrid.TabIndex = 2;
            this.tblCalendarGrid.Paint += new System.Windows.Forms.PaintEventHandler(this.tblCalendarGrid_Paint_1);
            // 
            // CalenderView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.tblCalendarGrid);
            this.Controls.Add(this.panelLegend);
            this.Name = "CalenderView";
            this.Size = new System.Drawing.Size(753, 459);
            this.Load += new System.EventHandler(this.CalenderView_Load_1);
            this.panelLegend.ResumeLayout(false);
            this.panelLegend.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.contextJobMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Panel panelLegend;
        private Label label3;
        private Label label2;
        private Label label1;
        private ContextMenuStrip contextJobMenu;
        private ToolStripMenuItem menuAddJob;
        private ToolStripMenuItem menuEditJob;
        private ToolStripMenuItem menuDeleteJob;
        private TableLayoutPanel tblCalendarGrid;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
    }
}
