﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace E_Shift
{
    public partial class DefaultDriverDashboard : UserControl
    {
        // connection strind
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True";

        // temporarily saving the driver and job assigned
        private Dictionary<int, HashSet<int>> jobCompletions = new Dictionary<int, HashSet<int>>();

        private void LoadAssignedJobsForDriver()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    string query = @"
                SELECT 
                    J.JobID,
                    J.CustomerID,
                    J.StartLocation,
                    J.Destination,
                    J.JobDate,
                    J.Status,
                    TU.TransportUnitID,
                    L.LorryID,
                    C.ContainerID,
                    C.Capacity,
                    C.Dimensions,
                    A.Name AS AssistantName
                FROM Job J
                INNER JOIN Load LD ON J.JobID = LD.JobID
                INNER JOIN TransportUnit TU ON LD.TransportUnitID = TU.TransportUnitID
                INNER JOIN Lorry L ON TU.LorryID = L.LorryID
                INNER JOIN Container C ON TU.ContainerID = C.ContainerID
                LEFT JOIN Assistant A ON TU.AssistantID = A.AssistantID
                WHERE TU.DriverID = @DriverID AND J.Status = 'In Progress'
                GROUP BY 
                    J.JobID, J.CustomerID, J.StartLocation, J.Destination, J.JobDate, J.Status,
                    TU.TransportUnitID, L.LorryID, C.ContainerID, C.Capacity, C.Dimensions, A.Name
                ORDER BY J.JobDate DESC";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@DriverID", Session.LoggedInDriverID); // assuming session holds this

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    viewAssignedJobs.DataSource = dt;

                    // Optional styling
                    viewAssignedJobs.Columns["JobDate"].DefaultCellStyle.Format = "yyyy-MM-dd hh:mm tt";
                    viewAssignedJobs.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    // Add button only if not already added
                    if (!viewAssignedJobs.Columns.Contains("btnMarkCompleted"))
                    {
                        DataGridViewButtonColumn btn = new DataGridViewButtonColumn();
                        btn.HeaderText = "Action";
                        btn.Text = "Mark Completed";
                        btn.UseColumnTextForButtonValue = true;
                        btn.Name = "btnMarkCompleted";
                        btn.DefaultCellStyle.BackColor = Color.LightGreen; // make it colorful
                        viewAssignedJobs.Columns.Add(btn);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading assigned jobs: " + ex.Message);
                }
            }
        }

        private void viewAssignedJobs_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (viewAssignedJobs.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex >= 0)
            {
                int jobId = Convert.ToInt32(viewAssignedJobs.Rows[e.RowIndex].Cells["JobID"].Value);
                int driverId = Session.LoggedInDriverID;

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    // Track completion in memory
                    if (!jobCompletions.ContainsKey(jobId))
                        jobCompletions[jobId] = new HashSet<int>();

                    jobCompletions[jobId].Add(driverId);

                    // Get total number of drivers assigned for the job
                    SqlCommand countCmd = new SqlCommand(@"
                SELECT COUNT(DISTINCT TU.DriverID)
                FROM Load L
                INNER JOIN TransportUnit TU ON L.TransportUnitID = TU.TransportUnitID
                WHERE L.JobID = @JobID", con);
                    countCmd.Parameters.AddWithValue("@JobID", jobId);
                    int totalDrivers = (int)countCmd.ExecuteScalar();

                    // If all drivers have completed
                    if (jobCompletions[jobId].Count == totalDrivers)
                    {
                        // Update job status
                        SqlCommand updateCmd = new SqlCommand("UPDATE Job SET Status = 'Completed' WHERE JobID = @JobID", con);
                        updateCmd.Parameters.AddWithValue("@JobID", jobId);
                        updateCmd.ExecuteNonQuery();

                        // Notify Customer
                        SqlCommand getCustCmd = new SqlCommand("SELECT CustomerID FROM Job WHERE JobID = @JobID", con);
                        getCustCmd.Parameters.AddWithValue("@JobID", jobId);
                        int customerId = (int)getCustCmd.ExecuteScalar();

                        SqlCommand notifyCmd = new SqlCommand(@"
                            INSERT INTO Notifications (CustomerID, Message, CreatedAt) 
                            VALUES (@CustomerID, @Message, GETDATE())", con);
                        notifyCmd.Parameters.AddWithValue("@CustomerID", customerId);
                        notifyCmd.Parameters.AddWithValue("@Message", $"Your job (Job ID: {jobId}) has been completed.");
                        notifyCmd.ExecuteNonQuery();

                        MessageBox.Show("All drivers have completed. Job marked as Completed and customer notified.");
                    }
                    else
                    {
                        MessageBox.Show("Your part marked as completed. Waiting for other drivers.");
                    }

                    LoadAssignedJobsForDriver(); // Refresh grid
                }
            }
        }

        private int GetAssignedDriverCount(int jobId)
        {
            int count = 0;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = @"
            SELECT COUNT(DISTINCT TU.DriverID)
            FROM TransportUnit TU
            INNER JOIN Load LD ON TU.TransportUnitID = LD.TransportUnitID
            WHERE LD.JobID = @JobID";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@JobID", jobId);

                count = (int)cmd.ExecuteScalar();
            }
            return count;
        }

        private void UpdateJobStatusToCompleted(int jobId)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "UPDATE Job SET Status = 'Completed' WHERE JobID = @JobID";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@JobID", jobId);
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show($"Job {jobId} is now marked as COMPLETED.");
            LoadAssignedJobsForDriver(); // Refresh table
        }
        private void viewAssignedJobs_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (viewAssignedJobs.Columns[e.ColumnIndex] is DataGridViewButtonColumn &&
                e.RowIndex >= 0)
            {
                DataGridViewButtonCell btn = (DataGridViewButtonCell)viewAssignedJobs.Rows[e.RowIndex].Cells[e.ColumnIndex];
                btn.Style.BackColor = Color.MediumSeaGreen;
                btn.Style.ForeColor = Color.White;
                btn.Style.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            }
        }

        public DefaultDriverDashboard()
        {
            InitializeComponent();
            viewAssignedJobs.CellClick += viewAssignedJobs_CellClick;
            viewAssignedJobs.CellFormatting += viewAssignedJobs_CellFormatting;
        }

        private void DefaultDriverDashboard_Load(object sender, EventArgs e)
        {
            LoadAssignedJobsForDriver();
        }

        

        private void completedBtn_Click(object sender, EventArgs e)
        {
            
        }

        

        private void viewAssignedJobs_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }

}
