﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace E_Shift
{
    public partial class login : Form
    {
        // connecting the database
        SqlConnection con = new SqlConnection(
            @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True");

        public login()
        {
            InitializeComponent();
        }

        // ✅ Hashing Method (SHA256)
        public static string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        // Login Button Click
        private void loginBtn_Click(object sender, EventArgs e)
        {
            string userName = userNameTxt.Text.Trim();
            string enteredPassword = passwordTxt.Text;
            string hashedPassword = HashPassword(enteredPassword);

            if (userRoleCBox.SelectedItem == null)
            {
                MessageBox.Show("Please select a role.");
                return;
            }

            string role = userRoleCBox.SelectedItem.ToString();

            try
            {
                con.Open();
                string query = "SELECT COUNT(*) FROM Users WHERE Username = @Username AND PasswordHash = @Password AND Role = @Role";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Username", userName);
                cmd.Parameters.AddWithValue("@Password", hashedPassword);
                cmd.Parameters.AddWithValue("@Role", role);

                if (role == "Customer")
                {
                    SqlCommand cmd1 = new SqlCommand("SELECT CustomerID FROM Customers WHERE Email = @Username", con);
                    cmd1.Parameters.AddWithValue("@Username", userName); // Assuming Email == Username
                    SqlDataReader sdr = cmd1.ExecuteReader();

                    if (sdr.Read())
                    {
                        Session.LoggedInCustomerID = Convert.ToInt32(sdr["CustomerID"]);
                    }
                    sdr.Close();
                }
                else if (role == "Driver")
                {
                    SqlCommand cmd1 = new SqlCommand("SELECT DriverID FROM Driver WHERE LicenseNumber = @Username", con);
                    cmd1.Parameters.AddWithValue("@Username", userName);
                    SqlDataReader sdr1 = cmd1.ExecuteReader();

                    if (sdr1.Read())
                    {
                        Session.LoggedInDriverID = Convert.ToInt32(sdr1["DriverID"]);
                    }
                    else
                    {
                        MessageBox.Show("Driver not found.");
                    }
                    sdr1.Close();
                }
                else if (role == "Assistant")
                {
                    SqlCommand cmd2 = new SqlCommand("SELECT AssistantID FROM Assistant WHERE NIC = @Username", con);
                    cmd2.Parameters.AddWithValue("@Username", userName);
                    SqlDataReader sdr2 = cmd2.ExecuteReader();

                    if (sdr2.Read())
                    {
                        Session.LoggedInAssistantID = Convert.ToInt32(sdr2["AssistantID"]);
                    }
                    else
                    {
                        MessageBox.Show("Assistant not found.");
                    }
                    sdr2.Close();
                }



                int count = (int)cmd.ExecuteScalar();

                if (count == 1)
                {
                    this.Hide();
                    switch (role)
                    {
                        case "Admin":
                            new AdminDashboard().Show();
                            break;
                        case "Driver":
                            new DriverDashboard().Show();
                            break;
                        case "Assistant":
                            new AssistantDashboard().Show();
                            break;
                        case "Customer":
                            new CustomerDashboard().Show();
                            break;
                    }
                }
                else
                {
                    errorMessage.Visible = true;
                    passwordTxt.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        // Show/Hide Password
        private void showPasswordCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            passwordTxt.UseSystemPasswordChar = !showPasswordCheckBox.Checked;
        }

        private void login_Load(object sender, EventArgs e)
        {
            passwordTxt.UseSystemPasswordChar = true;
            errorMessage.Visible = false;

            // Optional: populate roles manually
            userRoleCBox.Items.Clear();
            userRoleCBox.Items.Add("Admin");
            userRoleCBox.Items.Add("Driver");
            userRoleCBox.Items.Add("Assistant");
            userRoleCBox.Items.Add("Customer");
        }

        private void registerLinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            CustomerRegister customerRegisterForm = new CustomerRegister();
            customerRegisterForm.Show();
            this.Hide();
        }
    }
}
