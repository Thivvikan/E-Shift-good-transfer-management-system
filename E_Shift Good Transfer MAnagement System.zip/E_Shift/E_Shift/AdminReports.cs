﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using LiveCharts;
using LiveCharts.WinForms;
using LiveCharts.Wpf;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Data;
using System.Data.SqlClient;

namespace E_Shift
{
    public partial class AdminReports : UserControl
    {
        // connection string
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True";

        private string[] chartLabels;
        private List<int> chartValues;
        private LiveCharts.WinForms.CartesianChart currentChart;
        int currentYear = DateTime.Now.Year;

        public AdminReports()
        {
            InitializeComponent();

            // Wire up DataGridView download buttons
            this.downloadRecentlyAddedJobsBtn.Click += downloadRecentlyAddedJobsBtn_Click;
            this.downloadTopCustomersBtn.Click += downloadTopCustomersBtn_Click;
        }

        private void AdminReports_Load(object sender, EventArgs e)
        {
            
            for (int i = currentYear; i >= currentYear - 4; i--)
                yearComboBox.Items.Add(i);

            yearComboBox.SelectedItem = currentYear;
            pieChartYearComboBox.SelectedItem = currentYear;

            viewTypeComboBox.Items.Add("Monthly");
            viewTypeComboBox.Items.Add("Weekly");
            viewTypeComboBox.SelectedItem = "Monthly";

            // Remove empty month name (13th blank entry)
            string[] monthNames = System.Globalization.DateTimeFormatInfo.InvariantInfo.MonthNames;
            foreach (string month in monthNames)
            {
                if (!string.IsNullOrWhiteSpace(month))
                    monthCB.Items.Add(month);
            }

            if (monthCB.Items.Count > 0)
            {
                monthCB.SelectedIndex = DateTime.Now.Month - 1;
            }
            // after selecting index
            int selectedYear = currentYear;
            int selectedMonth = monthCB.SelectedIndex + 1;
            string selectedMonthFormatted = $"{selectedYear}-{selectedMonth:D2}";

            ShowJobStatusPieChart(selectedMonthFormatted);

            UpdateGraph();
            LoadRecentlyAddedJobs();
            LoadTopCustomers();
            StyleDataGridView(recentlyAddedJobsGrid);
            StyleDataGridView(topCustomersGrid);
        }

        private void yearComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateGraph();
        }

        private void viewTypeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateGraph();
        }

        private void monthCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (monthCB.SelectedIndex >= 0 && yearComboBox.SelectedItem != null)
            {
                int year = (int)yearComboBox.SelectedItem;
                int month = monthCB.SelectedIndex + 1;
                string formattedMonth = $"{year}-{month.ToString("D2")}";
                ShowJobStatusPieChart(formattedMonth);
            }
        }

        // line graph create and view
        private void UpdateGraph()
        {
            if (yearComboBox.SelectedItem == null || viewTypeComboBox.SelectedItem == null)
                return;

            int selectedYear = (int)yearComboBox.SelectedItem;
            string viewType = viewTypeComboBox.SelectedItem.ToString();

            totalJobsGB.Controls.Clear();
            chartLabels = null;
            chartValues = new List<int>();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;

                if (viewType == "Monthly")
                {
                    chartLabels = new[]
                    {
                        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
                    };
                    cmd.CommandText = @" SELECT MONTH(JobDate) AS Month, COUNT(*) AS Total FROM Job
                                WHERE YEAR(JobDate) = @Year
                                GROUP BY MONTH(JobDate)
                                ORDER BY Month";

                    cmd.Parameters.AddWithValue("@Year", selectedYear);
                    int[] monthlyData = new int[12]; // default 0 for all months
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int month = reader.GetInt32(0);
                            int total = reader.GetInt32(1);
                            monthlyData[month - 1] = total;
                        }
                    }
                    chartValues.AddRange(monthlyData);
                    }
                        else if (viewType == "Weekly")
                    {
                        chartLabels = new string[52];
                        for (int i = 0; i < 52; i++)
                            chartLabels[i] = $"Wk{i + 1}";

                        cmd.CommandText = @"SELECT DATEPART(WEEK, JobDate) AS WeekNumber, COUNT(*) AS Total FROM Job
                                    WHERE YEAR(JobDate) = @Year
                                    GROUP BY DATEPART(WEEK, JobDate)
                                    ORDER BY WeekNumber";
                        cmd.Parameters.AddWithValue("@Year", selectedYear);
                        int[] weeklyData = new int[52];
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                        {
                            int week = reader.GetInt32(0);
                            int total = reader.GetInt32(1);
                            if (week >= 1 && week <= 52)
                                weeklyData[week - 1] = total;
                        }
                    }
                    chartValues.AddRange(weeklyData);
                }
            }
            currentChart = new LiveCharts.WinForms.CartesianChart
            {
                Dock = DockStyle.Fill,
                Series = new SeriesCollection
                {
                    new LineSeries
                    {
                        Title = "Jobs",
                        Values = new ChartValues<int>(chartValues),
                        PointGeometry = DefaultGeometries.Circle,
                        PointGeometrySize = 8
                    }
                },
                AxisX = new AxesCollection
                {
                    new Axis
                    {
                        Title = $"{viewType} - {selectedYear}",
                        Labels = chartLabels,
                        LabelsRotation = viewType == "Weekly" ? 45 : 0,
                        Separator = new Separator { Step = viewType == "Weekly" ? 4 : 1 }
                    }
                },
                        AxisY = new AxesCollection
                {
                    new Axis
                    {
                        Title = "Total Jobs"
                    }
                }
            };
            totalJobsGB.Controls.Add(currentChart);
        }


        private void ExportGraphAndDataToPdf(string filePath, string title, string[] labels, List<int> values, LiveCharts.WinForms.CartesianChart chartControl)
        {
            Document doc = new Document(PageSize.A4, 20, 20, 20, 20);
            PdfWriter.GetInstance(doc, new FileStream(filePath, FileMode.Create));
            doc.Open();

            var titleFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 16);
            doc.Add(new Paragraph(title, titleFont));
            doc.Add(new Paragraph("\n"));

            using (MemoryStream chartStream = new MemoryStream())
            {
                Bitmap bmp = new Bitmap(chartControl.Width, chartControl.Height);
                chartControl.DrawToBitmap(bmp, new System.Drawing.Rectangle(0, 0, bmp.Width, bmp.Height));
                bmp.Save(chartStream, ImageFormat.Png);

                iTextSharp.text.Image chartImage = iTextSharp.text.Image.GetInstance(chartStream.ToArray());
                chartImage.Alignment = Element.ALIGN_CENTER;
                chartImage.ScaleToFit(500f, 300f);
                doc.Add(chartImage);
            }

            doc.Add(new Paragraph("\n"));

            PdfPTable table = new PdfPTable(2);
            table.WidthPercentage = 80;
            table.HorizontalAlignment = Element.ALIGN_CENTER;

            table.AddCell("Label");
            table.AddCell("Value");

            for (int i = 0; i < labels.Length; i++)
            {
                table.AddCell(labels[i]);
                table.AddCell(values[i].ToString());
            }

            doc.Close();
        }

        private void downloadBtn_Click(object sender, EventArgs e)
        {
            if (yearComboBox.SelectedItem == null || viewTypeComboBox.SelectedItem == null)
            {
                MessageBox.Show("Please select both Year and View Type.");
                return;
            }

            int selectedYear = (int)yearComboBox.SelectedItem;
            string viewType = viewTypeComboBox.SelectedItem.ToString();

            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "PDF file (*.pdf)|*.pdf";
                sfd.FileName = $"{viewType}_Report_{selectedYear}.pdf";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    ExportGraphAndDataToPdf(sfd.FileName, $"{viewType} Job Report - {selectedYear}", chartLabels, chartValues, currentChart);
                    MessageBox.Show("PDF report saved successfully!");
                }
            }
        }

        // Pie chart creation and view
        private void ShowJobStatusPieChart(string selectedMonth)
        {
            jobStatusGB.Controls.Clear();

            int completed = 0, inProgress = 0, approved = 0, pending = 0;

            try
            {
                // Parse the selectedMonth properly
                if (!DateTime.TryParseExact(selectedMonth, "yyyy-MM", null, System.Globalization.DateTimeStyles.None, out DateTime startDate))
                {
                    MessageBox.Show("Invalid month format: " + selectedMonth);
                    return;
                }

                DateTime endDate = startDate.AddMonths(1);

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string query = @"SELECT Status, COUNT(*) AS Count FROM Job
                             WHERE JobDate >= @StartDate AND JobDate < @EndDate
                             GROUP BY Status";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@StartDate", startDate);
                        cmd.Parameters.AddWithValue("@EndDate", endDate);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string status = reader["Status"].ToString();
                                int count = Convert.ToInt32(reader["Count"]);

                                switch (status)
                                {
                                    case "Completed":
                                        completed = count;
                                        break;
                                    case "In Progress":
                                        inProgress = count;
                                        break;
                                    case "Approved":
                                        approved = count;
                                        break;
                                    case "Pending":
                                        pending = count;
                                        break;
                                }
                            }
                        }
                    }
                }

                if (completed + inProgress + pending + approved == 0)
                {
                    MessageBox.Show("No job data found for: " + selectedMonth);
                    return;
                }

                var pieChart = new LiveCharts.WinForms.PieChart
                {
                    Dock = DockStyle.Fill,
                    Series = new SeriesCollection
            {
                new PieSeries
                {
                    Title = "Completed",
                    Values = new ChartValues<int> { completed },
                    DataLabels = true
                },
                new PieSeries
                {
                    Title = "In Progress",
                    Values = new ChartValues<int> { inProgress },
                    DataLabels = true
                },
                new PieSeries
                {
                    Title = "Approved",
                    Values = new ChartValues<int> { approved },
                    DataLabels = true
                },
                new PieSeries
                {
                    Title = "Pending",
                    Values = new ChartValues<int> { pending },
                    DataLabels = true
                }
            }
                };

                pieChart.Tag = new Dictionary<string, int>
        {
            { "Completed", completed },
            { "In Progress", inProgress },
            { "Pending", pending }
        };

                jobStatusGB.Controls.Add(pieChart);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading pie chart:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void statusReportDownloadBtn_Click(object sender, EventArgs e)
        {
            string selectedMonth = monthCB.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(selectedMonth))
            {
                MessageBox.Show("Please select a month.");
                return;
            }

            if (jobStatusGB.Controls.Count == 0 || !(jobStatusGB.Controls[0] is LiveCharts.WinForms.PieChart pieChart))
            {
                MessageBox.Show("Chart not found.");
                return;
            }

            Bitmap chartImage = new Bitmap(pieChart.Width, pieChart.Height);
            pieChart.DrawToBitmap(chartImage, new System.Drawing.Rectangle(0, 0, pieChart.Width, pieChart.Height));

            var chartData = pieChart.Tag as Dictionary<string, int>;

            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "PDF File|*.pdf";
                sfd.FileName = $"JobStatusReport_{selectedMonth}.pdf";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    SavePieChartReportAsPdf(sfd.FileName, chartImage, chartData, selectedMonth);
                    MessageBox.Show("Status report saved successfully.");
                }
            }
        }

        private void SavePieChartReportAsPdf(string filePath, Bitmap chartImage, Dictionary<string, int> data, string month)
        {
            using (FileStream fs = new FileStream(filePath, FileMode.Create))
            {
                Document doc = new Document(PageSize.A4);
                PdfWriter.GetInstance(doc, fs);
                doc.Open();

                var titleFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 16);
                doc.Add(new Paragraph($"Job Status Report - {month}", titleFont));
                doc.Add(new Paragraph(" "));

                using (MemoryStream ms = new MemoryStream())
                {
                    chartImage.Save(ms, ImageFormat.Png);
                    iTextSharp.text.Image chartImg = iTextSharp.text.Image.GetInstance(ms.ToArray());
                    chartImg.ScaleToFit(500f, 300f);
                    chartImg.Alignment = Element.ALIGN_CENTER;
                    doc.Add(chartImg);
                }

                doc.Add(new Paragraph("\nJob Status Data Table:\n"));

                PdfPTable table = new PdfPTable(2);
                table.AddCell("Status");
                table.AddCell("Count");

                foreach (var kvp in data)
                {
                    table.AddCell(kvp.Key);
                    table.AddCell(kvp.Value.ToString());
                }

                doc.Close();
            }
        }

        // Export DataGridView to PDF (shared for both tables)
        private void ExportDataGridViewToPdf(DataGridView dgv, string filePath, string title)
        {
            using (FileStream fs = new FileStream(filePath, FileMode.Create))
            {
                Document doc = new Document(PageSize.A4, 20f, 20f, 20f, 20f);
                PdfWriter.GetInstance(doc, fs);
                doc.Open();

                var titleFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 16);
                var cellFont = FontFactory.GetFont(FontFactory.HELVETICA, 10);

                doc.Add(new Paragraph(title, titleFont));
                doc.Add(new Paragraph("\n"));

                PdfPTable table = new PdfPTable(dgv.Columns.Count);
                table.WidthPercentage = 100;

                foreach (DataGridViewColumn column in dgv.Columns)
                {
                    PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText, FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 11)));
                    cell.BackgroundColor = new BaseColor(200, 200, 200);
                    table.AddCell(cell);
                }

                foreach (DataGridViewRow row in dgv.Rows)
                {
                    if (!row.IsNewRow)
                    {
                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            table.AddCell(new Phrase(cell.Value?.ToString() ?? "", cellFont));
                        }
                    }
                }

                doc.Add(table);
                doc.Close();
            }
        }

        // Button Click for Recently Added Jobs
        private void downloadRecentlyAddedJobsBtn_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "PDF File|*.pdf";
                sfd.FileName = "RecentlyAddedJobs.pdf";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    ExportDataGridViewToPdf(recentlyAddedJobsGrid, sfd.FileName, "Recently Added Jobs Report");
                    MessageBox.Show("PDF exported successfully!");
                }
            }
        }

        // Button Click for Top Customers
        private void downloadTopCustomersBtn_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "PDF File|*.pdf";
                sfd.FileName = "TopCustomersReport.pdf";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    ExportDataGridViewToPdf(topCustomersGrid, sfd.FileName, "Top Customers Report");
                    MessageBox.Show("PDF exported successfully!");
                }
            }
        }

        private void LoadRecentlyAddedJobs()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"SELECT TOP 10 J.JobID, C.FullName AS Customers, 
                                FORMAT(J.JobDate, 'yyyy-MM-dd') AS Date, 
                                J.Status
                         FROM Job J
                         JOIN Customers C ON J.CustomerID = C.CustomerID
                         ORDER BY J.JobDate DESC";

                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                recentlyAddedJobsGrid.DataSource = dt;
            }
        }

        private void LoadTopCustomers()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"SELECT TOP 10 C.FullName AS Customers,
                                COUNT(J.JobID) AS [Total Jobs],
                                MAX(J.JobDate) AS [Last Job Date]
                         FROM Job J
                         JOIN Customers C ON J.CustomerID = C.CustomerID
                         GROUP BY C.FullName
                         ORDER BY COUNT(J.JobID) DESC";

                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                topCustomersGrid.DataSource = dt;
            }
        }

        private void StyleDataGridView(DataGridView dgv)
        {
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.Navy;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 10, FontStyle.Bold);
            dgv.ColumnHeadersHeight = 35;

            dgv.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 10);
            dgv.DefaultCellStyle.BackColor = Color.White;
            dgv.DefaultCellStyle.SelectionBackColor = Color.LightBlue;
            dgv.DefaultCellStyle.SelectionForeColor = Color.Black;

            dgv.RowTemplate.Height = 30;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 248, 255); // light blue
            dgv.GridColor = Color.LightGray;

            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.BorderStyle = BorderStyle.None;
        }

        private void topCustomersGrid_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (topCustomersGrid.Columns[e.ColumnIndex].HeaderText == "Total Jobs")
            {
                if (int.TryParse(e.Value?.ToString(), out int jobs) && jobs >= 20)
                {
                    topCustomersGrid.Rows[e.RowIndex].DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 10, FontStyle.Bold);
                    topCustomersGrid.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.LightGoldenrodYellow;
                }
            }
        }

        
        private void pieChartYearComboBox_TextChanged(object sender, EventArgs e)
        {
            for (int i = currentYear; i >= currentYear - 4; i--)
                pieChartYearComboBox.Items.Add(i);
            int selectedYear = (int)pieChartYearComboBox.SelectedItem;
            int selectedMonth = monthCB.SelectedIndex + 1;
            string selectedMonthFormatted = $"{selectedYear}-{selectedMonth:D2}";

            ShowJobStatusPieChart(selectedMonthFormatted);
        }

        private void monthCB_TextChanged(object sender, EventArgs e)
        {
            for (int i = currentYear; i >= currentYear - 4; i--)
                pieChartYearComboBox.Items.Add(i);
            int selectedYear = currentYear;
            int selectedMonth = monthCB.SelectedIndex + 1;
            string selectedMonthFormatted = $"{selectedYear}-{selectedMonth:D2}";

            ShowJobStatusPieChart(selectedMonthFormatted);
        }

        private void statusReportDownloadBtn_Click_1(object sender, EventArgs e)
        {
            // Ensure month and year are selected
            if (monthCB.SelectedIndex < 0 || pieChartYearComboBox.SelectedItem == null)
            {
                MessageBox.Show("Please select both Year and Month.");
                return;
            }

            // Get selected year & month
            int selectedYear = (int)pieChartYearComboBox.SelectedItem;
            int selectedMonth = monthCB.SelectedIndex + 1;
            string selectedMonthName = monthCB.SelectedItem.ToString();
            string selectedMonthFormatted = $"{selectedYear}-{selectedMonth:D2}";

            // Get the pie chart control
            if (jobStatusGB.Controls.Count == 0 || !(jobStatusGB.Controls[0] is LiveCharts.WinForms.PieChart pieChart))
            {
                MessageBox.Show("No pie chart found to export.");
                return;
            }

            // Get the chart as image
            Bitmap chartImage = new Bitmap(pieChart.Width, pieChart.Height);
            pieChart.DrawToBitmap(chartImage, new System.Drawing.Rectangle(0, 0, pieChart.Width, pieChart.Height));

            // Get the data stored in Tag
            var chartData = pieChart.Tag as Dictionary<string, int>;
            if (chartData == null || chartData.Count == 0)
            {
                MessageBox.Show("No data found for this chart.");
                return;
            }

            // Save PDF
            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "PDF File|*.pdf";
                sfd.FileName = $"JobStatusReport_{selectedYear}_{selectedMonthName}.pdf";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    SavePieChartReportAsPdf(sfd.FileName,
                                            chartImage,
                                            chartData,
                                            $"{selectedMonthName} {selectedYear}");
                    MessageBox.Show("Pie chart report saved successfully!");
                }
            }
        }

        
    }
}
