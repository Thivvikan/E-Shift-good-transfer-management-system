﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E_Shift
{
    public partial class AssistantDashboard : Form
    {
        public AssistantDashboard()
        {
            InitializeComponent();
        }

        private void LoadUserControl(UserControl uc)
        {
            mainContentArea.Controls.Clear();
            uc.Dock = DockStyle.Fill;
            mainContentArea.Controls.Add(uc);
        }

        private void dashboardBtn_Click(object sender, EventArgs e)
        {
            LoadUserControl(new DefaultAssistantDashboard());
        }

        private void logoutBtn_Click(object sender, EventArgs e)
        {
            login loginForm = new login();
            loginForm.Show();
            this.Hide();
        }

        private void AssistantDashboard_Load(object sender, EventArgs e)
        {
            LoadUserControl(new DefaultAssistantDashboard());
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            LoadUserControl(new DefaultAssistantDashboard());
        }

        private void manageEmployeeProfileBtn_Click(object sender, EventArgs e)
        {
            LoadUserControl(new AssistantManageProfile());
        }

        private void mainContentArea_Paint(object sender, PaintEventArgs e)
        {
            mainContentArea.AutoScroll = true;

            for (int i = 0; i < 20; i++)
            {
                Label lbl = new Label();
                lbl.Text = "Label " + i;
                // Position labels so they are staggered vertically AND pushed to the right beyond panel width
                lbl.Location = new Point(10 + (i * 20), i * 30);
                lbl.Size = new Size(150, 25);
                mainContentArea.Controls.Add(lbl);
            }
        }
    }
}
