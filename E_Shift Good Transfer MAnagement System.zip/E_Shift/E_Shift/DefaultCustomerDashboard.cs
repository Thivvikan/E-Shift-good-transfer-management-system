﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace E_Shift
{
    public partial class DefaultCustomerDashboard : UserControl
    {
        // connection string
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True";

        public DefaultCustomerDashboard()
        {
            InitializeComponent();
        }

        private void LoadCustomerNotifications()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "SELECT Message, CreatedAt FROM Notifications WHERE CustomerID = @CustomerID ORDER BY CreatedAt DESC";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@CustomerID", Session.LoggedInCustomerID); // assuming Session holds this

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    customerNotificationsDGV.DataSource = dt; // bind to your DataGridView or ListBox
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading notifications: " + ex.Message);
                }
            }
        }

        private void LoadCustomerEnquiries()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = @"SELECT EnquiryDescription, 
                                    ISNULL(Reply, 'No reply yet') AS Reply
                             FROM Enquiry
                             WHERE CustomerID = @CustomerID
                             ORDER BY EnquiryID DESC";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@CustomerID", Session.LoggedInCustomerID);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    enquiriesDGV.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading enquiries: " + ex.Message);
                }
            }
        }

        private void DefaultCustomerDashboard_Load(object sender, EventArgs e)
        {
            LoadCustomerNotifications();
            LoadCustomerEnquiries();
        }
    }
}
