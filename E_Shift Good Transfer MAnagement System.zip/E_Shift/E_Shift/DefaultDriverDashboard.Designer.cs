﻿namespace E_Shift
{
    partial class DefaultDriverDashboard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.viewAssignedJobs = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.viewAssignedJobs)).BeginInit();
            this.SuspendLayout();
            // 
            // viewAssignedJobs
            // 
            this.viewAssignedJobs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.viewAssignedJobs.Location = new System.Drawing.Point(19, 90);
            this.viewAssignedJobs.Name = "viewAssignedJobs";
            this.viewAssignedJobs.RowHeadersWidth = 51;
            this.viewAssignedJobs.RowTemplate.Height = 29;
            this.viewAssignedJobs.Size = new System.Drawing.Size(774, 184);
            this.viewAssignedJobs.TabIndex = 53;
            this.viewAssignedJobs.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.viewAssignedJobs_CellContentClick);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Sylfaen", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(19, 51);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(146, 26);
            this.label6.TabIndex = 52;
            this.label6.Text = "Jobs Assigned:";
            // 
            // DefaultDriverDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.viewAssignedJobs);
            this.Controls.Add(this.label6);
            this.Name = "DefaultDriverDashboard";
            this.Size = new System.Drawing.Size(834, 481);
            this.Load += new System.EventHandler(this.DefaultDriverDashboard_Load);
            ((System.ComponentModel.ISupportInitialize)(this.viewAssignedJobs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView viewAssignedJobs;
        private Label label6;
    }
}
