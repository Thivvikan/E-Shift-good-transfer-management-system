﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E_Shift
{
    public partial class AdminDashboard : Form
    {
        public AdminDashboard()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            LoadUserControl(new ManageNotifications(this));
        }

        private void button8_Click(object sender, EventArgs e)
        {
            LoadUserControl(new ManageEmployees());
        }

        private void AdminDashboard_Load(object sender, EventArgs e)
        {
            LoadUserControl(new CalenderView());
        }

        public void LoadUserControl(UserControl uc)
        {
            mainContentArea.Controls.Clear();
            uc.Dock = DockStyle.Fill;
            mainContentArea.Controls.Add(uc);
        }

        private void dashboardBtn_Click(object sender, EventArgs e)
        {
            LoadUserControl(new CalenderView());
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            LoadUserControl(new CalenderView());
        }

        private void mainContentArea_Paint(object sender, PaintEventArgs e)
        {
            mainContentArea.AutoScroll = true;

            for (int i = 0; i < 20; i++)
            {
                Label lbl = new Label();
                lbl.Text = "Label " + i;
                // Position labels so they are staggered vertically AND pushed to the right beyond panel width
                lbl.Location = new Point(10 + (i * 20), i * 30);
                lbl.Size = new Size(150, 25);
                //mainContentArea.Controls.Add(lbl);
            }


        }

        private void manageCustomerBtn_Click(object sender, EventArgs e)
        {
            LoadUserControl(new ManageCustomersControl());
        }

        private void manageJobsBtn_Click(object sender, EventArgs e)
        {
            LoadUserControl(new ManageJobs(this));
        }

        private void manageTransportUnitsBtn_Click(object sender, EventArgs e)
        {
            LoadUserControl(new ManageTransportUnit());
        }

        private void manageLoadBtn_Click(object sender, EventArgs e)
        {
            LoadUserControl(new ManageLoad(this));
        }

        private void manageLorryAndContainerBtn_Click(object sender, EventArgs e)
        {
            LoadUserControl(new ManageLorryAndContainer());
        }

        private void reportsBtn_Click(object sender, EventArgs e)
        {
            LoadUserControl(new AdminReports());
        }

        private void feedbackBtn_Click(object sender, EventArgs e)
        {
            LoadUserControl(new CustomerFeedbacks());
        }

        private void logoutBtn_Click(object sender, EventArgs e)
        {
            login loginForm = new login();
            loginForm.Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            LoadUserControl(new ManageAdminProfile());
        }
    }
}
