﻿namespace E_Shift
{
    partial class DefaultAssistantDashboard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.viewAssignedJobs = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.viewAssignedJobs)).BeginInit();
            this.SuspendLayout();
            // 
            // viewAssignedJobs
            // 
            this.viewAssignedJobs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.viewAssignedJobs.Location = new System.Drawing.Point(24, 125);
            this.viewAssignedJobs.Name = "viewAssignedJobs";
            this.viewAssignedJobs.RowHeadersWidth = 51;
            this.viewAssignedJobs.RowTemplate.Height = 29;
            this.viewAssignedJobs.Size = new System.Drawing.Size(790, 184);
            this.viewAssignedJobs.TabIndex = 55;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Sylfaen", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(24, 86);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(146, 26);
            this.label6.TabIndex = 54;
            this.label6.Text = "Jobs Assigned:";
            // 
            // DefaultAssistantDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.viewAssignedJobs);
            this.Controls.Add(this.label6);
            this.Name = "DefaultAssistantDashboard";
            this.Size = new System.Drawing.Size(869, 576);
            this.Load += new System.EventHandler(this.DefaultAssistantDashboard_Load);
            ((System.ComponentModel.ISupportInitialize)(this.viewAssignedJobs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView viewAssignedJobs;
        private Label label6;
    }
}
