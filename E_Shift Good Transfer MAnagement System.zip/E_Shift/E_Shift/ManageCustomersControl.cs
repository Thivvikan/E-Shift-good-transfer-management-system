﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace E_Shift
{
    public partial class ManageCustomersControl : UserControl
    {
        // connection string
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True";

        public ManageCustomersControl()
        {
            InitializeComponent();
        }

        private void LoadCustomerDetails()
        {
            string query = "SELECT CustomerID, FullName, NIC, ContactNo, Email, Address, Location FROM Customers";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    viewCustomers.DataSource = dt;

                    // Auto-size columns
                    viewCustomers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading customer details: " + ex.Message);
                }
            }
        }

        private void ManageCustomersControl_Load(object sender, EventArgs e)
        {
            LoadCustomerDetails();
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
                string query = @"UPDATE Customers SET 
                        FullName = @FullName,
                        NIC = @NIC,
                        ContactNo = @ContactNo,
                        Email = @Email,
                        Address = @Address,
                        Location = @Location
                    WHERE CustomerID = @CustomerID";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    try
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand(query, conn);
                        cmd.Parameters.AddWithValue("@CustomerID", idTxt.Text);
                        cmd.Parameters.AddWithValue("@FullName", fullNameTxt.Text);
                        cmd.Parameters.AddWithValue("@NIC", NICTxt.Text);
                        cmd.Parameters.AddWithValue("@ContactNo", contactNoTxt.Text);
                        cmd.Parameters.AddWithValue("@Email", emailTxt.Text);
                        cmd.Parameters.AddWithValue("@Address", addressTxt.Text);
                        cmd.Parameters.AddWithValue("@Location", locationTxt.Text);

                        int rows = cmd.ExecuteNonQuery();
                        if (rows > 0)
                        {
                            MessageBox.Show("Customer updated successfully!");
                            LoadCustomerDetails(); // refresh DataGridView
                        }
                        else
                        {
                            MessageBox.Show("Customer not found.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error updating customer: " + ex.Message);
                    }
                }
           
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
                string query = "DELETE FROM Customers WHERE CustomerID = @CustomerID";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    try
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand(query, conn);
                        cmd.Parameters.AddWithValue("@CustomerID", idTxt.Text);

                        DialogResult result = MessageBox.Show("Are you sure you want to delete this customer?", "Confirm Delete", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {
                            int rows = cmd.ExecuteNonQuery();
                            if (rows > 0)
                            {
                                MessageBox.Show("Customer deleted successfully!");
                                LoadCustomerDetails(); // refresh DataGridView
                            }
                            else
                            {
                                MessageBox.Show("Customer not found.");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error deleting customer: " + ex.Message);
                    }
                }
        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            string customerID = idTxt.Text.Trim();
            string fullName = fullNameTxt.Text.Trim();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    if (!string.IsNullOrEmpty(customerID))
                    {
                        // Search by Customer ID
                        string idQuery = "SELECT * FROM Customers WHERE CustomerID = @CustomerID";
                        SqlCommand idCmd = new SqlCommand(idQuery, conn);
                        idCmd.Parameters.AddWithValue("@CustomerID", customerID);

                        SqlDataAdapter idAdapter = new SqlDataAdapter(idCmd);
                        DataTable idTable = new DataTable();
                        idAdapter.Fill(idTable);

                        if (idTable.Rows.Count == 1)
                        {
                            FillCustomerTextboxes(idTable.Rows[0]);
                            LoadCustomerJobs(customerID);
                            return;
                        }
                        else
                        {
                            MessageBox.Show("No customer found with that ID.");
                            return;
                        }
                    }
                    else if (!string.IsNullOrEmpty(fullName))
                    {
                        // Search by Full Name (partial match)
                        string nameQuery = "SELECT * FROM Customers WHERE FullName LIKE @FullName";
                        SqlCommand nameCmd = new SqlCommand(nameQuery, conn);
                        nameCmd.Parameters.AddWithValue("@FullName", "%" + fullName + "%");

                        SqlDataAdapter nameAdapter = new SqlDataAdapter(nameCmd);
                        DataTable nameTable = new DataTable();
                        nameAdapter.Fill(nameTable);

                        if (nameTable.Rows.Count == 1)
                        {
                            FillCustomerTextboxes(nameTable.Rows[0]);
                            string foundCustomerID = nameTable.Rows[0]["CustomerID"].ToString();
                            LoadCustomerJobs(foundCustomerID);
                        }
                        else if (nameTable.Rows.Count > 1)
                        {
                            viewCustomers.DataSource = nameTable;
                            MessageBox.Show("Multiple customers found with that name. Please refine your search.");
                        }
                        else
                        {
                            MessageBox.Show("No customer found with that name.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter Customer ID or Name to search.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Search error: " + ex.Message);
                }
            }
        }

        private void FillCustomerTextboxes(DataRow row)
        {
            idTxt.Text = row["CustomerID"].ToString();
            fullNameTxt.Text = row["FullName"].ToString();
            NICTxt.Text = row["NIC"].ToString();
            contactNoTxt.Text = row["ContactNo"].ToString();
            emailTxt.Text = row["Email"].ToString();
            addressTxt.Text = row["Address"].ToString();
            locationTxt.Text = row["Location"].ToString();
        }

        private void LoadCustomerJobs(string customerID)
        {
            string query = @"SELECT * FROM Job 
                     WHERE CustomerID = @CustomerID";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@CustomerID", customerID);
                    
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable jobTable = new DataTable();
                    adapter.Fill(jobTable);

                    viewJobs.DataSource = jobTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading jobs: " + ex.Message);
                }
            }
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            idTxt.Clear();
            fullNameTxt.Clear();
            NICTxt.Clear();
            contactNoTxt.Clear();
            emailTxt.Clear();
            addressTxt.Clear();
            locationTxt.Clear();
        }

        private void viewCustomers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Ignore header clicks
            {
                DataGridViewRow selectedRow = viewCustomers.Rows[e.RowIndex];

                // Create a temporary DataRow from the selected row
                DataTable tempTable = new DataTable();
                foreach (DataGridViewColumn col in viewCustomers.Columns)
                {
                    tempTable.Columns.Add(col.Name);
                }

                DataRow dataRow = tempTable.NewRow();
                foreach (DataGridViewColumn col in viewCustomers.Columns)
                {
                    dataRow[col.Name] = selectedRow.Cells[col.Index].Value?.ToString();
                }

                // Call existing method to fill textboxes
                FillCustomerTextboxes(dataRow);

                // Also load this customer's jobs
                string selectedCustomerID = dataRow["CustomerID"].ToString();
                LoadCustomerJobs(selectedCustomerID);
            }
        }

    }
}
