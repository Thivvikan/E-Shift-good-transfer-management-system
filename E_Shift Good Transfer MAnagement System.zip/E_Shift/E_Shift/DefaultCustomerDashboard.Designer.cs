﻿namespace E_Shift
{
    partial class DefaultCustomerDashboard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.enquiriesDGV = new System.Windows.Forms.DataGridView();
            this.customerNotificationsDGV = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.enquiriesDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerNotificationsDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(25, 161);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Reply for the Enquiry";
            // 
            // enquiriesDGV
            // 
            this.enquiriesDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.enquiriesDGV.Location = new System.Drawing.Point(25, 198);
            this.enquiriesDGV.Name = "enquiriesDGV";
            this.enquiriesDGV.RowHeadersWidth = 51;
            this.enquiriesDGV.RowTemplate.Height = 29;
            this.enquiriesDGV.Size = new System.Drawing.Size(461, 169);
            this.enquiriesDGV.TabIndex = 1;
            // 
            // customerNotificationsDGV
            // 
            this.customerNotificationsDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.customerNotificationsDGV.Location = new System.Drawing.Point(25, 34);
            this.customerNotificationsDGV.Name = "customerNotificationsDGV";
            this.customerNotificationsDGV.RowHeadersWidth = 51;
            this.customerNotificationsDGV.RowTemplate.Height = 29;
            this.customerNotificationsDGV.Size = new System.Drawing.Size(461, 109);
            this.customerNotificationsDGV.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(25, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 22);
            this.label2.TabIndex = 2;
            this.label2.Text = "Job updates";
            // 
            // DefaultCustomerDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.customerNotificationsDGV);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.enquiriesDGV);
            this.Controls.Add(this.label1);
            this.Name = "DefaultCustomerDashboard";
            this.Size = new System.Drawing.Size(514, 405);
            this.Load += new System.EventHandler(this.DefaultCustomerDashboard_Load);
            ((System.ComponentModel.ISupportInitialize)(this.enquiriesDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerNotificationsDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private DataGridView enquiriesDGV;
        private DataGridView customerNotificationsDGV;
        private Label label2;
    }
}
