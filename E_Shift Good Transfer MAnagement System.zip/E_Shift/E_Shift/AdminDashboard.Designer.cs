﻿namespace E_Shift
{
    partial class AdminDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminDashboard));
            this.sidebar = new System.Windows.Forms.Panel();
            this.reportsBtn = new System.Windows.Forms.Button();
            this.manageEmployeesBtn = new System.Windows.Forms.Button();
            this.logoutBtn = new System.Windows.Forms.Button();
            this.manageLorryAndContainerBtn = new System.Windows.Forms.Button();
            this.notificationsBtn = new System.Windows.Forms.Button();
            this.manageLoadBtn = new System.Windows.Forms.Button();
            this.manageTransportUnitsBtn = new System.Windows.Forms.Button();
            this.manageJobsBtn = new System.Windows.Forms.Button();
            this.manageCustomerBtn = new System.Windows.Forms.Button();
            this.dashboardBtn = new System.Windows.Forms.Button();
            this.topBar = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.mainContentArea = new System.Windows.Forms.Panel();
            this.sidebar.SuspendLayout();
            this.topBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // sidebar
            // 
            this.sidebar.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.sidebar.BackgroundImage = global::E_Shift.Properties.Resources.R;
            this.sidebar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sidebar.Controls.Add(this.reportsBtn);
            this.sidebar.Controls.Add(this.manageEmployeesBtn);
            this.sidebar.Controls.Add(this.logoutBtn);
            this.sidebar.Controls.Add(this.manageLorryAndContainerBtn);
            this.sidebar.Controls.Add(this.notificationsBtn);
            this.sidebar.Controls.Add(this.manageLoadBtn);
            this.sidebar.Controls.Add(this.manageTransportUnitsBtn);
            this.sidebar.Controls.Add(this.manageJobsBtn);
            this.sidebar.Controls.Add(this.manageCustomerBtn);
            this.sidebar.Controls.Add(this.dashboardBtn);
            this.sidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidebar.Location = new System.Drawing.Point(0, 0);
            this.sidebar.Name = "sidebar";
            this.sidebar.Size = new System.Drawing.Size(218, 777);
            this.sidebar.TabIndex = 0;
            // 
            // reportsBtn
            // 
            this.reportsBtn.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.reportsBtn.Location = new System.Drawing.Point(12, 443);
            this.reportsBtn.Name = "reportsBtn";
            this.reportsBtn.Size = new System.Drawing.Size(189, 34);
            this.reportsBtn.TabIndex = 10;
            this.reportsBtn.Text = "Reports";
            this.reportsBtn.UseVisualStyleBackColor = true;
            this.reportsBtn.Click += new System.EventHandler(this.reportsBtn_Click);
            // 
            // manageEmployeesBtn
            // 
            this.manageEmployeesBtn.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.manageEmployeesBtn.Location = new System.Drawing.Point(12, 110);
            this.manageEmployeesBtn.Name = "manageEmployeesBtn";
            this.manageEmployeesBtn.Size = new System.Drawing.Size(189, 34);
            this.manageEmployeesBtn.TabIndex = 8;
            this.manageEmployeesBtn.Text = "Manage Employees";
            this.manageEmployeesBtn.UseVisualStyleBackColor = true;
            this.manageEmployeesBtn.Click += new System.EventHandler(this.button8_Click);
            // 
            // logoutBtn
            // 
            this.logoutBtn.BackColor = System.Drawing.Color.Red;
            this.logoutBtn.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.logoutBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.logoutBtn.Location = new System.Drawing.Point(12, 492);
            this.logoutBtn.Name = "logoutBtn";
            this.logoutBtn.Size = new System.Drawing.Size(189, 34);
            this.logoutBtn.TabIndex = 9;
            this.logoutBtn.Text = "Logout";
            this.logoutBtn.UseVisualStyleBackColor = false;
            this.logoutBtn.Click += new System.EventHandler(this.logoutBtn_Click);
            // 
            // manageLorryAndContainerBtn
            // 
            this.manageLorryAndContainerBtn.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.manageLorryAndContainerBtn.Location = new System.Drawing.Point(12, 327);
            this.manageLorryAndContainerBtn.Name = "manageLorryAndContainerBtn";
            this.manageLorryAndContainerBtn.Size = new System.Drawing.Size(189, 54);
            this.manageLorryAndContainerBtn.TabIndex = 7;
            this.manageLorryAndContainerBtn.Text = "Manage Lorry & Container";
            this.manageLorryAndContainerBtn.UseVisualStyleBackColor = true;
            this.manageLorryAndContainerBtn.Click += new System.EventHandler(this.manageLorryAndContainerBtn_Click);
            // 
            // notificationsBtn
            // 
            this.notificationsBtn.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.notificationsBtn.Location = new System.Drawing.Point(12, 395);
            this.notificationsBtn.Name = "notificationsBtn";
            this.notificationsBtn.Size = new System.Drawing.Size(189, 34);
            this.notificationsBtn.TabIndex = 5;
            this.notificationsBtn.Text = "Notifications";
            this.notificationsBtn.UseVisualStyleBackColor = true;
            this.notificationsBtn.Click += new System.EventHandler(this.button5_Click);
            // 
            // manageLoadBtn
            // 
            this.manageLoadBtn.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.manageLoadBtn.Location = new System.Drawing.Point(12, 280);
            this.manageLoadBtn.Name = "manageLoadBtn";
            this.manageLoadBtn.Size = new System.Drawing.Size(189, 34);
            this.manageLoadBtn.TabIndex = 4;
            this.manageLoadBtn.Text = "Manage Load";
            this.manageLoadBtn.UseVisualStyleBackColor = true;
            this.manageLoadBtn.Click += new System.EventHandler(this.manageLoadBtn_Click);
            // 
            // manageTransportUnitsBtn
            // 
            this.manageTransportUnitsBtn.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.manageTransportUnitsBtn.Location = new System.Drawing.Point(12, 211);
            this.manageTransportUnitsBtn.Name = "manageTransportUnitsBtn";
            this.manageTransportUnitsBtn.Size = new System.Drawing.Size(189, 55);
            this.manageTransportUnitsBtn.TabIndex = 3;
            this.manageTransportUnitsBtn.Text = "Manage Transport Units";
            this.manageTransportUnitsBtn.UseVisualStyleBackColor = true;
            this.manageTransportUnitsBtn.Click += new System.EventHandler(this.manageTransportUnitsBtn_Click);
            // 
            // manageJobsBtn
            // 
            this.manageJobsBtn.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.manageJobsBtn.Location = new System.Drawing.Point(12, 160);
            this.manageJobsBtn.Name = "manageJobsBtn";
            this.manageJobsBtn.Size = new System.Drawing.Size(189, 34);
            this.manageJobsBtn.TabIndex = 2;
            this.manageJobsBtn.Text = "Manage Jobs";
            this.manageJobsBtn.UseVisualStyleBackColor = true;
            this.manageJobsBtn.Click += new System.EventHandler(this.manageJobsBtn_Click);
            // 
            // manageCustomerBtn
            // 
            this.manageCustomerBtn.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.manageCustomerBtn.Location = new System.Drawing.Point(12, 61);
            this.manageCustomerBtn.Name = "manageCustomerBtn";
            this.manageCustomerBtn.Size = new System.Drawing.Size(189, 34);
            this.manageCustomerBtn.TabIndex = 1;
            this.manageCustomerBtn.Text = "Manage Customers";
            this.manageCustomerBtn.UseVisualStyleBackColor = true;
            this.manageCustomerBtn.Click += new System.EventHandler(this.manageCustomerBtn_Click);
            // 
            // dashboardBtn
            // 
            this.dashboardBtn.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dashboardBtn.Location = new System.Drawing.Point(12, 11);
            this.dashboardBtn.Name = "dashboardBtn";
            this.dashboardBtn.Size = new System.Drawing.Size(189, 34);
            this.dashboardBtn.TabIndex = 0;
            this.dashboardBtn.Text = "Dashboard";
            this.dashboardBtn.UseVisualStyleBackColor = true;
            this.dashboardBtn.Click += new System.EventHandler(this.dashboardBtn_Click);
            // 
            // topBar
            // 
            this.topBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.topBar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("topBar.BackgroundImage")));
            this.topBar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.topBar.Controls.Add(this.pictureBox2);
            this.topBar.Controls.Add(this.label1);
            this.topBar.Controls.Add(this.pictureBox1);
            this.topBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.topBar.Location = new System.Drawing.Point(218, 0);
            this.topBar.Name = "topBar";
            this.topBar.Size = new System.Drawing.Size(856, 77);
            this.topBar.TabIndex = 1;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(677, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(89, 68);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Sylfaen", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Brown;
            this.label1.Location = new System.Drawing.Point(161, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(386, 39);
            this.label1.TabIndex = 1;
            this.label1.Text = "Welcome Back to E-Shift...";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Image = global::E_Shift.Properties.Resources.Screenshot_2025_07_23_161129;
            this.pictureBox1.Location = new System.Drawing.Point(6, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(86, 62);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // mainContentArea
            // 
            this.mainContentArea.AutoScroll = true;
            this.mainContentArea.BackColor = System.Drawing.Color.Transparent;
            this.mainContentArea.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("mainContentArea.BackgroundImage")));
            this.mainContentArea.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.mainContentArea.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainContentArea.Location = new System.Drawing.Point(218, 77);
            this.mainContentArea.Name = "mainContentArea";
            this.mainContentArea.Size = new System.Drawing.Size(856, 700);
            this.mainContentArea.TabIndex = 2;
            this.mainContentArea.Paint += new System.Windows.Forms.PaintEventHandler(this.mainContentArea_Paint);
            // 
            // AdminDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1074, 777);
            this.Controls.Add(this.mainContentArea);
            this.Controls.Add(this.topBar);
            this.Controls.Add(this.sidebar);
            this.Name = "AdminDashboard";
            this.Text = "AdminDashboard";
            this.Load += new System.EventHandler(this.AdminDashboard_Load);
            this.sidebar.ResumeLayout(false);
            this.topBar.ResumeLayout(false);
            this.topBar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel sidebar;
        private Button logoutBtn;
        private Button manageEmployeesBtn;
        private Button manageJobsBtn;
        private Button manageCustomerBtn;
        private Button dashboardBtn;
        private Panel topBar;
        private Panel mainContentArea;
        private PictureBox pictureBox2;
        private Label label1;
        private PictureBox pictureBox1;
        private Button reportsBtn;
        private Button manageLorryAndContainerBtn;
        private Button notificationsBtn;
        private Button manageLoadBtn;
        private Button manageTransportUnitsBtn;
    }
}