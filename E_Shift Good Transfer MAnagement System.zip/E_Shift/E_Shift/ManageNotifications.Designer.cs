﻿namespace E_Shift
{
    partial class ManageNotifications
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.newJobRequestsDGV = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.replyBtn = new System.Windows.Forms.Button();
            this.replyTxt = new System.Windows.Forms.TextBox();
            this.enquiriesDGV = new System.Windows.Forms.DataGridView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.feedbackDGV = new System.Windows.Forms.DataGridView();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.newJobRequestsDGV)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.enquiriesDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.feedbackDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.newJobRequestsDGV);
            this.groupBox1.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(12, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(771, 199);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "New Job Requests";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // newJobRequestsDGV
            // 
            this.newJobRequestsDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.newJobRequestsDGV.Location = new System.Drawing.Point(3, 26);
            this.newJobRequestsDGV.Name = "newJobRequestsDGV";
            this.newJobRequestsDGV.RowHeadersWidth = 51;
            this.newJobRequestsDGV.RowTemplate.Height = 29;
            this.newJobRequestsDGV.Size = new System.Drawing.Size(758, 167);
            this.newJobRequestsDGV.TabIndex = 0;
            this.newJobRequestsDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.newJobRequestsDGV_CellContentClick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.replyBtn);
            this.groupBox2.Controls.Add(this.replyTxt);
            this.groupBox2.Controls.Add(this.enquiriesDGV);
            this.groupBox2.Controls.Add(this.dataGridView1);
            this.groupBox2.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(15, 230);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(771, 272);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Customer Enquiries";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // replyBtn
            // 
            this.replyBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.replyBtn.Location = new System.Drawing.Point(633, 193);
            this.replyBtn.Name = "replyBtn";
            this.replyBtn.Size = new System.Drawing.Size(125, 38);
            this.replyBtn.TabIndex = 5;
            this.replyBtn.Text = "Send Reply";
            this.replyBtn.UseVisualStyleBackColor = false;
            this.replyBtn.Click += new System.EventHandler(this.replyBtn_Click);
            // 
            // replyTxt
            // 
            this.replyTxt.Location = new System.Drawing.Point(3, 193);
            this.replyTxt.Multiline = true;
            this.replyTxt.Name = "replyTxt";
            this.replyTxt.PlaceholderText = "Enter your eply here...";
            this.replyTxt.Size = new System.Drawing.Size(606, 69);
            this.replyTxt.TabIndex = 4;
            // 
            // enquiriesDGV
            // 
            this.enquiriesDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.enquiriesDGV.Location = new System.Drawing.Point(3, 29);
            this.enquiriesDGV.Name = "enquiriesDGV";
            this.enquiriesDGV.RowHeadersWidth = 51;
            this.enquiriesDGV.RowTemplate.Height = 29;
            this.enquiriesDGV.Size = new System.Drawing.Size(758, 140);
            this.enquiriesDGV.TabIndex = 3;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(17, -102);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(636, 90);
            this.dataGridView1.TabIndex = 2;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.feedbackDGV);
            this.groupBox4.Controls.Add(this.dataGridView6);
            this.groupBox4.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox4.Location = new System.Drawing.Point(15, 508);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(771, 190);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Customer Feedback";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // feedbackDGV
            // 
            this.feedbackDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.feedbackDGV.Location = new System.Drawing.Point(3, 29);
            this.feedbackDGV.Name = "feedbackDGV";
            this.feedbackDGV.RowHeadersWidth = 51;
            this.feedbackDGV.RowTemplate.Height = 29;
            this.feedbackDGV.Size = new System.Drawing.Size(591, 126);
            this.feedbackDGV.TabIndex = 3;
            // 
            // dataGridView6
            // 
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Location = new System.Drawing.Point(17, -102);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.RowHeadersWidth = 51;
            this.dataGridView6.RowTemplate.Height = 29;
            this.dataGridView6.Size = new System.Drawing.Size(636, 90);
            this.dataGridView6.TabIndex = 2;
            // 
            // ManageNotifications
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "ManageNotifications";
            this.Size = new System.Drawing.Size(816, 689);
            this.Load += new System.EventHandler(this.ManageNotifications_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.newJobRequestsDGV)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.enquiriesDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.feedbackDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox1;
        private DataGridView newJobRequestsDGV;
        private GroupBox groupBox2;
        private DataGridView enquiriesDGV;
        private DataGridView dataGridView1;
        private GroupBox groupBox4;
        private DataGridView feedbackDGV;
        private DataGridView dataGridView6;
        private TextBox replyTxt;
        private Button replyBtn;
    }
}
