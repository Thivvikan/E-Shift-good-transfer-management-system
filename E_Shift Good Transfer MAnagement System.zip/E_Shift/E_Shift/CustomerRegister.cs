﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace E_Shift
{
    public partial class CustomerRegister : Form
    {
        SqlConnection con = new SqlConnection(
            @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True");

        public CustomerRegister()
        {
            InitializeComponent();
        }

        private async void CustomerRegister_Load(object sender, EventArgs e)
        {
            string locationLink = await GetLocationFromIPAsync();
            locationTxt.Text = locationLink;
        }

        public async Task<string> GetLocationFromIPAsync()
        {
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    string url = "http://ip-api.com/json/";
                    HttpResponseMessage response = await client.GetAsync(url);
                    response.EnsureSuccessStatusCode();

                    string json = await response.Content.ReadAsStringAsync();
                    JObject locationData = JObject.Parse(json);

                    string lat = locationData["lat"]?.ToString();
                    string lon = locationData["lon"]?.ToString();

                    if (!string.IsNullOrEmpty(lat) && !string.IsNullOrEmpty(lon))
                    {
                        return $"https://www.google.com/maps?q={lat},{lon}";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Failed to get location: " + ex.Message);
                }
                return "";
            }
        }

        private void showPasswordCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            createPasswordTxt.UseSystemPasswordChar = !showPasswordCheckBox.Checked;
            confirmPasswordTxt.UseSystemPasswordChar = !showPasswordCheckBox.Checked;
        }

        private void loginLinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            login loginForm = new login();
            loginForm.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }

        private bool ValidatePassword(string password)
        {
            // Check length
            if (password.Length < 8)
            {
                MessageBox.Show("Password must be at least 8 characters long.");
                return false;
            }

            // Check uppercase
            if (!password.Any(char.IsUpper))
            {
                MessageBox.Show("Password must contain at least one uppercase letter.");
                return false;
            }

            // Check lowercase
            if (!password.Any(char.IsLower))
            {
                MessageBox.Show("Password must contain at least one lowercase letter.");
                return false;
            }

            // Check number
            if (!password.Any(char.IsDigit))
            {
                MessageBox.Show("Password must contain at least one number.");
                return false;
            }

            // Check special character
            if (!password.Any(ch => !char.IsLetterOrDigit(ch)))
            {
                MessageBox.Show("Password must contain at least one special character.");
                return false;
            }

            return true;
        }
        private async void registerBtn_Click(object sender, EventArgs e)
        {
            string email = emailTxt.Text.Trim();
            string password = createPasswordTxt.Text;
            string confirmPassword = confirmPasswordTxt.Text;

            // Validate password
            if (!ValidatePassword(password))
            {
                return; // stop registration if password fails
            }

            string fullName = fullNameTxt.Text.Trim();
            string nic = NICTxt.Text.Trim();
            string contactNumber = contactNoTxt.Text.Trim();
            string address = addressTxt.Text.Trim();
            string location = locationTxt.Text.Trim();

            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password) ||
                string.IsNullOrWhiteSpace(confirmPassword) || string.IsNullOrWhiteSpace(fullName) ||
                string.IsNullOrWhiteSpace(nic) || string.IsNullOrWhiteSpace(contactNumber) ||
                string.IsNullOrWhiteSpace(address) || string.IsNullOrWhiteSpace(location))
            {
                MessageBox.Show("Please fill in all required fields.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (password != confirmPassword)
            {
                MessageBox.Show("Passwords do not match!", "Mismatch", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Password validation
            if (password.Length < 8 ||
                !password.Any(char.IsUpper) ||
                !password.Any(char.IsLower) ||
                !password.Any(char.IsDigit) ||
                !password.Any(ch => !char.IsLetterOrDigit(ch)))
            {
                MessageBox.Show("Password must be at least 8 characters long and contain at least:\n- 1 uppercase letter\n- 1 lowercase letter\n- 1 number\n- 1 special character",
                                "Weak Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string hashedPassword = HashPassword(password);

            try
            {
                con.Open();

                // Check if email already exists
                SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM Users WHERE Username = @Email", con);
                checkCmd.Parameters.AddWithValue("@Email", email);
                int exists = (int)checkCmd.ExecuteScalar();

                if (exists > 0)
                {
                    MessageBox.Show("This email is already registered.", "Already Exists", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                // Insert into Users table
                SqlCommand insertUserCmd = new SqlCommand("INSERT INTO Users (Username, PasswordHash, Role) OUTPUT INSERTED.Id VALUES (@Email, @PasswordHash, 'Customer')", con);
                insertUserCmd.Parameters.AddWithValue("@Email", email);
                insertUserCmd.Parameters.AddWithValue("@PasswordHash", hashedPassword);
                int userId = (int)insertUserCmd.ExecuteScalar();

                // Insert into Customer table
                SqlCommand insertCustomerCmd = new SqlCommand(
                    "INSERT INTO Customers (FullName, NIC, ContactNo, Address, Location, Email) " +
                    "VALUES (@FullName, @NIC, @Contact, @Address, @Location, @Email)", con);

                insertCustomerCmd.Parameters.AddWithValue("@FullName", fullName);
                insertCustomerCmd.Parameters.AddWithValue("@NIC", nic);
                insertCustomerCmd.Parameters.AddWithValue("@Contact", contactNumber);
                insertCustomerCmd.Parameters.AddWithValue("@Address", address);
                insertCustomerCmd.Parameters.AddWithValue("@Location", location);
                insertCustomerCmd.Parameters.AddWithValue("@Email", email);
                insertCustomerCmd.ExecuteNonQuery();

                MessageBox.Show("Customer registered successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide();
                login loginForm = new login();
                loginForm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
            }
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private async void refreshLocationBtn_Click(object sender, EventArgs e)
        {
            string locationLink = await GetLocationFromIPAsync();
            locationTxt.Text = locationLink;
        }
    }
}
