﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace E_Shift
{
    public partial class CustomerManageProfile : UserControl
    {
        // Connection string
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True";

        public CustomerManageProfile()
        {
            InitializeComponent();
            IDTxt.Text = Session.LoggedInCustomerID.ToString();
        }

        public async Task<string> GetLocationFromIPAsync()
        {
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    string url = "http://ip-api.com/json/";
                    HttpResponseMessage response = await client.GetAsync(url);
                    response.EnsureSuccessStatusCode();

                    string json = await response.Content.ReadAsStringAsync();
                    JObject locationData = JObject.Parse(json);

                    string lat = locationData["lat"]?.ToString();
                    string lon = locationData["lon"]?.ToString();

                    if (!string.IsNullOrEmpty(lat) && !string.IsNullOrEmpty(lon))
                    {
                        return $"https://www.google.com/maps?q={lat},{lon}";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Failed to get location: " + ex.Message);
                }
                return "";
            }
        }

        private async void refreshLocationBtn_Click(object sender, EventArgs e)
        {
            string locationLink = await GetLocationFromIPAsync();
            locationTxt.Text = locationLink;
        }

        private void CustomerManageProfile_Load(object sender, EventArgs e)
        {

        }

        public static string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        // update button code.
        private void button3_Click(object sender, EventArgs e)
        {
            string fullName = fullNameTxt.Text.Trim();
            string nic = NICTxt.Text.Trim();
            string contact = contactNoTxt.Text.Trim();
            string address = addressTxt.Text.Trim();
            string location = locationTxt.Text.Trim();
            string email = emailTxt.Text.Trim();
            string currentPassword = currentPasswordTxt.Text;
            string confirmPassword = confirmPasswordTxt.Text;

            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(currentPassword))
            {
                MessageBox.Show("Please enter your email and current password to make any changes.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    // STEP 1: Get current user password from Users table using Email
                    string getUserQuery = "SELECT PasswordHash FROM Users WHERE Username = @Email";
                    SqlCommand getUserCmd = new SqlCommand(getUserQuery, con);
                    getUserCmd.Parameters.AddWithValue("@Email", email);
                    object result = getUserCmd.ExecuteScalar();

                    if (result == null)
                    {
                        MessageBox.Show("Email not found in user records.");
                        return;
                    }

                    string existingPasswordHash = result.ToString();

                    // STEP 2: Check current password matches
                    string inputPasswordHash = HashPassword(currentPassword);
                    if (existingPasswordHash != inputPasswordHash)
                    {
                        MessageBox.Show("Current password is incorrect.");
                        return;
                    }

                    // STEP 3: Check if password is being changed
                    bool isPasswordChanging = !string.IsNullOrWhiteSpace(confirmPassword) && currentPassword != confirmPassword;

                    if (isPasswordChanging)
                    {
                        // Confirm new password
                        if (confirmPassword != confirmPasswordTxt.Text)
                        {
                            MessageBox.Show("New password and confirm password do not match.");
                            return;
                        }

                        // Update password in Users table
                        string updateUserPwdQuery = "UPDATE Users SET PasswordHash = @NewPasswordHash WHERE Username = @Email";
                        SqlCommand updatePwdCmd = new SqlCommand(updateUserPwdQuery, con);
                        updatePwdCmd.Parameters.AddWithValue("@NewPasswordHash", HashPassword(confirmPassword));
                        updatePwdCmd.Parameters.AddWithValue("@Email", email);
                        updatePwdCmd.ExecuteNonQuery();
                    }

                    // STEP 4: Build dynamic update for Customers table
                    List<string> setClauses = new List<string>();
                    SqlCommand updateCustCmd = new SqlCommand();
                    updateCustCmd.Connection = con;

                    if (!string.IsNullOrWhiteSpace(fullName))
                    {
                        setClauses.Add("FullName = @FullName");
                        updateCustCmd.Parameters.AddWithValue("@FullName", fullName);
                    }
                    if (!string.IsNullOrWhiteSpace(nic))
                    {
                        setClauses.Add("NIC = @NIC");
                        updateCustCmd.Parameters.AddWithValue("@NIC", nic);
                    }
                    if (!string.IsNullOrWhiteSpace(contact))
                    {
                        setClauses.Add("ContactNo = @Contact");
                        updateCustCmd.Parameters.AddWithValue("@Contact", contact);
                    }
                    if (!string.IsNullOrWhiteSpace(address))
                    {
                        setClauses.Add("Address = @Address");
                        updateCustCmd.Parameters.AddWithValue("@Address", address);
                    }
                    if (!string.IsNullOrWhiteSpace(location))
                    {
                        setClauses.Add("Location = @Location");
                        updateCustCmd.Parameters.AddWithValue("@Location", location);
                    }

                    if (setClauses.Count > 0)
                    {
                        string updateCustomerQuery = "UPDATE Customers SET " + string.Join(", ", setClauses) +
                                                     " WHERE CustomerID = @CustomerID";

                        updateCustCmd.CommandText = updateCustomerQuery;
                        updateCustCmd.Parameters.AddWithValue("@CustomerID", Session.LoggedInCustomerID);

                        int rowsAffected = updateCustCmd.ExecuteNonQuery();

                        MessageBox.Show(rowsAffected > 0 || isPasswordChanging
                            ? "Profile updated successfully!"
                            : "No changes were made.");
                    }
                    else if (!isPasswordChanging)
                    {
                        MessageBox.Show("No fields to update. Please enter at least one field to change.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating profile: " + ex.Message);
                }
                clearAll();
            }
        }

        // method to clear all input fields
        private void clearAll()
        {
            IDTxt.Clear();
            fullNameTxt.Clear();
            NICTxt.Clear();
            contactNoTxt.Clear();
            addressTxt.Clear();
            locationTxt.Clear();
            emailTxt.Clear();
            currentPasswordTxt.Clear();
            confirmPasswordTxt.Clear();
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            clearAll();
        }

        private void showPasswordCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            currentPasswordTxt.UseSystemPasswordChar = !showPasswordCheckBox.Checked;
            confirmPasswordTxt.UseSystemPasswordChar = !showPasswordCheckBox.Checked;
        }
    }
}
