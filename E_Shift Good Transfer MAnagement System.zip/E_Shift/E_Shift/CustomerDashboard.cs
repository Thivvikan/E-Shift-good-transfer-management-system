﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E_Shift
{
    public partial class CustomerDashboard : Form
    {
        public CustomerDashboard()
        {
            InitializeComponent();
        }

        public CustomerDashboard(int customerId)
        {
            InitializeComponent();
           
        }

        private void logoutBtn_Click(object sender, EventArgs e)
        {
            login loginForm = new login();
            loginForm.Show();
            this.Hide();
        }

        public void CustomerLoadUserControl(UserControl uc)
        {
            mainContentArea.Controls.Clear();
            uc.Dock = DockStyle.Fill;
            mainContentArea.Controls.Add(uc);
        }

        private void manageJobsBtn_Click(object sender, EventArgs e)
        {
            CustomerLoadUserControl(new CustomerManageJobs());
        }

        private void dashboardBtn_Click(object sender, EventArgs e)
        {
            CustomerLoadUserControl(new DefaultCustomerDashboard());
        }

        private void manageProfileBtn_Click(object sender, EventArgs e)
        {
            CustomerLoadUserControl(new CustomerManageProfile());
        }

        private void enquiryBtn_Click(object sender, EventArgs e)
        {
            CustomerLoadUserControl(new CustomerEnquiry());
        }

        private void feedbackBtn_Click(object sender, EventArgs e)
        {
            CustomerLoadUserControl(new CustomerGiveFeedbacks());
        }

        private void CustomerDashboard_Load(object sender, EventArgs e)
        {
            CustomerLoadUserControl(new DefaultCustomerDashboard());
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            CustomerLoadUserControl(new DefaultCustomerDashboard());
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            CustomerLoadUserControl(new CustomerManageProfile());
        }

        private void mainContentArea_Paint(object sender, PaintEventArgs e)
        {
            mainContentArea.AutoScroll = true;

            for (int i = 0; i < 20; i++)
            {
                Label lbl = new Label();
                lbl.Text = "Label " + i;
                // Position labels so they are staggered vertically AND pushed to the right beyond panel width
                lbl.Location = new Point(10 + (i * 20), i * 30);
                lbl.Size = new Size(150, 25);
                mainContentArea.Controls.Add(lbl);
            }
        }
    }
}
