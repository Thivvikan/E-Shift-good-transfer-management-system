﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace E_Shift
{
    public partial class DiverManageProfile : UserControl
    {
        // connection string
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mind Tech Era\OneDrive\Documents\Thivvikan\E_Shift\E_Shift\Database.mdf;Integrated Security=True";

        public DiverManageProfile()
        {
            InitializeComponent();
        }

        // method to cleaa all input fields.
        private void clearAll()
        {
            driverIDTxt.Clear();
            nameTxt.Clear();
            licenceNumberTxt.Clear();
            contactNumberTxt.Clear();
            driverPasswordTxt.Clear();
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            clearAll();
        }

        // Reuse your existing hash method
        public static string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    // Step 1: Get logged-in driver's license number
                    string getLicenseQuery = "SELECT LicenceNumber FROM Driver WHERE DriverID = @DriverID";
                    SqlCommand getLicenseCmd = new SqlCommand(getLicenseQuery, con);
                    getLicenseCmd.Parameters.AddWithValue("@DriverID", Session.LoggedInDriverID);
                    string licenceNumber = getLicenseCmd.ExecuteScalar()?.ToString();

                    if (string.IsNullOrEmpty(licenceNumber))
                    {
                        MessageBox.Show("Logged-in driver details not found.");
                        return;
                    }

                    // Step 2: Hash the entered password
                    string enteredPassword = driverPasswordTxt.Text.Trim();
                    string hashedPassword = HashPassword(enteredPassword); // Use your existing hash method

                    // Step 3: Check password match in Users table
                    string checkUserQuery = "SELECT COUNT(*) FROM Users WHERE Username = @Username AND PasswordHash = @PasswordHash AND Role = 'Driver'";
                    SqlCommand checkCmd = new SqlCommand(checkUserQuery, con);
                    checkCmd.Parameters.AddWithValue("@Username", licenceNumber);
                    checkCmd.Parameters.AddWithValue("@PasswordHash", hashedPassword);

                    int userCount = (int)checkCmd.ExecuteScalar();

                    if (userCount != 1)
                    {
                        MessageBox.Show("Password incorrect. Update denied.");
                        return;
                    }

                    // Step 4: Proceed with the update
                    string updateQuery = @"UPDATE Driver 
                                   SET Name = @Name, 
                                       LicenceNumber = @LicenceNumber, 
                                       ContactNumber = @ContactNumber 
                                   WHERE DriverID = @DriverID";

                    SqlCommand updateCmd = new SqlCommand(updateQuery, con);
                    updateCmd.Parameters.AddWithValue("@DriverID", Session.LoggedInDriverID);
                    updateCmd.Parameters.AddWithValue("@Name", nameTxt.Text.Trim());
                    updateCmd.Parameters.AddWithValue("@LicenceNumber", licenceNumberTxt.Text.Trim());
                    updateCmd.Parameters.AddWithValue("@ContactNumber", contactNumberTxt.Text.Trim());

                    int rowsAffected = updateCmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Driver details updated successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Update failed. No matching record found.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error during update: " + ex.Message);
                }
                clearAll();
            }
        }
    }
}
