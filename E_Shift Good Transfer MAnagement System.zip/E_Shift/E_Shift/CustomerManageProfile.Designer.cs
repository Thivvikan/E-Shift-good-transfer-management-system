﻿namespace E_Shift
{
    partial class CustomerManageProfile
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.refreshLocationBtn = new System.Windows.Forms.Button();
            this.locationTxt = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.showPasswordCheckBox = new System.Windows.Forms.CheckBox();
            this.confirmPasswordTxt = new System.Windows.Forms.TextBox();
            this.emailTxt = new System.Windows.Forms.TextBox();
            this.addressTxt = new System.Windows.Forms.TextBox();
            this.contactNoTxt = new System.Windows.Forms.TextBox();
            this.NICTxt = new System.Windows.Forms.TextBox();
            this.fullNameTxt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.clearBtn = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.IDTxt = new System.Windows.Forms.TextBox();
            this.IDLbl = new System.Windows.Forms.Label();
            this.currentPasswordTxt = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // refreshLocationBtn
            // 
            this.refreshLocationBtn.BackgroundImage = global::E_Shift.Properties.Resources.restart;
            this.refreshLocationBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.refreshLocationBtn.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.refreshLocationBtn.Location = new System.Drawing.Point(491, 272);
            this.refreshLocationBtn.Name = "refreshLocationBtn";
            this.refreshLocationBtn.Size = new System.Drawing.Size(34, 29);
            this.refreshLocationBtn.TabIndex = 39;
            this.refreshLocationBtn.UseVisualStyleBackColor = true;
            this.refreshLocationBtn.Click += new System.EventHandler(this.refreshLocationBtn_Click);
            // 
            // locationTxt
            // 
            this.locationTxt.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.locationTxt.Location = new System.Drawing.Point(318, 272);
            this.locationTxt.Name = "locationTxt";
            this.locationTxt.Size = new System.Drawing.Size(207, 30);
            this.locationTxt.TabIndex = 38;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(142, 275);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 22);
            this.label10.TabIndex = 37;
            this.label10.Text = "Location";
            // 
            // showPasswordCheckBox
            // 
            this.showPasswordCheckBox.AutoSize = true;
            this.showPasswordCheckBox.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.showPasswordCheckBox.Location = new System.Drawing.Point(368, 421);
            this.showPasswordCheckBox.Name = "showPasswordCheckBox";
            this.showPasswordCheckBox.Size = new System.Drawing.Size(144, 26);
            this.showPasswordCheckBox.TabIndex = 36;
            this.showPasswordCheckBox.Text = "Show Password";
            this.showPasswordCheckBox.UseVisualStyleBackColor = true;
            this.showPasswordCheckBox.CheckedChanged += new System.EventHandler(this.showPasswordCheckBox_CheckedChanged);
            // 
            // confirmPasswordTxt
            // 
            this.confirmPasswordTxt.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.confirmPasswordTxt.Location = new System.Drawing.Point(318, 390);
            this.confirmPasswordTxt.Name = "confirmPasswordTxt";
            this.confirmPasswordTxt.PlaceholderText = "Enter new one, to change";
            this.confirmPasswordTxt.Size = new System.Drawing.Size(207, 30);
            this.confirmPasswordTxt.TabIndex = 35;
            this.confirmPasswordTxt.UseSystemPasswordChar = true;
            // 
            // emailTxt
            // 
            this.emailTxt.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.emailTxt.Location = new System.Drawing.Point(318, 312);
            this.emailTxt.Name = "emailTxt";
            this.emailTxt.PlaceholderText = "You cannot change";
            this.emailTxt.Size = new System.Drawing.Size(207, 30);
            this.emailTxt.TabIndex = 33;
            // 
            // addressTxt
            // 
            this.addressTxt.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.addressTxt.Location = new System.Drawing.Point(318, 218);
            this.addressTxt.Multiline = true;
            this.addressTxt.Name = "addressTxt";
            this.addressTxt.Size = new System.Drawing.Size(207, 40);
            this.addressTxt.TabIndex = 32;
            // 
            // contactNoTxt
            // 
            this.contactNoTxt.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.contactNoTxt.Location = new System.Drawing.Point(318, 171);
            this.contactNoTxt.Name = "contactNoTxt";
            this.contactNoTxt.Size = new System.Drawing.Size(207, 30);
            this.contactNoTxt.TabIndex = 31;
            // 
            // NICTxt
            // 
            this.NICTxt.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NICTxt.Location = new System.Drawing.Point(318, 123);
            this.NICTxt.Name = "NICTxt";
            this.NICTxt.Size = new System.Drawing.Size(207, 30);
            this.NICTxt.TabIndex = 30;
            // 
            // fullNameTxt
            // 
            this.fullNameTxt.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fullNameTxt.Location = new System.Drawing.Point(318, 77);
            this.fullNameTxt.Name = "fullNameTxt";
            this.fullNameTxt.Size = new System.Drawing.Size(207, 30);
            this.fullNameTxt.TabIndex = 29;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(142, 393);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(127, 22);
            this.label8.TabIndex = 28;
            this.label8.Text = "New Password";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(142, 347);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 22);
            this.label7.TabIndex = 27;
            this.label7.Text = "Password";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(142, 221);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 22);
            this.label6.TabIndex = 26;
            this.label6.Text = "Address";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(142, 316);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 22);
            this.label5.TabIndex = 25;
            this.label5.Text = "Email";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(142, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(147, 22);
            this.label4.TabIndex = 24;
            this.label4.Text = "Contact Number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(142, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(154, 22);
            this.label3.TabIndex = 23;
            this.label3.Text = "NIC/ Passport No.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(142, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 22);
            this.label2.TabIndex = 22;
            this.label2.Text = "Full Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sylfaen", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(170, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(342, 29);
            this.label1.TabIndex = 40;
            this.label1.Text = "Customer Profile Management";
            // 
            // clearBtn
            // 
            this.clearBtn.BackColor = System.Drawing.Color.Silver;
            this.clearBtn.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.clearBtn.Location = new System.Drawing.Point(432, 454);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(93, 36);
            this.clearBtn.TabIndex = 87;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = false;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Yellow;
            this.button3.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button3.Location = new System.Drawing.Point(318, 454);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(88, 36);
            this.button3.TabIndex = 86;
            this.button3.Text = "Update";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // IDTxt
            // 
            this.IDTxt.Location = new System.Drawing.Point(318, 35);
            this.IDTxt.Name = "IDTxt";
            this.IDTxt.ReadOnly = true;
            this.IDTxt.Size = new System.Drawing.Size(207, 27);
            this.IDTxt.TabIndex = 97;
            // 
            // IDLbl
            // 
            this.IDLbl.AutoSize = true;
            this.IDLbl.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.IDLbl.Location = new System.Drawing.Point(142, 39);
            this.IDLbl.Name = "IDLbl";
            this.IDLbl.Size = new System.Drawing.Size(27, 19);
            this.IDLbl.TabIndex = 96;
            this.IDLbl.Text = "ID";
            // 
            // currentPasswordTxt
            // 
            this.currentPasswordTxt.Font = new System.Drawing.Font("Sylfaen", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.currentPasswordTxt.Location = new System.Drawing.Point(318, 349);
            this.currentPasswordTxt.Name = "currentPasswordTxt";
            this.currentPasswordTxt.PlaceholderText = "current password";
            this.currentPasswordTxt.Size = new System.Drawing.Size(207, 30);
            this.currentPasswordTxt.TabIndex = 99;
            this.currentPasswordTxt.UseSystemPasswordChar = true;
            // 
            // CustomerManageProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.currentPasswordTxt);
            this.Controls.Add(this.IDTxt);
            this.Controls.Add(this.IDLbl);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.refreshLocationBtn);
            this.Controls.Add(this.locationTxt);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.showPasswordCheckBox);
            this.Controls.Add(this.confirmPasswordTxt);
            this.Controls.Add(this.emailTxt);
            this.Controls.Add(this.addressTxt);
            this.Controls.Add(this.contactNoTxt);
            this.Controls.Add(this.NICTxt);
            this.Controls.Add(this.fullNameTxt);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Name = "CustomerManageProfile";
            this.Size = new System.Drawing.Size(666, 542);
            this.Load += new System.EventHandler(this.CustomerManageProfile_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button refreshLocationBtn;
        private TextBox locationTxt;
        private Label label10;
        private CheckBox showPasswordCheckBox;
        private TextBox confirmPasswordTxt;
        private TextBox emailTxt;
        private TextBox addressTxt;
        private TextBox contactNoTxt;
        private TextBox NICTxt;
        private TextBox fullNameTxt;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button clearBtn;
        private Button button3;
        private TextBox IDTxt;
        private Label IDLbl;
        private TextBox currentPasswordTxt;
    }
}
