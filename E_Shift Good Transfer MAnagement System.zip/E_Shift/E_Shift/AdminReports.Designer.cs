﻿namespace E_Shift
{
    partial class AdminReports
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.totalJobsGB = new System.Windows.Forms.GroupBox();
            this.yearComboBox = new System.Windows.Forms.ComboBox();
            this.viewTypeComboBox = new System.Windows.Forms.ComboBox();
            this.jobStatusGB = new System.Windows.Forms.GroupBox();
            this.downloadBtn = new System.Windows.Forms.Button();
            this.statusReportDownloadBtn = new System.Windows.Forms.Button();
            this.monthCB = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.recentlyAddedJobsGrid = new System.Windows.Forms.DataGridView();
            this.topCustomersGrid = new System.Windows.Forms.DataGridView();
            this.downloadRecentlyAddedJobsBtn = new System.Windows.Forms.Button();
            this.downloadTopCustomersBtn = new System.Windows.Forms.Button();
            this.pieChartYearComboBox = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.recentlyAddedJobsGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.topCustomersGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // totalJobsGB
            // 
            this.totalJobsGB.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.totalJobsGB.Location = new System.Drawing.Point(6, 8);
            this.totalJobsGB.Name = "totalJobsGB";
            this.totalJobsGB.Size = new System.Drawing.Size(440, 285);
            this.totalJobsGB.TabIndex = 0;
            this.totalJobsGB.TabStop = false;
            this.totalJobsGB.Text = "Total Jobs";
            // 
            // yearComboBox
            // 
            this.yearComboBox.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.yearComboBox.FormattingEnabled = true;
            this.yearComboBox.Location = new System.Drawing.Point(92, 299);
            this.yearComboBox.Name = "yearComboBox";
            this.yearComboBox.Size = new System.Drawing.Size(112, 27);
            this.yearComboBox.TabIndex = 1;
            this.yearComboBox.SelectedIndexChanged += new System.EventHandler(this.yearComboBox_SelectedIndexChanged);
            // 
            // viewTypeComboBox
            // 
            this.viewTypeComboBox.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.viewTypeComboBox.FormattingEnabled = true;
            this.viewTypeComboBox.Location = new System.Drawing.Point(210, 299);
            this.viewTypeComboBox.Name = "viewTypeComboBox";
            this.viewTypeComboBox.Size = new System.Drawing.Size(128, 27);
            this.viewTypeComboBox.TabIndex = 2;
            this.viewTypeComboBox.SelectedIndexChanged += new System.EventHandler(this.viewTypeComboBox_SelectedIndexChanged);
            // 
            // jobStatusGB
            // 
            this.jobStatusGB.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.jobStatusGB.Location = new System.Drawing.Point(466, 8);
            this.jobStatusGB.Name = "jobStatusGB";
            this.jobStatusGB.Size = new System.Drawing.Size(313, 285);
            this.jobStatusGB.TabIndex = 3;
            this.jobStatusGB.TabStop = false;
            this.jobStatusGB.Text = "Job Status";
            // 
            // downloadBtn
            // 
            this.downloadBtn.BackgroundImage = global::E_Shift.Properties.Resources.download_icon;
            this.downloadBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.downloadBtn.Location = new System.Drawing.Point(344, 297);
            this.downloadBtn.Name = "downloadBtn";
            this.downloadBtn.Size = new System.Drawing.Size(102, 29);
            this.downloadBtn.TabIndex = 4;
            this.downloadBtn.UseVisualStyleBackColor = true;
            this.downloadBtn.Click += new System.EventHandler(this.downloadBtn_Click);
            // 
            // statusReportDownloadBtn
            // 
            this.statusReportDownloadBtn.BackgroundImage = global::E_Shift.Properties.Resources.download_icon;
            this.statusReportDownloadBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.statusReportDownloadBtn.Location = new System.Drawing.Point(678, 297);
            this.statusReportDownloadBtn.Name = "statusReportDownloadBtn";
            this.statusReportDownloadBtn.Size = new System.Drawing.Size(102, 29);
            this.statusReportDownloadBtn.TabIndex = 6;
            this.statusReportDownloadBtn.UseVisualStyleBackColor = true;
            this.statusReportDownloadBtn.Click += new System.EventHandler(this.statusReportDownloadBtn_Click_1);
            // 
            // monthCB
            // 
            this.monthCB.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.monthCB.FormattingEnabled = true;
            this.monthCB.Location = new System.Drawing.Point(556, 299);
            this.monthCB.Name = "monthCB";
            this.monthCB.Size = new System.Drawing.Size(116, 27);
            this.monthCB.TabIndex = 5;
            this.monthCB.TextChanged += new System.EventHandler(this.monthCB_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(20, 359);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 19);
            this.label1.TabIndex = 7;
            this.label1.Text = "Recently Added Jobs";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(465, 359);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 19);
            this.label2.TabIndex = 8;
            this.label2.Text = "Top Customers";
            // 
            // recentlyAddedJobsGrid
            // 
            this.recentlyAddedJobsGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.recentlyAddedJobsGrid.Location = new System.Drawing.Point(20, 381);
            this.recentlyAddedJobsGrid.Name = "recentlyAddedJobsGrid";
            this.recentlyAddedJobsGrid.RowHeadersWidth = 51;
            this.recentlyAddedJobsGrid.RowTemplate.Height = 29;
            this.recentlyAddedJobsGrid.Size = new System.Drawing.Size(426, 145);
            this.recentlyAddedJobsGrid.TabIndex = 9;
            // 
            // topCustomersGrid
            // 
            this.topCustomersGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.topCustomersGrid.Location = new System.Drawing.Point(466, 381);
            this.topCustomersGrid.Name = "topCustomersGrid";
            this.topCustomersGrid.RowHeadersWidth = 51;
            this.topCustomersGrid.RowTemplate.Height = 29;
            this.topCustomersGrid.Size = new System.Drawing.Size(313, 145);
            this.topCustomersGrid.TabIndex = 10;
            // 
            // downloadRecentlyAddedJobsBtn
            // 
            this.downloadRecentlyAddedJobsBtn.BackgroundImage = global::E_Shift.Properties.Resources.download_icon;
            this.downloadRecentlyAddedJobsBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.downloadRecentlyAddedJobsBtn.Location = new System.Drawing.Point(344, 532);
            this.downloadRecentlyAddedJobsBtn.Name = "downloadRecentlyAddedJobsBtn";
            this.downloadRecentlyAddedJobsBtn.Size = new System.Drawing.Size(102, 29);
            this.downloadRecentlyAddedJobsBtn.TabIndex = 11;
            this.downloadRecentlyAddedJobsBtn.UseVisualStyleBackColor = true;
            // 
            // downloadTopCustomersBtn
            // 
            this.downloadTopCustomersBtn.BackgroundImage = global::E_Shift.Properties.Resources.download_icon;
            this.downloadTopCustomersBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.downloadTopCustomersBtn.Location = new System.Drawing.Point(677, 532);
            this.downloadTopCustomersBtn.Name = "downloadTopCustomersBtn";
            this.downloadTopCustomersBtn.Size = new System.Drawing.Size(102, 29);
            this.downloadTopCustomersBtn.TabIndex = 12;
            this.downloadTopCustomersBtn.UseVisualStyleBackColor = true;
            // 
            // pieChartYearComboBox
            // 
            this.pieChartYearComboBox.Font = new System.Drawing.Font("Sylfaen", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pieChartYearComboBox.FormattingEnabled = true;
            this.pieChartYearComboBox.Location = new System.Drawing.Point(465, 299);
            this.pieChartYearComboBox.Name = "pieChartYearComboBox";
            this.pieChartYearComboBox.Size = new System.Drawing.Size(85, 27);
            this.pieChartYearComboBox.TabIndex = 13;
            this.pieChartYearComboBox.TextChanged += new System.EventHandler(this.pieChartYearComboBox_TextChanged);
            // 
            // AdminReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.pieChartYearComboBox);
            this.Controls.Add(this.downloadTopCustomersBtn);
            this.Controls.Add(this.downloadRecentlyAddedJobsBtn);
            this.Controls.Add(this.topCustomersGrid);
            this.Controls.Add(this.recentlyAddedJobsGrid);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.statusReportDownloadBtn);
            this.Controls.Add(this.monthCB);
            this.Controls.Add(this.downloadBtn);
            this.Controls.Add(this.jobStatusGB);
            this.Controls.Add(this.viewTypeComboBox);
            this.Controls.Add(this.yearComboBox);
            this.Controls.Add(this.totalJobsGB);
            this.Name = "AdminReports";
            this.Size = new System.Drawing.Size(806, 571);
            this.Load += new System.EventHandler(this.AdminReports_Load);
            ((System.ComponentModel.ISupportInitialize)(this.recentlyAddedJobsGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.topCustomersGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private GroupBox totalJobsGB;
        private ComboBox yearComboBox;
        private ComboBox viewTypeComboBox;
        private GroupBox jobStatusGB;
        private Button downloadBtn;
        private Button statusReportDownloadBtn;
        private ComboBox monthCB;
        private Label label1;
        private Label label2;
        private DataGridView recentlyAddedJobsGrid;
        private DataGridView topCustomersGrid;
        private Button downloadRecentlyAddedJobsBtn;
        private Button downloadTopCustomersBtn;
        private ComboBox pieChartYearComboBox;
    }
}
